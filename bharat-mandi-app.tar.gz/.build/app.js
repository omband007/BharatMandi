"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const path_1 = __importDefault(require("path"));
const cors_1 = __importDefault(require("cors"));
const fs_1 = __importDefault(require("fs"));
const db_abstraction_1 = require("./shared/database/db-abstraction");
const sequelize_config_1 = require("./shared/database/sequelize-config");
const i18n_backend_config_1 = require("./features/i18n/i18n-backend.config");
// Feature controllers
const grading_1 = require("./features/grading");
const marketplace_1 = require("./features/marketplace");
const transactions_1 = require("./features/transactions");
// import { usersController } from './features/users'; // DEPRECATED - use user_profiles via /api/v1/profiles
const dev_1 = require("./features/dev");
const i18n_routes_1 = __importDefault(require("./features/i18n/i18n.routes"));
const voice_controller_1 = require("./features/i18n/voice.controller");
const kisan_mitra_routes_1 = __importDefault(require("./features/i18n/kisan-mitra.routes"));
const profile_routes_1 = __importDefault(require("./features/profile/routes/profile.routes"));
const auth_routes_1 = __importDefault(require("./features/profile/routes/auth.routes"));
const app = (0, express_1.default)();
// Initialize DatabaseManager for PostgreSQL
const dbManager = new db_abstraction_1.DatabaseManager();
// Make dbManager globally accessible for media controller
global.sharedDbManager = dbManager;
// Initialize databases on startup
(async () => {
    try {
        // Initialize PostgreSQL with Sequelize (for profile management)
        try {
            const connected = await (0, sequelize_config_1.testSequelizeConnection)();
            if (connected) {
                // Sync database schema (create tables if they don't exist)
                await (0, sequelize_config_1.syncDatabase)(false); // Use alter mode, not force
                console.log('✓ PostgreSQL (Sequelize) initialized');
            }
        }
        catch (pgError) {
            console.warn('⚠ PostgreSQL connection failed - profile features may not work:', pgError.message);
            console.warn('  To fix: Check PostgreSQL connection settings in .env');
        }
        // Start DatabaseManager (connection monitoring)
        await dbManager.start();
        console.log('✓ DatabaseManager started - PostgreSQL connectivity confirmed');
    }
    catch (error) {
        console.error('✗ Failed to initialize databases:', error);
    }
})();
// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n[App] Shutting down gracefully...');
    dbManager.stop();
    process.exit(0);
});
process.on('SIGTERM', () => {
    console.log('\n[App] Shutting down gracefully...');
    dbManager.stop();
    process.exit(0);
});
// Middleware
app.use((0, cors_1.default)());
app.use(express_1.default.json());
app.use(i18n_backend_config_1.i18nextMiddleware); // Add i18n middleware for language detection
// Serve static files from public directory
app.use(express_1.default.static(path_1.default.join(__dirname, '../public')));
// Serve media files from data/media directory
app.use('/data/media', express_1.default.static(path_1.default.join(__dirname, '../data/media')));
// Serve markdown files
app.get('/docs/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path_1.default.join(__dirname, '..', filename);
    if (fs_1.default.existsSync(filePath) && filename.endsWith('.md')) {
        const content = fs_1.default.readFileSync(filePath, 'utf-8');
        res.type('text/plain').send(content);
    }
    else {
        res.status(404).send('File not found');
    }
});
// Health check with database status
app.get('/api/health', (req, res) => {
    const healthStatus = dbManager.getHealthStatus();
    const isConnected = dbManager.isPostgreSQLConnected();
    console.log('[Health Check] PostgreSQL connected:', isConnected);
    console.log('[Health Check] Health status:', healthStatus);
    res.json({
        status: 'ok',
        timestamp: new Date(),
        databases: {
            postgresql: {
                ...healthStatus.postgresql,
                isConnected: isConnected
            }
        }
    });
});
// Feature routes
app.use('/api/v1/profiles', profile_routes_1.default); // Profile management routes
app.use('/api/v1/profiles/auth', auth_routes_1.default); // Authentication routes
app.use('/api/grading', grading_1.gradingController);
app.use('/api/marketplace', marketplace_1.marketplaceController);
app.use('/api/marketplace', marketplace_1.mediaController); // Media routes under /api/marketplace
app.use('/api/transactions', transactions_1.transactionController);
// app.use('/api/users', usersController); // DEPRECATED - use /api/v1/profiles instead
app.use('/api/i18n', i18n_routes_1.default); // i18n routes
app.use('/api/voice', voice_controller_1.voiceController); // Voice routes
app.use('/api/kisan-mitra', kisan_mitra_routes_1.default); // Kisan Mitra AI assistant routes
// Development routes (only in development)
if (process.env.NODE_ENV !== 'production') {
    app.use('/api/dev', dev_1.devController);
    console.log('✓ Development endpoints enabled at /api/dev');
}
exports.default = app;
//# sourceMappingURL=app.js.map