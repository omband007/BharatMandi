"use strict";
/**
 * ExpirationService
 * Automatically expires listings based on expiry_date
 * Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.expirationService = exports.ExpirationService = void 0;
const listing_status_manager_1 = require("./listing-status-manager");
// Get the shared DatabaseManager instance from app.ts
function getDbManager() {
    const dbManager = global.sharedDbManager;
    if (!dbManager) {
        throw new Error('DatabaseManager not initialized. This should be set by app.ts');
    }
    return dbManager;
}
class ExpirationService {
    constructor() {
        this.intervalId = null;
        this.CHECK_INTERVAL_MS = 60 * 60 * 1000; // 1 hour in milliseconds
    }
    /**
     * Check for expired listings and transition them to EXPIRED status
     * Requirements: 4.1, 4.3, 4.4
     *
     * @returns Number of listings expired
     */
    async checkExpiredListings() {
        const dbManager = getDbManager();
        try {
            // Query ACTIVE listings where expiry_date < NOW()
            const expiredListings = await dbManager.all(`SELECT id, expiry_date FROM listings 
         WHERE status = ? AND expiry_date < ?`, [listing_status_manager_1.ListingStatus.ACTIVE, new Date().toISOString()]);
            console.log(`[ExpirationService] Found ${expiredListings.length} expired listings`);
            // Expire each listing
            let expiredCount = 0;
            for (const listing of expiredListings) {
                try {
                    await this.expireListing(listing.id);
                    expiredCount++;
                }
                catch (error) {
                    console.error(`[ExpirationService] Failed to expire listing ${listing.id}:`, error);
                    // Continue with other listings even if one fails
                }
            }
            console.log(`[ExpirationService] Successfully expired ${expiredCount} listings`);
            return expiredCount;
        }
        catch (error) {
            console.error('[ExpirationService] Error checking expired listings:', error);
            throw error;
        }
    }
    /**
     * Expire a single listing
     * Requirements: 4.3, 4.5, 4.6
     *
     * @param listingId - Listing ID to expire
     */
    async expireListing(listingId) {
        try {
            // Transition status to EXPIRED
            await listing_status_manager_1.listingStatusManager.transitionStatus(listingId, listing_status_manager_1.ListingStatus.EXPIRED, 'SYSTEM', listing_status_manager_1.TriggerType.SYSTEM, {
                reason: 'automatic_expiration',
                expired_at: new Date().toISOString()
            });
            console.log(`[ExpirationService] Expired listing: ${listingId}`);
        }
        catch (error) {
            console.error(`[ExpirationService] Failed to expire listing ${listingId}:`, error);
            throw error;
        }
    }
    /**
     * Schedule periodic expiration checks
     * Requirements: 4.2
     *
     * Runs checkExpiredListings() every hour
     */
    scheduleExpirationCheck() {
        if (this.intervalId) {
            console.log('[ExpirationService] Expiration check already scheduled');
            return;
        }
        console.log('[ExpirationService] Starting expiration scheduler (runs every hour)');
        // Run immediately on startup
        this.checkExpiredListings().catch(error => {
            console.error('[ExpirationService] Initial expiration check failed:', error);
        });
        // Schedule periodic checks
        this.intervalId = setInterval(() => {
            this.checkExpiredListings().catch(error => {
                console.error('[ExpirationService] Scheduled expiration check failed:', error);
            });
        }, this.CHECK_INTERVAL_MS);
        console.log('[ExpirationService] Expiration scheduler started');
    }
    /**
     * Stop the expiration scheduler
     * Used for graceful shutdown
     */
    stopScheduler() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
            console.log('[ExpirationService] Expiration scheduler stopped');
        }
    }
    /**
     * Check if scheduler is running
     */
    isSchedulerRunning() {
        return this.intervalId !== null;
    }
    /**
     * Get upcoming expirations (listings expiring in next N hours)
     * Useful for notifications or monitoring
     *
     * @param hoursAhead - Number of hours to look ahead
     * @returns Array of listings expiring soon
     */
    async getUpcomingExpirations(hoursAhead = 24) {
        const dbManager = getDbManager();
        const futureDate = new Date();
        futureDate.setHours(futureDate.getHours() + hoursAhead);
        return await dbManager.all(`SELECT * FROM listings 
       WHERE status = ? 
       AND expiry_date > ? 
       AND expiry_date <= ?
       ORDER BY expiry_date ASC`, [listing_status_manager_1.ListingStatus.ACTIVE, new Date().toISOString(), futureDate.toISOString()]);
    }
    /**
     * Get expiration statistics
     * Useful for monitoring and analytics
     *
     * @returns Statistics about expired listings
     */
    async getExpirationStats() {
        const dbManager = getDbManager();
        const now = new Date();
        const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const weekStart = new Date(now);
        weekStart.setDate(weekStart.getDate() - 7);
        const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
        const [total, today, week, month] = await Promise.all([
            dbManager.get('SELECT COUNT(*) as count FROM listings WHERE status = ?', [listing_status_manager_1.ListingStatus.EXPIRED]),
            dbManager.get('SELECT COUNT(*) as count FROM listings WHERE status = ? AND expired_at >= ?', [listing_status_manager_1.ListingStatus.EXPIRED, todayStart.toISOString()]),
            dbManager.get('SELECT COUNT(*) as count FROM listings WHERE status = ? AND expired_at >= ?', [listing_status_manager_1.ListingStatus.EXPIRED, weekStart.toISOString()]),
            dbManager.get('SELECT COUNT(*) as count FROM listings WHERE status = ? AND expired_at >= ?', [listing_status_manager_1.ListingStatus.EXPIRED, monthStart.toISOString()])
        ]);
        return {
            total_expired: total?.count || 0,
            expired_today: today?.count || 0,
            expired_this_week: week?.count || 0,
            expired_this_month: month?.count || 0
        };
    }
}
exports.ExpirationService = ExpirationService;
// Export singleton instance
exports.expirationService = new ExpirationService();
//# sourceMappingURL=expiration.service.js.map