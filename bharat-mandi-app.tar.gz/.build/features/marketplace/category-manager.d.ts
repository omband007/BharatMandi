/**
 * CategoryManager Service
 * Manages produce categories for perishability-based listing expiration
 * Requirements: 6.1, 6.2, 6.3, 6.4, 6.6
 */
export interface ProduceCategory {
    id: string;
    name: string;
    expiry_period_hours: number;
    description: string;
    created_at: Date;
    updated_at: Date;
}
export interface CreateCategoryInput {
    name: string;
    expiry_period_hours: number;
    description?: string;
}
export interface UpdateCategoryInput {
    name?: string;
    expiry_period_hours?: number;
    description?: string;
}
export declare class CategoryManager {
    /**
     * Create a new produce category
     * Requirements: 6.1, 6.2, 6.6
     *
     * @param input - Category creation data
     * @returns Created category
     * @throws Error if name already exists or expiry period is invalid
     */
    createCategory(input: CreateCategoryInput): Promise<ProduceCategory>;
    /**
     * Update an existing produce category
     * Requirements: 6.3
     *
     * @param id - Category ID
     * @param updates - Fields to update
     * @returns Updated category
     * @throws Error if category not found or validation fails
     */
    updateCategory(id: string, updates: UpdateCategoryInput): Promise<ProduceCategory>;
    /**
     * Delete a produce category
     * Requirements: 6.4
     *
     * @param id - Category ID
     * @throws Error if category has existing listings
     */
    deleteCategory(id: string): Promise<void>;
    /**
     * Get all produce categories
     * Requirements: 6.1
     *
     * @returns Array of all categories
     */
    getCategories(): Promise<ProduceCategory[]>;
    /**
     * Get a category by ID
     * Requirements: 6.1
     *
     * @param id - Category ID
     * @returns Category or undefined if not found
     */
    getCategoryById(id: string): Promise<ProduceCategory | undefined>;
    /**
     * Get a category by name
     *
     * @param name - Category name
     * @returns Category or undefined if not found
     */
    getCategoryByName(name: string): Promise<ProduceCategory | undefined>;
    /**
     * Map database row to ProduceCategory object
     * Handles both PostgreSQL and SQLite date formats
     */
    private mapRowToCategory;
}
export declare const categoryManager: CategoryManager;
//# sourceMappingURL=category-manager.d.ts.map