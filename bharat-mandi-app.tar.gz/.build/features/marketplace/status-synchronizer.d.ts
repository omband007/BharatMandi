/**
 * StatusSynchronizer Service
 * Synchronizes listing status with transaction and escrow state changes
 * Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 7.1, 7.2, 7.3, 7.4, 7.5, 20.4, 20.5
 */
export declare class StatusSynchronizer {
    /**
     * Handle transaction completion (escrow flow)
     * Requirements: 5.1, 5.2, 5.3
     *
     * Transitions listing to SOLD when transaction reaches COMPLETED state
     *
     * @param transactionId - Transaction ID
     */
    onTransactionCompleted(transactionId: string): Promise<void>;
    /**
     * Handle direct payment transaction completion
     * Requirements: 20.4, 20.5, 5.1, 5.2, 5.3
     *
     * Transitions listing to SOLD when transaction reaches COMPLETED_DIRECT state
     *
     * @param transactionId - Transaction ID
     */
    onTransactionCompletedDirect(transactionId: string): Promise<void>;
    /**
     * Handle transaction cancellation
     * Requirements: 7.1, 7.2, 7.5
     *
     * Returns listing to ACTIVE if not expired, otherwise marks as EXPIRED
     *
     * @param transactionId - Transaction ID
     */
    onTransactionCancelled(transactionId: string): Promise<void>;
    /**
     * Handle transaction rejection
     * Requirements: 7.3, 7.4, 7.5
     *
     * Returns listing to ACTIVE if not expired, otherwise marks as EXPIRED
     *
     * @param transactionId - Transaction ID
     */
    onTransactionRejected(transactionId: string): Promise<void>;
    /**
     * Handle escrow refund
     * Requirements: 7.1, 7.2, 7.5
     *
     * Returns listing to ACTIVE if not expired, otherwise marks as EXPIRED
     *
     * @param escrowId - Escrow account ID
     */
    onEscrowRefunded(escrowId: string): Promise<void>;
    /**
     * Check if a listing should be reactivated
     * Requirements: 7.5
     *
     * Returns true if expiry_date has not passed, false otherwise
     *
     * @param listingId - Listing ID
     * @returns true if listing can be reactivated
     */
    shouldReactivateListing(listingId: string): Promise<boolean>;
}
export declare const statusSynchronizer: StatusSynchronizer;
//# sourceMappingURL=status-synchronizer.d.ts.map