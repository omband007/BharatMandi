/**
 * ListingStatusManager Service
 * Manages listing status transitions, validation, and audit trail
 * Requirements: 1.1, 1.2, 1.3, 1.4, 9.1, 9.2, 9.3, 11.1, 11.2, 16.1, 16.2, 16.5, 17.1
 */
export declare enum ListingStatus {
    ACTIVE = "ACTIVE",
    SOLD = "SOLD",
    EXPIRED = "EXPIRED",
    CANCELLED = "CANCELLED"
}
export declare enum ListingType {
    PRE_HARVEST = "PRE_HARVEST",
    POST_HARVEST = "POST_HARVEST"
}
export declare enum SaleChannel {
    PLATFORM = "PLATFORM",
    EXTERNAL = "EXTERNAL"
}
export declare enum TriggerType {
    USER = "USER",
    SYSTEM = "SYSTEM",
    TRANSACTION = "TRANSACTION"
}
export interface StatusChangeRecord {
    id: string;
    listing_id: string;
    previous_status: ListingStatus | null;
    new_status: ListingStatus;
    changed_at: Date;
    triggered_by: string;
    trigger_type: TriggerType;
    metadata?: Record<string, any>;
}
export interface MarkAsSoldInput {
    listingId: string;
    saleChannel: SaleChannel;
    salePrice?: number;
    saleNotes?: string;
    userId: string;
}
export declare class ListingStatusManager {
    /**
     * Valid state transitions
     * Requirements: 11.1, 11.2
     */
    private readonly VALID_TRANSITIONS;
    /**
     * Validate if a status transition is allowed
     * Requirements: 11.1, 11.2
     *
     * @param currentStatus - Current listing status
     * @param newStatus - Desired new status
     * @returns true if transition is valid
     */
    validateTransition(currentStatus: ListingStatus, newStatus: ListingStatus): boolean;
    /**
     * Transition a listing to a new status
     * Requirements: 1.1, 1.2, 1.3, 1.4
     *
     * @param listingId - Listing ID
     * @param newStatus - New status
     * @param triggeredBy - User ID or 'SYSTEM'
     * @param triggerType - Type of trigger (USER, SYSTEM, TRANSACTION)
     * @param metadata - Additional context
     * @throws Error if transition is invalid
     */
    transitionStatus(listingId: string, newStatus: ListingStatus, triggeredBy: string, triggerType: TriggerType, metadata?: Record<string, any>): Promise<void>;
    /**
     * Record a status change in the audit trail
     * Requirements: 1.4
     *
     * @param listingId - Listing ID
     * @param previousStatus - Previous status
     * @param newStatus - New status
     * @param triggeredBy - User ID or 'SYSTEM'
     * @param triggerType - Type of trigger
     * @param metadata - Additional context
     */
    recordStatusChange(listingId: string, previousStatus: ListingStatus | null, newStatus: ListingStatus, triggeredBy: string, triggerType: TriggerType, metadata?: Record<string, any>): Promise<void>;
    /**
     * Get listings by status with optional filtering
     * Requirements: 9.1, 9.2, 9.3
     *
     * @param statuses - Array of statuses to filter by
     * @param farmerId - Optional farmer ID filter
     * @returns Array of listings
     */
    getListingsByStatus(statuses: ListingStatus[], farmerId?: string): Promise<any[]>;
    /**
     * Calculate expiry date for a listing
     * Requirements: 16.1, 16.2, 16.5, 17.1
     *
     * @param harvestDate - Expected or actual harvest date
     * @param categoryId - Produce category ID
     * @returns Calculated expiry date
     */
    calculateExpiryDate(harvestDate: Date, categoryId: string): Promise<Date>;
    /**
     * Mark a listing as sold (manual sale confirmation)
     * Requirements: 19.1, 19.2, 19.3, 19.4, 19.5, 19.6, 19.7, 19.8, 19.9, 19.10
     *
     * @param input - Sale confirmation details
     * @throws Error if validation fails or active transaction exists
     */
    markAsSold(input: MarkAsSoldInput): Promise<void>;
    /**
     * Get status history for a listing
     *
     * @param listingId - Listing ID
     * @returns Array of status change records
     */
    getStatusHistory(listingId: string): Promise<StatusChangeRecord[]>;
}
export declare const listingStatusManager: ListingStatusManager;
//# sourceMappingURL=listing-status-manager.d.ts.map