export declare const marketplaceController: import("express-serve-static-core").Router;
//# sourceMappingURL=marketplace.controller.d.ts.map