"use strict";
// File validation service for media uploads
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.validationService = exports.ValidationService = void 0;
const path = __importStar(require("path"));
const media_constants_1 = require("./media.constants");
class ValidationService {
    /**
     * Validate media file
     * @param file - File buffer
     * @param fileName - Original file name
     * @param mimeType - File MIME type
     * @param mediaType - Expected media type
     * @returns Validation result
     */
    validateMediaFile(file, fileName, mimeType, mediaType) {
        // Validate file is not empty
        if (!file || file.length === 0) {
            return {
                valid: false,
                error: 'File is empty or invalid'
            };
        }
        // Validate file extension
        const extensionValidation = this.validateFileExtension(fileName, mimeType);
        if (!extensionValidation.valid) {
            return extensionValidation;
        }
        // Validate MIME type
        const mimeValidation = this.validateMimeType(mimeType, mediaType);
        if (!mimeValidation.valid) {
            return mimeValidation;
        }
        // Validate file size
        const sizeValidation = this.validateFileSize(file.length, mediaType);
        if (!sizeValidation.valid) {
            return sizeValidation;
        }
        return { valid: true };
    }
    /**
     * Validate file extension matches MIME type
     * @param fileName - File name
     * @param mimeType - MIME type
     * @returns Validation result
     */
    validateFileExtension(fileName, mimeType) {
        const extension = path.extname(fileName).toLowerCase();
        if (!extension) {
            return {
                valid: false,
                error: 'File must have a valid extension'
            };
        }
        const expectedMimeType = media_constants_1.FILE_EXTENSION_TO_MIME[extension];
        if (!expectedMimeType) {
            return {
                valid: false,
                error: `Unsupported file extension: ${extension}. Allowed extensions: .jpg, .jpeg, .png, .webp, .mp4, .mov, .pdf`
            };
        }
        if (expectedMimeType !== mimeType) {
            return {
                valid: false,
                error: `File extension ${extension} does not match MIME type ${mimeType}`
            };
        }
        return { valid: true };
    }
    /**
     * Validate MIME type for media type
     * @param mimeType - MIME type
     * @param mediaType - Media type
     * @returns Validation result
     */
    validateMimeType(mimeType, mediaType) {
        const allowedMimeTypes = media_constants_1.ALLOWED_MIME_TYPES[mediaType];
        if (!allowedMimeTypes.includes(mimeType)) {
            return {
                valid: false,
                error: `Invalid MIME type ${mimeType} for ${mediaType}. Allowed types: ${allowedMimeTypes.join(', ')}`
            };
        }
        return { valid: true };
    }
    /**
     * Validate file size
     * @param fileSize - File size in bytes
     * @param mediaType - Media type
     * @returns Validation result
     */
    validateFileSize(fileSize, mediaType) {
        const maxSize = media_constants_1.MAX_FILE_SIZES[mediaType];
        if (fileSize > maxSize) {
            const maxSizeMB = (maxSize / (1024 * 1024)).toFixed(0);
            const fileSizeMB = (fileSize / (1024 * 1024)).toFixed(2);
            return {
                valid: false,
                error: `File size ${fileSizeMB}MB exceeds maximum allowed size of ${maxSizeMB}MB for ${mediaType}. Please compress or reduce the file size.`
            };
        }
        if (fileSize === 0) {
            return {
                valid: false,
                error: 'File is empty (0 bytes)'
            };
        }
        return { valid: true };
    }
    /**
     * Detect media type from MIME type
     * @param mimeType - MIME type
     * @returns Media type or undefined
     */
    detectMediaType(mimeType) {
        return media_constants_1.MIME_TO_MEDIA_TYPE[mimeType];
    }
    /**
     * Detect media type from file extension
     * @param fileName - File name
     * @returns Media type or undefined
     */
    detectMediaTypeFromExtension(fileName) {
        const extension = path.extname(fileName).toLowerCase();
        const mimeType = media_constants_1.FILE_EXTENSION_TO_MIME[extension];
        if (!mimeType) {
            return undefined;
        }
        return media_constants_1.MIME_TO_MEDIA_TYPE[mimeType];
    }
    /**
     * Get human-readable error message for validation
     * @param error - Error message
     * @returns User-friendly error message
     */
    getUserFriendlyError(error) {
        // Map technical errors to user-friendly messages
        if (error.includes('exceeds maximum')) {
            return error; // Already user-friendly
        }
        if (error.includes('extension')) {
            return 'Please upload a valid file type (JPEG, PNG, WebP for photos; MP4, MOV for videos; PDF for documents)';
        }
        if (error.includes('MIME type')) {
            return 'The file type is not supported. Please upload a valid image, video, or PDF file.';
        }
        if (error.includes('empty')) {
            return 'The file appears to be empty or corrupted. Please try uploading a different file.';
        }
        return 'File validation failed. Please check the file and try again.';
    }
}
exports.ValidationService = ValidationService;
// Export singleton instance
exports.validationService = new ValidationService();
//# sourceMappingURL=validation.service.js.map