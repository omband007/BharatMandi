/**
 * ExpirationService
 * Automatically expires listings based on expiry_date
 * Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6
 */
export declare class ExpirationService {
    private intervalId;
    private readonly CHECK_INTERVAL_MS;
    /**
     * Check for expired listings and transition them to EXPIRED status
     * Requirements: 4.1, 4.3, 4.4
     *
     * @returns Number of listings expired
     */
    checkExpiredListings(): Promise<number>;
    /**
     * Expire a single listing
     * Requirements: 4.3, 4.5, 4.6
     *
     * @param listingId - Listing ID to expire
     */
    expireListing(listingId: string): Promise<void>;
    /**
     * Schedule periodic expiration checks
     * Requirements: 4.2
     *
     * Runs checkExpiredListings() every hour
     */
    scheduleExpirationCheck(): void;
    /**
     * Stop the expiration scheduler
     * Used for graceful shutdown
     */
    stopScheduler(): void;
    /**
     * Check if scheduler is running
     */
    isSchedulerRunning(): boolean;
    /**
     * Get upcoming expirations (listings expiring in next N hours)
     * Useful for notifications or monitoring
     *
     * @param hoursAhead - Number of hours to look ahead
     * @returns Array of listings expiring soon
     */
    getUpcomingExpirations(hoursAhead?: number): Promise<any[]>;
    /**
     * Get expiration statistics
     * Useful for monitoring and analytics
     *
     * @returns Statistics about expired listings
     */
    getExpirationStats(): Promise<{
        total_expired: number;
        expired_today: number;
        expired_this_week: number;
        expired_this_month: number;
    }>;
}
export declare const expirationService: ExpirationService;
//# sourceMappingURL=expiration.service.d.ts.map