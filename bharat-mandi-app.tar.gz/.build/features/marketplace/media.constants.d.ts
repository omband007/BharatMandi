import type { MediaType } from './media.types';
export declare const ALLOWED_MIME_TYPES: Record<MediaType, string[]>;
export declare const MAX_FILE_SIZES: Record<MediaType, number>;
export declare const MAX_MEDIA_PER_LISTING = 10;
export declare const FILE_EXTENSION_TO_MIME: Record<string, string>;
export declare const MIME_TO_MEDIA_TYPE: Record<string, MediaType>;
export declare const THUMBNAIL_WIDTH = 200;
export declare const THUMBNAIL_HEIGHT = 200;
export declare const IMAGE_COMPRESSION_QUALITY = 85;
export declare const SIGNED_URL_EXPIRATION = 3600;
export declare const MAX_RETRY_ATTEMPTS = 3;
export declare const RETRY_BACKOFF_MS: number[];
//# sourceMappingURL=media.constants.d.ts.map