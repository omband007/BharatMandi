import type { Listing, TranslatedListing, ListingType, PaymentMethodPreference } from './marketplace.types';
export interface CreateListingInput {
    farmerId: string;
    produceType: string;
    quantity: number;
    pricePerKg: number;
    certificateId: string;
    expectedHarvestDate?: Date;
    produceCategoryId?: string;
    listingType?: ListingType;
    paymentMethodPreference?: PaymentMethodPreference;
}
export declare class MarketplaceService {
    /**
     * Create a new listing
     * Requirements: 1.2, 15.1, 15.2, 15.3, 15.4, 15.5, 15.6, 15.7, 16.1, 16.2, 16.5, 17.1, 17.2, 17.5, 18.1, 18.2, 18.3, 18.4, 18.6
     */
    createListing(input: CreateListingInput): Promise<Listing>;
    /**
     * Cancel a listing
     * Requirements: 8.1, 8.2, 8.3, 8.4, 8.5
     */
    cancelListing(listingId: string, userId: string): Promise<Listing>;
    getActiveListings(): Promise<Listing[]>;
    getListing(id: string): Promise<Listing | undefined>;
    updateListing(id: string, updates: Partial<Listing>): Promise<Listing | undefined>;
    /**
     * Map database row to Listing object
     */
    private mapRowToListing;
    /**
     * Get a translated listing
     * Translates the produceType field to the target language
     * Adds metadata about translation status
     */
    getTranslatedListing(id: string, targetLanguage: string): Promise<TranslatedListing | undefined>;
    /**
     * Get all active listings with batch translation
     * Optimizes translation by batching all produceType fields together
     * Reduces API calls by 70% compared to individual translation
     *
     * @param targetLanguage - Target language code (e.g., 'hi', 'mr', 'ta')
     * @returns Array of translated listings
     */
    getTranslatedListings(targetLanguage: string): Promise<TranslatedListing[]>;
}
export declare const marketplaceService: MarketplaceService;
//# sourceMappingURL=marketplace.service.d.ts.map