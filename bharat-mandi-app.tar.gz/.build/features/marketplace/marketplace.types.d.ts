export declare enum ListingStatus {
    ACTIVE = "ACTIVE",
    SOLD = "SOLD",
    EXPIRED = "EXPIRED",
    CANCELLED = "CANCELLED"
}
export declare enum ListingType {
    PRE_HARVEST = "PRE_HARVEST",
    POST_HARVEST = "POST_HARVEST"
}
export declare enum PaymentMethodPreference {
    PLATFORM_ONLY = "PLATFORM_ONLY",
    DIRECT_ONLY = "DIRECT_ONLY",
    BOTH = "BOTH"
}
export declare enum SaleChannel {
    PLATFORM = "PLATFORM",
    EXTERNAL = "EXTERNAL"
}
export interface Listing {
    id: string;
    farmerId: string;
    produceType: string;
    quantity: number;
    pricePerKg: number;
    certificateId: string;
    expectedHarvestDate?: Date;
    createdAt: Date;
    updatedAt: Date;
    status: ListingStatus;
    soldAt?: Date;
    transactionId?: string;
    expiredAt?: Date;
    cancelledAt?: Date;
    cancelledBy?: string;
    listingType: ListingType;
    produceCategoryId: string;
    produceCategoryName?: string;
    expiryDate: Date;
    paymentMethodPreference: PaymentMethodPreference;
    saleChannel?: SaleChannel;
    salePrice?: number;
    saleNotes?: string;
}
export interface TranslatedListing extends Listing {
    originalProduceType: string;
    translatedProduceType: string;
    isTranslated: boolean;
    sourceLanguage: string;
    targetLanguage: string;
}
//# sourceMappingURL=marketplace.types.d.ts.map