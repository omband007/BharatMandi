import type { MediaType } from './media.types';
export declare class StorageService {
    private s3Client;
    private bucketName;
    private localStoragePath;
    private useS3;
    constructor();
    /**
     * Upload file to cloud storage (AWS S3) or local storage
     * @param file - File buffer
     * @param key - Storage key (path)
     * @param mimeType - File MIME type
     * @returns Storage URL
     */
    uploadFile(file: Buffer, key: string, mimeType: string): Promise<string>;
    /**
     * Delete file from cloud storage (AWS S3) or local storage
     * @param key - Storage key (path)
     * @returns Success boolean
     */
    deleteFile(key: string): Promise<boolean>;
    /**
     * Generate signed URL for secure file access
     * @param urlOrKey - Storage URL or key (path)
     * @param expiresIn - Expiration time in seconds
     * @returns Signed URL or URL path
     */
    generateSignedUrl(urlOrKey: string, expiresIn?: number): Promise<string>;
    /**
     * Upload file to local storage (offline support)
     * @param file - File buffer
     * @param filePath - Relative file path
     * @returns URL path for accessing the file
     */
    uploadToLocal(file: Buffer, filePath: string): Promise<string>;
    /**
     * Delete file from local storage
     * @param filePath - Relative file path
     * @returns Success boolean
     */
    deleteFromLocal(filePath: string): Promise<boolean>;
    /**
     * Generate thumbnail for image or video
     * @param file - Original file buffer
     * @param mediaType - Type of media (photo or video)
     * @returns Thumbnail buffer
     */
    generateThumbnail(file: Buffer, mediaType: MediaType): Promise<Buffer>;
    /**
     * Compress image before upload
     * @param file - Original image buffer
     * @returns Compressed image buffer
     */
    compressImage(file: Buffer): Promise<Buffer>;
    /**
     * Generate storage key for media file
     * @param listingId - Listing ID
     * @param mediaId - Media ID
     * @param fileName - Original file name
     * @returns Storage key
     */
    generateStorageKey(listingId: string, mediaId: string, fileName: string): string;
    /**
     * Generate storage key for thumbnail
     * @param listingId - Listing ID
     * @param mediaId - Media ID
     * @returns Thumbnail storage key
     */
    generateThumbnailKey(listingId: string, mediaId: string): string;
    /**
     * Ensure local storage directory exists
     */
    private ensureLocalStorageDirectory;
    /**
     * Get file size
     * @param filePath - File path (can be URL path or relative path)
     * @returns File size in bytes
     */
    getFileSize(filePath: string): number;
    /**
     * Check if file exists
     * @param filePath - File path (can be URL path or relative path)
     * @returns Boolean indicating if file exists
     */
    fileExists(filePath: string): boolean;
}
export declare const storageService: StorageService;
//# sourceMappingURL=storage.service.d.ts.map