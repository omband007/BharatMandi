/**
 * Mock DatabaseManager for Marketplace Controller Tests
 *
 * Provides a mock DatabaseManager instance for testing
 * to enable isolated controller testing without real database operations.
 */
import type { DatabaseManager } from '../../../../shared/database/db-abstraction';
/**
 * Create mock DatabaseManager with required methods
 */
export declare function createMockDatabaseManager(): Partial<DatabaseManager>;
//# sourceMappingURL=mock-database-manager.d.ts.map