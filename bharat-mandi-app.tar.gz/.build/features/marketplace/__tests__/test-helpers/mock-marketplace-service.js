"use strict";
/**
 * Mock Marketplace Service Configuration
 *
 * Provides mock implementations for marketplace service and media service
 * to enable isolated controller testing.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createMockMarketplaceService = createMockMarketplaceService;
exports.createMockMediaService = createMockMediaService;
exports.configureMockMarketplaceService = configureMockMarketplaceService;
exports.configureMockMediaService = configureMockMediaService;
const marketplace_types_1 = require("../../marketplace.types");
/**
 * Create mock marketplace service with all methods
 */
function createMockMarketplaceService() {
    return {
        createListing: jest.fn(),
        getActiveListings: jest.fn(),
        getListing: jest.fn()
    };
}
/**
 * Create mock media service with all methods
 */
function createMockMediaService() {
    return {
        uploadMedia: jest.fn()
    };
}
/**
 * Configure mock marketplace service with default success responses
 */
function configureMockMarketplaceService(mockService) {
    mockService.createListing.mockResolvedValue({
        id: 'test-listing-id',
        farmerId: 'test-farmer-id',
        produceType: 'Tomatoes',
        quantity: 100,
        pricePerKg: 50,
        certificateId: 'test-cert-id',
        createdAt: new Date('2024-01-01T00:00:00.000Z'),
        updatedAt: new Date('2024-01-01T00:00:00.000Z'),
        status: marketplace_types_1.ListingStatus.ACTIVE,
        listingType: marketplace_types_1.ListingType.POST_HARVEST,
        produceCategoryId: 'cat-1',
        expiryDate: new Date('2024-01-02T00:00:00.000Z'),
        paymentMethodPreference: marketplace_types_1.PaymentMethodPreference.BOTH
    });
    mockService.getActiveListings.mockResolvedValue([
        {
            id: 'test-listing-id',
            farmerId: 'test-farmer-id',
            produceType: 'Tomatoes',
            quantity: 100,
            pricePerKg: 50,
            certificateId: 'test-cert-id',
            createdAt: new Date('2024-01-01T00:00:00.000Z'),
            updatedAt: new Date('2024-01-01T00:00:00.000Z'),
            status: marketplace_types_1.ListingStatus.ACTIVE,
            listingType: marketplace_types_1.ListingType.POST_HARVEST,
            produceCategoryId: 'cat-1',
            expiryDate: new Date('2024-01-02T00:00:00.000Z'),
            paymentMethodPreference: marketplace_types_1.PaymentMethodPreference.BOTH
        }
    ]);
    mockService.getListing.mockResolvedValue({
        id: 'test-listing-id',
        farmerId: 'test-farmer-id',
        produceType: 'Tomatoes',
        quantity: 100,
        pricePerKg: 50,
        certificateId: 'test-cert-id',
        createdAt: new Date('2024-01-01T00:00:00.000Z'),
        updatedAt: new Date('2024-01-01T00:00:00.000Z'),
        status: marketplace_types_1.ListingStatus.ACTIVE,
        listingType: marketplace_types_1.ListingType.POST_HARVEST,
        produceCategoryId: 'cat-1',
        expiryDate: new Date('2024-01-02T00:00:00.000Z'),
        paymentMethodPreference: marketplace_types_1.PaymentMethodPreference.BOTH
    });
}
/**
 * Configure mock media service with default success responses
 */
function configureMockMediaService(mockService) {
    mockService.uploadMedia.mockResolvedValue({
        mediaId: 'test-media-id',
        storageUrl: 'https://storage.example.com/test-media-id.jpg',
        success: true
    });
}
//# sourceMappingURL=mock-marketplace-service.js.map