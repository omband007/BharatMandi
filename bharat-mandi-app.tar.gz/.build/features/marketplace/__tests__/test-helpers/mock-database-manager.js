"use strict";
/**
 * Mock DatabaseManager for Marketplace Controller Tests
 *
 * Provides a mock DatabaseManager instance for testing
 * to enable isolated controller testing without real database operations.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createMockDatabaseManager = createMockDatabaseManager;
/**
 * Create mock DatabaseManager with required methods
 */
function createMockDatabaseManager() {
    return {
        start: jest.fn(),
        stop: jest.fn(),
        getPostgreSQLAdapter: jest.fn(),
        getConnectionMonitor: jest.fn(),
        isPostgreSQLConnected: jest.fn().mockReturnValue(true),
        getHealthStatus: jest.fn().mockReturnValue({
            postgresql: {
                connected: true,
                lastCheck: new Date()
            }
        })
    };
}
//# sourceMappingURL=mock-database-manager.js.map