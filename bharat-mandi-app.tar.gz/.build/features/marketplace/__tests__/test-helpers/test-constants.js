"use strict";
/**
 * Test Constants for Marketplace Controller Tests
 *
 * Provides constant values used across multiple test cases.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.INVALID_MIME_TYPES = exports.ALLOWED_MIME_TYPES = exports.TEST_PRODUCE_TYPES = exports.TEST_FARMER_IDS = exports.TEST_LISTING_IDS = void 0;
/**
 * Test listing IDs
 */
exports.TEST_LISTING_IDS = {
    VALID: 'test-listing-id',
    VALID_2: 'test-listing-id-2',
    NON_EXISTENT: 'non-existent-listing-id'
};
/**
 * Test farmer IDs
 */
exports.TEST_FARMER_IDS = {
    VALID: 'test-farmer-id',
    VALID_2: 'test-farmer-id-2'
};
/**
 * Test produce types
 */
exports.TEST_PRODUCE_TYPES = {
    TOMATOES: 'Tomatoes',
    CARROTS: 'Carrots',
    POTATOES: 'Potatoes',
    ONIONS: 'Onions',
    WHEAT: 'Wheat'
};
/**
 * Allowed MIME types for file uploads
 */
exports.ALLOWED_MIME_TYPES = [
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/webp',
    'video/mp4',
    'video/quicktime',
    'application/pdf'
];
/**
 * Invalid MIME types for file uploads
 */
exports.INVALID_MIME_TYPES = [
    'text/plain',
    'application/x-msdownload',
    'application/javascript',
    'text/html'
];
//# sourceMappingURL=test-constants.js.map