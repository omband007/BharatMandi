/**
 * Test Constants for Marketplace Controller Tests
 *
 * Provides constant values used across multiple test cases.
 */
/**
 * Test listing IDs
 */
export declare const TEST_LISTING_IDS: {
    VALID: string;
    VALID_2: string;
    NON_EXISTENT: string;
};
/**
 * Test farmer IDs
 */
export declare const TEST_FARMER_IDS: {
    VALID: string;
    VALID_2: string;
};
/**
 * Test produce types
 */
export declare const TEST_PRODUCE_TYPES: {
    TOMATOES: string;
    CARROTS: string;
    POTATOES: string;
    ONIONS: string;
    WHEAT: string;
};
/**
 * Allowed MIME types for file uploads
 */
export declare const ALLOWED_MIME_TYPES: string[];
/**
 * Invalid MIME types for file uploads
 */
export declare const INVALID_MIME_TYPES: string[];
//# sourceMappingURL=test-constants.d.ts.map