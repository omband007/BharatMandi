/**
 * Test Data Factories for Marketplace Controller Tests
 *
 * Provides factory functions to create test data objects with sensible defaults
 * and support for partial overrides.
 */
import type { Listing } from '../../marketplace.types';
import type { MediaUploadResponse } from '../../media.types';
/**
 * Create a test listing with default values
 */
export declare function createTestListing(overrides?: Partial<Listing>): Listing;
/**
 * Create a test listing request with default values
 */
export declare function createTestListingRequest(overrides?: Partial<{
    farmerId: string;
    produceType: string;
    quantity: number;
    pricePerKg: number;
    certificateId: string;
}>): {
    farmerId: string;
    produceType: string;
    quantity: number;
    pricePerKg: number;
    certificateId: string;
};
/**
 * Create a test media upload result with default values
 */
export declare function createTestMediaResult(overrides?: Partial<{
    fileName: string;
    success: boolean;
    mediaId: string;
    error?: string;
}>): {
    fileName: string;
    success: boolean;
    mediaId: string;
    error?: string;
};
/**
 * Create a test file object (Express.Multer.File)
 */
export declare function createTestFile(overrides?: Partial<Express.Multer.File>): Express.Multer.File;
/**
 * Create a test MediaUploadResponse with default values
 */
export declare function createTestMediaUploadResponse(overrides?: Partial<MediaUploadResponse>): MediaUploadResponse;
//# sourceMappingURL=test-data-factories.d.ts.map