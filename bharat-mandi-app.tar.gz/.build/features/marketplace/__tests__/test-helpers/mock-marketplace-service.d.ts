/**
 * Mock Marketplace Service Configuration
 *
 * Provides mock implementations for marketplace service and media service
 * to enable isolated controller testing.
 */
/**
 * Create mock marketplace service with all methods
 */
export declare function createMockMarketplaceService(): {
    createListing: jest.Mock<any, any, any>;
    getActiveListings: jest.Mock<any, any, any>;
    getListing: jest.Mock<any, any, any>;
};
/**
 * Create mock media service with all methods
 */
export declare function createMockMediaService(): {
    uploadMedia: jest.Mock<any, any, any>;
};
/**
 * Configure mock marketplace service with default success responses
 */
export declare function configureMockMarketplaceService(mockService: ReturnType<typeof createMockMarketplaceService>): void;
/**
 * Configure mock media service with default success responses
 */
export declare function configureMockMediaService(mockService: ReturnType<typeof createMockMediaService>): void;
//# sourceMappingURL=mock-marketplace-service.d.ts.map