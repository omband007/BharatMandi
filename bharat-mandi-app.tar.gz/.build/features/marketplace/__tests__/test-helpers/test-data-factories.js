"use strict";
/**
 * Test Data Factories for Marketplace Controller Tests
 *
 * Provides factory functions to create test data objects with sensible defaults
 * and support for partial overrides.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTestListing = createTestListing;
exports.createTestListingRequest = createTestListingRequest;
exports.createTestMediaResult = createTestMediaResult;
exports.createTestFile = createTestFile;
exports.createTestMediaUploadResponse = createTestMediaUploadResponse;
const marketplace_types_1 = require("../../marketplace.types");
/**
 * Create a test listing with default values
 */
function createTestListing(overrides) {
    return {
        id: 'test-listing-id',
        farmerId: 'test-farmer-id',
        produceType: 'Tomatoes',
        quantity: 100,
        pricePerKg: 50,
        certificateId: 'test-cert-id',
        createdAt: new Date('2024-01-01T00:00:00.000Z'),
        updatedAt: new Date('2024-01-01T00:00:00.000Z'),
        status: marketplace_types_1.ListingStatus.ACTIVE,
        listingType: marketplace_types_1.ListingType.POST_HARVEST,
        produceCategoryId: 'cat-1',
        expiryDate: new Date('2024-01-02T00:00:00.000Z'),
        paymentMethodPreference: marketplace_types_1.PaymentMethodPreference.BOTH,
        ...overrides
    };
}
/**
 * Create a test listing request with default values
 */
function createTestListingRequest(overrides) {
    return {
        farmerId: 'test-farmer-id',
        produceType: 'Tomatoes',
        quantity: 100,
        pricePerKg: 50,
        certificateId: 'test-cert-id',
        ...overrides
    };
}
/**
 * Create a test media upload result with default values
 */
function createTestMediaResult(overrides) {
    return {
        fileName: 'test-image.jpg',
        success: true,
        mediaId: 'test-media-id',
        ...overrides
    };
}
/**
 * Create a test file object (Express.Multer.File)
 */
function createTestFile(overrides) {
    return {
        fieldname: 'media',
        originalname: 'test-image.jpg',
        encoding: '7bit',
        mimetype: 'image/jpeg',
        buffer: Buffer.from('fake-image-data'),
        size: 1024,
        stream: null,
        destination: '',
        filename: '',
        path: '',
        ...overrides
    };
}
/**
 * Create a test MediaUploadResponse with default values
 */
function createTestMediaUploadResponse(overrides) {
    return {
        mediaId: 'test-media-id',
        storageUrl: 'https://storage.example.com/test-media-id.jpg',
        success: true,
        ...overrides
    };
}
//# sourceMappingURL=test-data-factories.js.map