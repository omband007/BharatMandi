import { DatabaseManager } from '../../shared/database/db-abstraction';
import { StorageService } from './storage.service';
import { ValidationService } from './validation.service';
import type { ListingMedia, MediaUploadRequest, MediaUploadResponse } from './media.types';
/**
 * Media Service
 *
 * Handles all media operations for marketplace listings including:
 * - Upload media (photos, videos, documents)
 * - Retrieve media for listings
 * - Delete media
 * - Reorder media
 * - Set primary media
 *
 * Integrates with:
 * - DatabaseManager for persistence
 * - StorageService for file storage (S3/local)
 * - ValidationService for file validation
 */
export declare class MediaService {
    private dbManager;
    private storageService;
    private validationService;
    constructor(dbManager: DatabaseManager, storageService: StorageService, validationService: ValidationService);
    /**
     * Upload media for a listing
     *
     * Requirements: 1.1, 1.2, 1.3, 1.5, 1.6, 1.7, 1.8
     *
     * @param request - Media upload request
     * @returns Upload response with media ID and URLs
     */
    uploadMedia(request: MediaUploadRequest): Promise<MediaUploadResponse>;
    /**
     * Get all media for a listing
     *
     * Requirements: 4.2, 4.3
     *
     * @param listingId - Listing ID
     * @returns Array of media items sorted by display order
     */
    getListingMedia(listingId: string): Promise<ListingMedia[]>;
    /**
     * Delete media from a listing
     *
     * Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.7
     *
     * @param listingId - Listing ID
     * @param mediaId - Media ID to delete
     * @param userId - User ID (for ownership verification)
     * @returns true if deleted successfully
     */
    deleteMedia(listingId: string, mediaId: string, userId: string): Promise<boolean>;
    /**
     * Reorder media for a listing
     *
     * Requirements: 8.1, 8.2, 8.5, 8.6
     *
     * @param listingId - Listing ID
     * @param mediaOrder - Array of media IDs in desired order
     * @param userId - User ID (for ownership verification)
     * @returns true if reordered successfully
     */
    reorderMedia(listingId: string, mediaOrder: string[], userId: string): Promise<boolean>;
    /**
     * Set primary media for a listing
     *
     * Requirements: 8.3, 8.4
     *
     * @param listingId - Listing ID
     * @param mediaId - Media ID to set as primary
     * @param userId - User ID (for ownership verification)
     * @returns true if set successfully
     */
    setPrimaryMedia(listingId: string, mediaId: string, userId: string): Promise<boolean>;
}
//# sourceMappingURL=media.service.d.ts.map