/**
 * Media Controller
 *
 * Handles HTTP requests for listing media operations:
 * - Upload media (photos, videos, documents)
 * - Get listing media
 * - Delete media
 * - Reorder media
 * - Set primary media
 */
export declare const mediaController: import("express-serve-static-core").Router;
//# sourceMappingURL=media.controller.d.ts.map