"use strict";
// Media validation constants
Object.defineProperty(exports, "__esModule", { value: true });
exports.RETRY_BACKOFF_MS = exports.MAX_RETRY_ATTEMPTS = exports.SIGNED_URL_EXPIRATION = exports.IMAGE_COMPRESSION_QUALITY = exports.THUMBNAIL_HEIGHT = exports.THUMBNAIL_WIDTH = exports.MIME_TO_MEDIA_TYPE = exports.FILE_EXTENSION_TO_MIME = exports.MAX_MEDIA_PER_LISTING = exports.MAX_FILE_SIZES = exports.ALLOWED_MIME_TYPES = void 0;
// Allowed MIME types for each media type
exports.ALLOWED_MIME_TYPES = {
    photo: ['image/jpeg', 'image/png', 'image/webp'],
    video: ['video/mp4', 'video/quicktime'],
    document: ['application/pdf']
};
// Maximum file sizes in bytes
exports.MAX_FILE_SIZES = {
    photo: 5 * 1024 * 1024, // 5MB
    video: 50 * 1024 * 1024, // 50MB
    document: 10 * 1024 * 1024 // 10MB
};
// Maximum media items per listing
exports.MAX_MEDIA_PER_LISTING = 10;
// File extension to MIME type mapping
exports.FILE_EXTENSION_TO_MIME = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.webp': 'image/webp',
    '.mp4': 'video/mp4',
    '.mov': 'video/quicktime',
    '.pdf': 'application/pdf'
};
// MIME type to media type mapping
exports.MIME_TO_MEDIA_TYPE = {
    'image/jpeg': 'photo',
    'image/png': 'photo',
    'image/webp': 'photo',
    'video/mp4': 'video',
    'video/quicktime': 'video',
    'application/pdf': 'document'
};
// Thumbnail dimensions
exports.THUMBNAIL_WIDTH = 200;
exports.THUMBNAIL_HEIGHT = 200;
// Image compression quality (0-100)
exports.IMAGE_COMPRESSION_QUALITY = 85;
// Signed URL expiration time (in seconds)
exports.SIGNED_URL_EXPIRATION = 3600; // 1 hour
// Retry configuration
exports.MAX_RETRY_ATTEMPTS = 3;
exports.RETRY_BACKOFF_MS = [2000, 4000, 8000]; // Exponential backoff
//# sourceMappingURL=media.constants.js.map