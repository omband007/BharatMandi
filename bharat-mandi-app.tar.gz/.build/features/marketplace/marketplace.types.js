"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SaleChannel = exports.PaymentMethodPreference = exports.ListingType = exports.ListingStatus = void 0;
var ListingStatus;
(function (ListingStatus) {
    ListingStatus["ACTIVE"] = "ACTIVE";
    ListingStatus["SOLD"] = "SOLD";
    ListingStatus["EXPIRED"] = "EXPIRED";
    ListingStatus["CANCELLED"] = "CANCELLED";
})(ListingStatus || (exports.ListingStatus = ListingStatus = {}));
var ListingType;
(function (ListingType) {
    ListingType["PRE_HARVEST"] = "PRE_HARVEST";
    ListingType["POST_HARVEST"] = "POST_HARVEST";
})(ListingType || (exports.ListingType = ListingType = {}));
var PaymentMethodPreference;
(function (PaymentMethodPreference) {
    PaymentMethodPreference["PLATFORM_ONLY"] = "PLATFORM_ONLY";
    PaymentMethodPreference["DIRECT_ONLY"] = "DIRECT_ONLY";
    PaymentMethodPreference["BOTH"] = "BOTH";
})(PaymentMethodPreference || (exports.PaymentMethodPreference = PaymentMethodPreference = {}));
var SaleChannel;
(function (SaleChannel) {
    SaleChannel["PLATFORM"] = "PLATFORM";
    SaleChannel["EXTERNAL"] = "EXTERNAL";
})(SaleChannel || (exports.SaleChannel = SaleChannel = {}));
//# sourceMappingURL=marketplace.types.js.map