import type { MediaType } from './media.types';
export interface ValidationResult {
    valid: boolean;
    error?: string;
}
export declare class ValidationService {
    /**
     * Validate media file
     * @param file - File buffer
     * @param fileName - Original file name
     * @param mimeType - File MIME type
     * @param mediaType - Expected media type
     * @returns Validation result
     */
    validateMediaFile(file: Buffer, fileName: string, mimeType: string, mediaType: MediaType): ValidationResult;
    /**
     * Validate file extension matches MIME type
     * @param fileName - File name
     * @param mimeType - MIME type
     * @returns Validation result
     */
    validateFileExtension(fileName: string, mimeType: string): ValidationResult;
    /**
     * Validate MIME type for media type
     * @param mimeType - MIME type
     * @param mediaType - Media type
     * @returns Validation result
     */
    validateMimeType(mimeType: string, mediaType: MediaType): ValidationResult;
    /**
     * Validate file size
     * @param fileSize - File size in bytes
     * @param mediaType - Media type
     * @returns Validation result
     */
    validateFileSize(fileSize: number, mediaType: MediaType): ValidationResult;
    /**
     * Detect media type from MIME type
     * @param mimeType - MIME type
     * @returns Media type or undefined
     */
    detectMediaType(mimeType: string): MediaType | undefined;
    /**
     * Detect media type from file extension
     * @param fileName - File name
     * @returns Media type or undefined
     */
    detectMediaTypeFromExtension(fileName: string): MediaType | undefined;
    /**
     * Get human-readable error message for validation
     * @param error - Error message
     * @returns User-friendly error message
     */
    getUserFriendlyError(error: string): string;
}
export declare const validationService: ValidationService;
//# sourceMappingURL=validation.service.d.ts.map