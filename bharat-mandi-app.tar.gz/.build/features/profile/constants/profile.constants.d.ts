/**
 * Profile Management Constants
 *
 * Business logic constants for profile completeness, points, tiers, and trust scores.
 */
export declare const PROFILE_FIELD_WEIGHTS: {
    readonly mobileNumber: 10;
    readonly name: 10;
    readonly location: 10;
    readonly userType: 10;
    readonly cropsGrown: 20;
    readonly languagePreference: 10;
    readonly farmSize: 10;
    readonly bankAccount: 10;
    readonly profilePicture: 10;
};
export declare const POINTS_RULES: {
    readonly PROFILE_COMPLETE_100: 50;
    readonly CREATE_LISTING: 10;
    readonly CHECK_WEATHER: 5;
    readonly QUERY_CROP_PRICE: 5;
    readonly REQUEST_FARMING_ADVICE: 5;
    readonly COMPLETE_TRANSACTION: 20;
    readonly UPLOAD_CROP_PHOTO: 15;
    readonly DAILY_STREAK: 10;
    readonly REFERRAL_REGISTRATION: 100;
    readonly REFERRAL_FIRST_TRANSACTION: 200;
};
export declare const DAILY_LIMITS: {
    readonly CREATE_LISTING: 3;
    readonly CHECK_WEATHER: 5;
    readonly QUERY_CROP_PRICE: 5;
    readonly REQUEST_FARMING_ADVICE: 5;
    readonly UPLOAD_CROP_PHOTO: 3;
    readonly DAILY_CAP: 200;
};
export declare const TIER_THRESHOLDS: {
    readonly BRONZE: 0;
    readonly SILVER: 500;
    readonly GOLD: 2000;
    readonly PLATINUM: 5000;
};
export declare const TRUST_SCORE_RULES: {
    readonly INITIAL: 50;
    readonly MIN: 0;
    readonly MAX: 100;
    readonly POSITIVE_EVENTS: {
        readonly PROFILE_COMPLETE_100: 5;
        readonly VERIFY_LOCATION_GPS: 3;
        readonly COMPLETE_TRANSACTION: 2;
        readonly RECEIVE_POSITIVE_FEEDBACK: 5;
    };
    readonly NEGATIVE_EVENTS: {
        readonly RECEIVE_NEGATIVE_FEEDBACK: -10;
        readonly CANCEL_TRANSACTION: -15;
        readonly DISPUTE_RAISED: -20;
    };
    readonly RANGES: {
        readonly LOW: {
            readonly min: 0;
            readonly max: 40;
        };
        readonly MEDIUM: {
            readonly min: 41;
            readonly max: 70;
        };
        readonly HIGH: {
            readonly min: 71;
            readonly max: 85;
        };
        readonly EXCELLENT: {
            readonly min: 86;
            readonly max: 100;
        };
    };
};
export declare const FIELD_PRIORITY: {
    readonly location: 100;
    readonly name: 90;
    readonly userType: 85;
    readonly cropsGrown: 80;
    readonly languagePreference: 70;
    readonly farmSize: 60;
    readonly profilePicture: 50;
    readonly bankAccount: 40;
};
export declare const PROMPT_LIMITS: {
    readonly MAX_DISMISSALS: 3;
    readonly DISMISSAL_COOLDOWN_HOURS: 24;
    readonly MIN_PROMPT_INTERVAL_MINUTES: 5;
    readonly MAX_PROMPTS_PER_SESSION: 1;
};
export declare const VALIDATION_RULES: {
    readonly MOBILE_NUMBER: {
        readonly LENGTH: 10;
        readonly PATTERN: RegExp;
    };
    readonly NAME: {
        readonly MIN_LENGTH: 2;
        readonly MAX_LENGTH: 100;
        readonly PATTERN: RegExp;
    };
    readonly FARM_SIZE: {
        readonly MIN: 0.1;
        readonly MAX: 10000;
    };
    readonly PROFILE_PICTURE: {
        readonly MAX_SIZE_MB: 5;
        readonly ALLOWED_FORMATS: readonly ["image/jpeg", "image/png", "image/webp"];
        readonly DIMENSIONS: {
            readonly FULL: {
                readonly width: 400;
                readonly height: 400;
            };
            readonly THUMBNAIL: {
                readonly width: 100;
                readonly height: 100;
            };
        };
    };
    readonly REFERRAL_CODE: {
        readonly LENGTH: 8;
        readonly PATTERN: RegExp;
    };
};
export declare const SUPPORTED_LANGUAGES: readonly ["en", "hi", "pa", "bn", "te", "mr", "ta", "gu", "kn", "ml", "or"];
export declare const DEFAULT_PRIVACY_SETTINGS: {
    readonly name: "platform_only";
    readonly location: "platform_only";
    readonly userType: "platform_only";
    readonly cropsGrown: "platform_only";
    readonly farmSize: "platform_only";
    readonly languagePreference: "platform_only";
    readonly bankAccount: "private";
    readonly profilePicture: "public";
};
export declare const REDEMPTION_CATALOG: {
    readonly FEATURED_LISTING_24H: {
        readonly pointsCost: 500;
        readonly duration: number;
    };
    readonly TRANSACTION_FEE_WAIVER: {
        readonly pointsCost: 2000;
        readonly uses: 1;
    };
    readonly PRIORITY_SUPPORT_30D: {
        readonly pointsCost: 3000;
        readonly duration: number;
    };
};
//# sourceMappingURL=profile.constants.d.ts.map