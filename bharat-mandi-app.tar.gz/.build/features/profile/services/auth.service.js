"use strict";
/**
 * Authentication Service
 *
 * Handles PIN/biometric authentication, JWT token management, and account security.
 *
 * MIGRATED FROM: src/features/auth/auth.service.ts
 * ADAPTED FOR: UserProfile model (comprehensive profile data)
 * CHANGES:
 * - User → UserProfile type
 * - JWT expiration: 7d → 30d
 * - Uses UserProfileModel instead of DatabaseManager
 * - Account lockout uses profile fields (failedLoginAttempts, lockedUntil)
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupPIN = setupPIN;
exports.changePIN = changePIN;
exports.loginWithPIN = loginWithPIN;
exports.loginWithBiometric = loginWithBiometric;
exports.loginWithOTP = loginWithOTP;
exports.generateToken = generateToken;
exports.verifyToken = verifyToken;
exports.refreshToken = refreshToken;
exports.isAccountLocked = isAccountLocked;
exports.handleFailedLogin = handleFailedLogin;
exports.handleSuccessfulLogin = handleSuccessfulLogin;
exports.enableBiometric = enableBiometric;
exports.disableBiometric = disableBiometric;
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const profile_sequelize_model_1 = require("../models/profile.sequelize.model");
const otpHelpers = __importStar(require("../../../shared/database/otp-helpers"));
// JWT Configuration
const JWT_SECRET = process.env.JWT_SECRET || 'bharat-mandi-secret-key-change-in-production';
const JWT_EXPIRY = '30d'; // 30 days (per unified spec - Requirement 8.9, 12.2)
// Account Lockout Configuration (per Requirement 24A)
const LOCKOUT_RULES = {
    MAX_FAILED_ATTEMPTS: 3,
    LOCKOUT_DURATION_MINUTES: 30,
    RESET_ON_SUCCESS: true,
    ALLOW_OTP_WHEN_LOCKED: true // For account recovery
};
// ============================================================================
// PIN MANAGEMENT
// ============================================================================
/**
 * Setup PIN for a user
 * Requirement 6: Optional PIN Setup
 */
async function setupPIN(userId, pin, confirmPin) {
    try {
        // Validate PIN format (4-6 digits)
        const pinRegex = /^\d{4,6}$/;
        if (!pinRegex.test(pin)) {
            return { success: false, message: 'PIN must be 4-6 digits' };
        }
        // Validate PIN confirmation
        if (pin !== confirmPin) {
            return { success: false, message: 'PIN and confirmation do not match' };
        }
        // Get user profile
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            return { success: false, message: 'Profile not found' };
        }
        // Check if PIN is already set
        if (profile.pinHash) {
            return { success: false, message: 'PIN already set. Use change PIN to update.' };
        }
        // Hash the PIN (bcrypt with salt rounds: 10)
        const pinHash = await bcrypt_1.default.hash(pin, 10);
        // Update profile with PIN hash
        profile.pinHash = pinHash;
        profile.updatedAt = new Date();
        await profile.save();
        return { success: true, message: 'PIN set up successfully' };
    }
    catch (error) {
        console.error('[AuthService] Error setting up PIN:', error);
        return { success: false, message: 'Failed to set up PIN' };
    }
}
/**
 * Change PIN for a user (requires OTP verification first)
 * Requirement 23: Password Reset (PIN Reset)
 */
async function changePIN(userId, newPin, confirmNewPin) {
    try {
        // Validate new PIN format
        const pinRegex = /^\d{4,6}$/;
        if (!pinRegex.test(newPin)) {
            return { success: false, message: 'New PIN must be 4-6 digits' };
        }
        // Validate PIN confirmation
        if (newPin !== confirmNewPin) {
            return { success: false, message: 'New PIN and confirmation do not match' };
        }
        // Get user profile
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            return { success: false, message: 'Profile not found' };
        }
        // Hash the new PIN
        const pinHash = await bcrypt_1.default.hash(newPin, 10);
        // Update profile with new PIN hash
        profile.pinHash = pinHash;
        profile.updatedAt = new Date();
        await profile.save();
        // Log PIN change event for security audit
        console.log(`[AuthService] PIN changed for user ${userId}`);
        return { success: true, message: 'PIN changed successfully' };
    }
    catch (error) {
        console.error('[AuthService] Error changing PIN:', error);
        return { success: false, message: 'Failed to change PIN' };
    }
}
// ============================================================================
// AUTHENTICATION
// ============================================================================
/**
 * Login with PIN
 * Requirements: 10 (PIN Login), 24A (Account Lockout Protection)
 */
async function loginWithPIN(mobileNumber, pin) {
    try {
        // Get user profile by mobile number
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { mobileNumber } });
        if (!profile) {
            return { success: false, message: 'User not found' };
        }
        // Check if account is locked (Requirement 24A.3)
        if (isAccountLocked(profile)) {
            const remainingMinutes = Math.ceil((profile.lockedUntil.getTime() - Date.now()) / 60000);
            return {
                success: false,
                message: `Account is locked. Try again in ${remainingMinutes} minutes or use OTP login.`
            };
        }
        // Check if PIN is set
        if (!profile.pinHash) {
            return { success: false, message: 'PIN not set up. Please set up your PIN first.' };
        }
        // Verify PIN
        const pinValid = await bcrypt_1.default.compare(pin, profile.pinHash);
        if (!pinValid) {
            // Handle failed login attempt
            await handleFailedLogin(profile.userId, 'pin');
            const attemptsRemaining = LOCKOUT_RULES.MAX_FAILED_ATTEMPTS - (profile.failedLoginAttempts + 1);
            if (attemptsRemaining <= 0) {
                return {
                    success: false,
                    message: 'Too many failed attempts. Account locked for 30 minutes.'
                };
            }
            return {
                success: false,
                message: `Invalid PIN. ${attemptsRemaining} attempts remaining.`
            };
        }
        // PIN is valid - handle successful login
        await handleSuccessfulLogin(profile.userId);
        // Generate JWT token
        const token = generateToken(profile);
        // Convert profile to plain object for response
        const profileObj = profile.toJSON();
        // Remove sensitive fields
        delete profileObj.pinHash;
        return {
            success: true,
            token,
            profile: profileObj,
            message: 'Login successful'
        };
    }
    catch (error) {
        console.error('[AuthService] Error during PIN login:', error);
        return { success: false, message: 'Login failed' };
    }
}
/**
 * Login with biometric authentication
 * Requirements: 11 (Biometric Login), 24A (Account Lockout Protection)
 *
 * Note: This requires the mobile app to first verify biometric locally,
 * then call this endpoint with the mobile number
 */
async function loginWithBiometric(mobileNumber) {
    try {
        // Get user profile by mobile number
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { mobileNumber } });
        if (!profile) {
            return { success: false, message: 'User not found' };
        }
        // Check if biometric is enabled
        if (!profile.biometricEnabled) {
            return {
                success: false,
                message: 'Biometric authentication not enabled. Please enable it in settings.'
            };
        }
        // Check if account is locked (Requirement 24A.3)
        if (isAccountLocked(profile)) {
            const remainingMinutes = Math.ceil((profile.lockedUntil.getTime() - Date.now()) / 60000);
            return {
                success: false,
                message: `Account is locked. Try again in ${remainingMinutes} minutes or use OTP login.`
            };
        }
        // Biometric verification happens on device - if we reach here, it succeeded
        // Handle successful login
        await handleSuccessfulLogin(profile.userId);
        // Generate JWT token
        const token = generateToken(profile);
        // Convert profile to plain object for response
        const profileObj = profile.toJSON();
        // Remove sensitive fields
        delete profileObj.pinHash;
        return {
            success: true,
            token,
            profile: profileObj,
            message: 'Biometric login successful'
        };
    }
    catch (error) {
        console.error('[AuthService] Error during biometric login:', error);
        return { success: false, message: 'Biometric login failed' };
    }
}
/**
 * Login with OTP (for existing users)
 * Always available, even when account is locked (account recovery)
 * Requirements: 9.1-9.7, 24A.8
 */
async function loginWithOTP(mobileNumber, otp) {
    try {
        // Get OTP session
        const session = await otpHelpers.getOTPSession(mobileNumber);
        if (!session) {
            return {
                success: false,
                message: 'OTP session not found or expired'
            };
        }
        // Check if OTP has expired
        if (new Date() > session.expiresAt) {
            await otpHelpers.deleteOTPSession(session.phoneNumber);
            return {
                success: false,
                message: 'OTP has expired. Please request a new one'
            };
        }
        // Check attempts
        if (session.attempts >= 3) {
            await otpHelpers.deleteOTPSession(session.phoneNumber);
            return {
                success: false,
                message: 'Maximum OTP attempts exceeded. Please request a new OTP'
            };
        }
        // Verify OTP
        if (session.otp !== otp) {
            // Increment attempts
            await otpHelpers.updateOTPAttempts(session.phoneNumber, session.attempts + 1);
            return {
                success: false,
                message: 'Invalid OTP'
            };
        }
        // OTP verified - get user profile
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { mobileNumber } });
        if (!profile) {
            await otpHelpers.deleteOTPSession(session.phoneNumber);
            return {
                success: false,
                message: 'User not found. Please register first'
            };
        }
        // Delete OTP session
        await otpHelpers.deleteOTPSession(session.phoneNumber);
        // Reset failed login attempts and unlock account (OTP login bypasses lockout)
        await handleSuccessfulLogin(profile.userId);
        // Generate JWT token
        const token = generateToken(profile);
        return {
            success: true,
            token,
            profile: profile.toJSON(),
            message: 'OTP login successful'
        };
    }
    catch (error) {
        console.error('[AuthService] OTP login error:', error);
        return {
            success: false,
            message: error instanceof Error ? error.message : 'OTP login failed'
        };
    }
}
// ============================================================================
// JWT TOKEN MANAGEMENT
// ============================================================================
/**
 * Generate JWT token for authenticated user
 * Requirement 12: Session Management
 */
function generateToken(profile) {
    const payload = {
        userId: profile.userId,
        mobileNumber: profile.mobileNumber,
        name: profile.name || undefined
    };
    return jsonwebtoken_1.default.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRY });
}
/**
 * Verify JWT token
 * Requirement 12.4: Validate tokens on protected API endpoints
 */
function verifyToken(token) {
    try {
        const decoded = jsonwebtoken_1.default.verify(token, JWT_SECRET);
        return {
            valid: true,
            payload: decoded
        };
    }
    catch (error) {
        return { valid: false };
    }
}
/**
 * Refresh JWT token
 * Requirement 12.5: Refresh tokens automatically before expiration
 */
function refreshToken(currentToken) {
    try {
        const verification = verifyToken(currentToken);
        if (!verification.valid || !verification.payload) {
            return { success: false, message: 'Invalid token' };
        }
        // Generate new token with same payload
        const newToken = jsonwebtoken_1.default.sign(verification.payload, JWT_SECRET, { expiresIn: JWT_EXPIRY });
        return {
            success: true,
            token: newToken,
            message: 'Token refreshed successfully'
        };
    }
    catch (error) {
        console.error('[AuthService] Error refreshing token:', error);
        return { success: false, message: 'Failed to refresh token' };
    }
}
// ============================================================================
// ACCOUNT SECURITY
// ============================================================================
/**
 * Check if account is locked
 * Requirement 24A.4: Auto-unlock after lockout period
 */
function isAccountLocked(profile) {
    if (!profile.lockedUntil) {
        return false;
    }
    // Check if lockout period has expired (auto-unlock)
    if (new Date() > profile.lockedUntil) {
        return false;
    }
    return true;
}
/**
 * Handle failed login attempt
 * Requirement 24A: Account Lockout Protection
 */
async function handleFailedLogin(userId, method) {
    try {
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            throw new Error('Profile not found');
        }
        // Increment failed attempts (Requirement 24A.1, 24A.2)
        profile.failedLoginAttempts += 1;
        // Check if lockout threshold reached
        if (profile.failedLoginAttempts >= LOCKOUT_RULES.MAX_FAILED_ATTEMPTS) {
            // Lock account for 30 minutes (Requirement 24A.1, 24A.2)
            const lockoutUntil = new Date(Date.now() + LOCKOUT_RULES.LOCKOUT_DURATION_MINUTES * 60 * 1000);
            profile.lockedUntil = lockoutUntil;
            // Log security event (Requirement 24A.9)
            console.log(`[AuthService] Account locked for user ${userId} due to ${LOCKOUT_RULES.MAX_FAILED_ATTEMPTS} failed ${method} attempts`);
            // TODO: Send SMS notification (Requirement 24A.10)
            // await sendSMS(profile.mobileNumber, 
            //   `Your account has been locked for ${LOCKOUT_RULES.LOCKOUT_DURATION_MINUTES} minutes due to multiple failed login attempts.`
            // );
        }
        profile.updatedAt = new Date();
        await profile.save();
    }
    catch (error) {
        console.error('[AuthService] Error handling failed login:', error);
    }
}
/**
 * Handle successful login
 * Requirement 24A.5: Reset failed attempt counter on successful login
 */
async function handleSuccessfulLogin(userId) {
    try {
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            throw new Error('Profile not found');
        }
        // Reset failed attempts counter (Requirement 24A.5)
        if (LOCKOUT_RULES.RESET_ON_SUCCESS) {
            profile.failedLoginAttempts = 0;
            profile.lockedUntil = undefined;
        }
        // Update last login timestamp (Requirement 12.8)
        profile.lastLoginAt = new Date();
        profile.lastActiveAt = new Date();
        await profile.save();
    }
    catch (error) {
        console.error('[AuthService] Error handling successful login:', error);
    }
}
/**
 * Enable biometric authentication for a user
 * Requirement 7: Optional Biometric Setup
 */
async function enableBiometric(userId) {
    try {
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            return { success: false, message: 'Profile not found' };
        }
        profile.biometricEnabled = true;
        profile.updatedAt = new Date();
        await profile.save();
        return { success: true, message: 'Biometric authentication enabled' };
    }
    catch (error) {
        console.error('[AuthService] Error enabling biometric:', error);
        return { success: false, message: 'Failed to enable biometric authentication' };
    }
}
/**
 * Disable biometric authentication for a user
 * Requirement 7.7: Allow users to disable biometric authentication
 */
async function disableBiometric(userId) {
    try {
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            return { success: false, message: 'Profile not found' };
        }
        profile.biometricEnabled = false;
        profile.updatedAt = new Date();
        await profile.save();
        return { success: true, message: 'Biometric authentication disabled' };
    }
    catch (error) {
        console.error('[AuthService] Error disabling biometric:', error);
        return { success: false, message: 'Failed to disable biometric authentication' };
    }
}
//# sourceMappingURL=auth.service.js.map