/**
 * Profile Manager Service
 *
 * Core service for profile CRUD operations, completeness calculation,
 * and privacy settings management.
 */
import type { UserProfile, UpdateProfileFieldResponse, PrivacyLevel } from '../types/profile.types';
export declare class ProfileManagerService {
    private cacheService;
    constructor();
    /**
     * Get user profile by userId (with caching)
     */
    getProfile(userId: string): Promise<UserProfile | null>;
    /**
     * Update a single profile field
     */
    updateProfileField(userId: string, fieldName: string, value: any): Promise<UpdateProfileFieldResponse>;
    /**
     * Calculate profile completion percentage
     */
    calculateCompletionPercentage(profile: UserProfile): number;
    /**
     * Export profile data as JSON
     */
    exportProfileData(userId: string): Promise<any>;
    /**
     * Update privacy setting for a field
     */
    updatePrivacySetting(userId: string, fieldName: string, privacyLevel: PrivacyLevel): Promise<boolean>;
    /**
     * Get privacy setting for a field
     */
    getPrivacySetting(userId: string, fieldName: string): Promise<PrivacyLevel>;
    /**
     * Apply privacy filters to profile data
     */
    applyPrivacyFilters(profile: UserProfile, viewerContext: 'self' | 'public' | 'platform'): Partial<UserProfile>;
    /**
     * Delete user profile (mark for deletion)
     */
    deleteProfile(userId: string): Promise<boolean>;
    /**
     * Update last active timestamp
     */
    updateLastActive(userId: string): Promise<void>;
}
//# sourceMappingURL=profile-manager.service.d.ts.map