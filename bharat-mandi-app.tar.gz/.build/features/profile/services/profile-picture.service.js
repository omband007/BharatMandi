"use strict";
/**
 * Profile Picture Service
 *
 * Handles profile picture upload, processing, and storage.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProfilePictureService = void 0;
const uuid_1 = require("uuid");
const sharp_1 = __importDefault(require("sharp"));
const profile_sequelize_model_1 = require("../models/profile.sequelize.model");
const contextual_prompt_service_1 = require("./contextual-prompt.service");
const validators_1 = require("../utils/validators");
const profile_constants_1 = require("../constants/profile.constants");
class ProfilePictureService {
    constructor() {
        this.promptService = new contextual_prompt_service_1.ContextualPromptService();
        // In production, this would be S3 bucket or Cloudinary URL
        this.storageBasePath = process.env.PROFILE_PICTURE_STORAGE_PATH || '/uploads/profile-pictures';
    }
    /**
     * Upload and process profile picture
     */
    async uploadProfilePicture(userId, fileBuffer, mimeType, originalSize) {
        // Validate file
        const validation = (0, validators_1.validateProfilePicture)({
            size: originalSize,
            mimetype: mimeType
        });
        if (!validation.valid) {
            throw new Error(validation.error);
        }
        // Check content moderation
        const isSafe = await this.moderateContent(fileBuffer);
        if (!isSafe) {
            throw new Error('Profile picture contains inappropriate content');
        }
        // Generate unique filename
        const fileId = (0, uuid_1.v4)();
        const extension = this.getExtensionFromMimeType(mimeType);
        // Process images
        const fullImagePath = await this.resizeAndSave(fileBuffer, fileId, extension, profile_constants_1.VALIDATION_RULES.PROFILE_PICTURE.DIMENSIONS.FULL.width, profile_constants_1.VALIDATION_RULES.PROFILE_PICTURE.DIMENSIONS.FULL.height);
        const thumbnailPath = await this.resizeAndSave(fileBuffer, `${fileId}_thumb`, extension, profile_constants_1.VALIDATION_RULES.PROFILE_PICTURE.DIMENSIONS.THUMBNAIL.width, profile_constants_1.VALIDATION_RULES.PROFILE_PICTURE.DIMENSIONS.THUMBNAIL.height);
        // Create profile picture object
        const profilePicture = {
            url: fullImagePath,
            thumbnailUrl: thumbnailPath,
            uploadedAt: new Date()
        };
        // Update profile
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            throw new Error('Profile not found');
        }
        // Delete old profile picture if exists
        if (profile.profilePicture) {
            await this.deleteStoredImages(profile.profilePicture);
        }
        profile.profilePicture = profilePicture;
        profile.updatedAt = new Date();
        await profile.save();
        // Record collection
        await this.promptService.recordFieldCollected(userId, 'profilePicture', 'manual_edit');
        return profilePicture;
    }
    /**
     * Resize and save image
     */
    async resizeAndSave(buffer, fileId, extension, width, height) {
        const filename = `${fileId}.${extension}`;
        const filepath = `${this.storageBasePath}/${filename}`;
        // Resize image using sharp
        const resizedBuffer = await (0, sharp_1.default)(buffer)
            .resize(width, height, {
            fit: 'cover',
            position: 'center'
        })
            .toFormat(extension === 'png' ? 'png' : 'jpeg', {
            quality: 85
        })
            .toBuffer();
        // In production, upload to S3 or Cloudinary
        // For now, just return the path
        // Example with S3:
        // await s3Client.putObject({
        //   Bucket: process.env.S3_BUCKET,
        //   Key: filepath,
        //   Body: resizedBuffer,
        //   ContentType: `image/${extension}`
        // });
        console.log(`[ProfilePicture] Saved ${width}x${height} image: ${filepath}`);
        return filepath;
    }
    /**
     * Moderate content using AWS Rekognition or similar
     */
    async moderateContent(buffer) {
        // TODO: Integrate with AWS Rekognition or Clarifai
        // For now, just return true (safe)
        console.log('[ProfilePicture] Content moderation check (placeholder)');
        // Example with AWS Rekognition:
        // const rekognition = new AWS.Rekognition();
        // const result = await rekognition.detectModerationLabels({
        //   Image: { Bytes: buffer },
        //   MinConfidence: 60
        // }).promise();
        //
        // const unsafeLabels = result.ModerationLabels?.filter(
        //   label => label.Confidence && label.Confidence > 60
        // );
        //
        // return !unsafeLabels || unsafeLabels.length === 0;
        return true;
    }
    /**
     * Get file extension from MIME type
     */
    getExtensionFromMimeType(mimeType) {
        const map = {
            'image/jpeg': 'jpg',
            'image/png': 'png',
            'image/webp': 'webp'
        };
        return map[mimeType] || 'jpg';
    }
    /**
     * Delete stored images
     */
    async deleteStoredImages(profilePicture) {
        // In production, delete from S3 or Cloudinary
        console.log(`[ProfilePicture] Deleting images: ${profilePicture.url}, ${profilePicture.thumbnailUrl}`);
        // Example with S3:
        // await s3Client.deleteObject({
        //   Bucket: process.env.S3_BUCKET,
        //   Key: profilePicture.url
        // });
        // await s3Client.deleteObject({
        //   Bucket: process.env.S3_BUCKET,
        //   Key: profilePicture.thumbnailUrl
        // });
    }
    /**
     * Remove profile picture
     */
    async removeProfilePicture(userId) {
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            throw new Error('Profile not found');
        }
        if (!profile.profilePicture) {
            return false; // No picture to remove
        }
        // Delete stored images
        await this.deleteStoredImages(profile.profilePicture);
        // Remove from profile
        profile.profilePicture = undefined;
        profile.updatedAt = new Date();
        await profile.save();
        return true;
    }
    /**
     * Get profile picture
     */
    async getProfilePicture(userId) {
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        return profile?.profilePicture || null;
    }
    /**
     * Get default avatar URL
     */
    getDefaultAvatar() {
        return '/assets/default-avatar.png';
    }
}
exports.ProfilePictureService = ProfilePictureService;
//# sourceMappingURL=profile-picture.service.js.map