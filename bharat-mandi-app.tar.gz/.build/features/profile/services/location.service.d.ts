/**
 * Location Service
 *
 * Handles location capture (GPS/manual) and geocoding.
 */
import type { Location } from '../types/profile.types';
export declare class LocationService {
    private promptService;
    constructor();
    /**
     * Capture GPS location
     */
    captureGPSLocation(userId: string, latitude: number, longitude: number, accuracy?: number): Promise<boolean>;
    /**
     * Capture manual location
     */
    captureManualLocation(userId: string, locationData: {
        addressLine1?: string;
        addressLine2?: string;
        city?: string;
        district?: string;
        state?: string;
        pincode?: string;
    }): Promise<boolean>;
    /**
     * Reverse geocode coordinates to address
     * TODO: Integrate with OpenStreetMap Nominatim or Google Maps API
     */
    private reverseGeocode;
    /**
     * Geocode address to coordinates
     * TODO: Integrate with OpenStreetMap Nominatim or Google Maps API
     */
    private geocodeAddress;
    /**
     * Update location
     */
    updateLocation(userId: string, location: Partial<Location>): Promise<boolean>;
    /**
     * Get user location
     */
    getLocation(userId: string): Promise<Location | null>;
}
//# sourceMappingURL=location.service.d.ts.map