/**
 * Profile Cache Service
 *
 * Redis caching layer for profile data to improve performance.
 */
import type { UserProfile } from '../types/profile.types';
export declare class ProfileCacheService {
    private readonly PROFILE_TTL;
    private readonly COMPLETION_TTL;
    private readonly POINTS_TTL;
    /**
     * Get cache key for profile
     */
    private getProfileKey;
    /**
     * Get cache key for completion percentage
     */
    private getCompletionKey;
    /**
     * Get cache key for points balance
     */
    private getPointsKey;
    /**
     * Cache profile data
     */
    cacheProfile(userId: string, profile: UserProfile): Promise<void>;
    /**
     * Get cached profile
     */
    getCachedProfile(userId: string): Promise<UserProfile | null>;
    /**
     * Invalidate profile cache
     */
    invalidateProfile(userId: string): Promise<void>;
    /**
     * Cache completion percentage
     */
    cacheCompletion(userId: string, percentage: number): Promise<void>;
    /**
     * Get cached completion percentage
     */
    getCachedCompletion(userId: string): Promise<number | null>;
    /**
     * Cache points balance
     */
    cachePoints(userId: string, points: {
        current: number;
        lifetime: number;
    }): Promise<void>;
    /**
     * Get cached points balance
     */
    getCachedPoints(userId: string): Promise<{
        current: number;
        lifetime: number;
    } | null>;
    /**
     * Invalidate points cache
     */
    invalidatePoints(userId: string): Promise<void>;
}
//# sourceMappingURL=profile-cache.service.d.ts.map