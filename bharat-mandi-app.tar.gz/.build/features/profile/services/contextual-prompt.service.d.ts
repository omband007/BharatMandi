/**
 * Contextual Prompt Engine
 *
 * Determines when and what profile data to request based on user interactions.
 */
export interface PromptOpportunity {
    fieldName: string;
    priority: number;
    reason: string;
    shouldPrompt: boolean;
}
export declare class ContextualPromptService {
    /**
     * Identify the highest priority missing field to prompt for
     */
    identifyPromptOpportunity(userId: string, interactionContext?: string): Promise<PromptOpportunity | null>;
    /**
     * Get missing profile fields
     */
    private getMissingFields;
    /**
     * Get field priority
     */
    private getFieldPriority;
    /**
     * Get prompt reason based on field and context
     */
    private getPromptReason;
    /**
     * Check if field is eligible for prompting
     */
    private isFieldEligibleForPrompt;
    /**
     * Check if user can receive a prompt now (timing check)
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    canPromptNow(userId: string): Promise<boolean>;
    /**
     * Record that a prompt was shown
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    recordPromptShown(userId: string, fieldName: string): Promise<void>;
    /**
     * Record that a prompt was dismissed
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    recordPromptDismissed(userId: string, fieldName: string): Promise<void>;
    /**
     * Record that a field was collected
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    recordFieldCollected(userId: string, fieldName: string, source: 'explicit_prompt' | 'implicit_update' | 'manual_edit' | 'import'): Promise<void>;
    /**
     * Get prompt statistics for a user
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    getPromptStats(userId: string): Promise<any>;
}
//# sourceMappingURL=contextual-prompt.service.d.ts.map