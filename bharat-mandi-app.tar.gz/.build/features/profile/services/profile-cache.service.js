"use strict";
/**
 * Profile Cache Service
 *
 * Redis caching layer for profile data to improve performance.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProfileCacheService = void 0;
const redis_client_1 = require("../../../shared/cache/redis-client");
// Logging control
const VERBOSE_LOGGING = process.env.DB_VERBOSE_LOGGING === 'true';
class ProfileCacheService {
    constructor() {
        this.PROFILE_TTL = 5 * 60; // 5 minutes
        this.COMPLETION_TTL = 5 * 60; // 5 minutes
        this.POINTS_TTL = 1 * 60; // 1 minute
    }
    /**
     * Get cache key for profile
     */
    getProfileKey(userId) {
        return `profile:${userId}`;
    }
    /**
     * Get cache key for completion percentage
     */
    getCompletionKey(userId) {
        return `profile:completion:${userId}`;
    }
    /**
     * Get cache key for points balance
     */
    getPointsKey(userId) {
        return `profile:points:${userId}`;
    }
    /**
     * Cache profile data
     */
    async cacheProfile(userId, profile) {
        try {
            const redis = (0, redis_client_1.getRedisClient)();
            const key = this.getProfileKey(userId);
            await redis.setEx(key, this.PROFILE_TTL, JSON.stringify(profile));
        }
        catch (error) {
            if (VERBOSE_LOGGING) {
                console.error('[ProfileCache] Failed to cache profile:', error);
            }
            // Don't throw - caching is optional
        }
    }
    /**
     * Get cached profile
     */
    async getCachedProfile(userId) {
        try {
            const redis = (0, redis_client_1.getRedisClient)();
            const key = this.getProfileKey(userId);
            const cached = await redis.get(key);
            return cached ? JSON.parse(cached) : null;
        }
        catch (error) {
            if (VERBOSE_LOGGING) {
                console.error('[ProfileCache] Failed to get cached profile:', error);
            }
            return null;
        }
    }
    /**
     * Invalidate profile cache
     */
    async invalidateProfile(userId) {
        try {
            const redis = (0, redis_client_1.getRedisClient)();
            await redis.del(this.getProfileKey(userId));
            await redis.del(this.getCompletionKey(userId));
        }
        catch (error) {
            if (VERBOSE_LOGGING) {
                console.error('[ProfileCache] Failed to invalidate profile:', error);
            }
        }
    }
    /**
     * Cache completion percentage
     */
    async cacheCompletion(userId, percentage) {
        try {
            const redis = (0, redis_client_1.getRedisClient)();
            const key = this.getCompletionKey(userId);
            await redis.setEx(key, this.COMPLETION_TTL, percentage.toString());
        }
        catch (error) {
            if (VERBOSE_LOGGING) {
                console.error('[ProfileCache] Failed to cache completion:', error);
            }
        }
    }
    /**
     * Get cached completion percentage
     */
    async getCachedCompletion(userId) {
        try {
            const redis = (0, redis_client_1.getRedisClient)();
            const key = this.getCompletionKey(userId);
            const cached = await redis.get(key);
            return cached ? parseFloat(cached) : null;
        }
        catch (error) {
            if (VERBOSE_LOGGING) {
                console.error('[ProfileCache] Failed to get cached completion:', error);
            }
            return null;
        }
    }
    /**
     * Cache points balance
     */
    async cachePoints(userId, points) {
        try {
            const redis = (0, redis_client_1.getRedisClient)();
            const key = this.getPointsKey(userId);
            await redis.setEx(key, this.POINTS_TTL, JSON.stringify(points));
        }
        catch (error) {
            if (VERBOSE_LOGGING) {
                console.error('[ProfileCache] Failed to cache points:', error);
            }
        }
    }
    /**
     * Get cached points balance
     */
    async getCachedPoints(userId) {
        try {
            const redis = (0, redis_client_1.getRedisClient)();
            const key = this.getPointsKey(userId);
            const cached = await redis.get(key);
            return cached ? JSON.parse(cached) : null;
        }
        catch (error) {
            if (VERBOSE_LOGGING) {
                console.error('[ProfileCache] Failed to get cached points:', error);
            }
            return null;
        }
    }
    /**
     * Invalidate points cache
     */
    async invalidatePoints(userId) {
        try {
            const redis = (0, redis_client_1.getRedisClient)();
            await redis.del(this.getPointsKey(userId));
        }
        catch (error) {
            if (VERBOSE_LOGGING) {
                console.error('[ProfileCache] Failed to invalidate points:', error);
            }
        }
    }
}
exports.ProfileCacheService = ProfileCacheService;
//# sourceMappingURL=profile-cache.service.js.map