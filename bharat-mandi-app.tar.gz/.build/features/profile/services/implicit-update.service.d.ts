/**
 * Implicit Update Service
 *
 * Automatically updates profile fields from user interactions.
 */
export declare class ImplicitUpdateService {
    private promptService;
    private languageMessageCount;
    constructor();
    /**
     * Detect and update language preference from message
     */
    detectAndUpdateLanguage(userId: string, messageText: string): Promise<boolean>;
    /**
     * Simple language detection (in production, use external API)
     */
    private detectLanguage;
    /**
     * Add crop to user's crops_grown list from image upload
     */
    addCropFromImage(userId: string, cropName: string, confidence: number): Promise<boolean>;
    /**
     * Add crop from price query
     */
    addCropFromPriceQuery(userId: string, cropName: string): Promise<boolean>;
    /**
     * Add crop from sale post
     */
    addCropFromSalePost(userId: string, cropName: string): Promise<boolean>;
    /**
     * Infer user type from marketplace behavior
     */
    inferUserType(userId: string, behavior: 'selling' | 'buying'): Promise<boolean>;
    /**
     * Check if user should be explicitly prompted for user type
     */
    shouldPromptForUserType(userId: string): Promise<boolean>;
}
//# sourceMappingURL=implicit-update.service.d.ts.map