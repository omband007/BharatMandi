"use strict";
/**
 * Contextual Prompt Engine
 *
 * Determines when and what profile data to request based on user interactions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContextualPromptService = void 0;
const profile_sequelize_model_1 = require("../models/profile.sequelize.model");
// TODO: Migrate PromptTrackingModel to Sequelize
// import { PromptTrackingModel } from '../models/profile.model';
const profile_constants_1 = require("../constants/profile.constants");
class ContextualPromptService {
    /**
     * Identify the highest priority missing field to prompt for
     */
    async identifyPromptOpportunity(userId, interactionContext) {
        // Get user profile
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            throw new Error('Profile not found');
        }
        // Get all missing fields
        const profileObj = profile.toJSON();
        const missingFields = this.getMissingFields(profileObj);
        if (missingFields.length === 0) {
            return null; // Profile is complete
        }
        // TODO: Re-enable prompt tracking after migrating PromptTrackingModel to Sequelize
        // For now, return the highest priority missing field
        const eligibleFields = missingFields.map(fieldName => ({
            fieldName,
            priority: this.getFieldPriority(fieldName),
            reason: this.getPromptReason(fieldName, interactionContext),
            shouldPrompt: true
        }));
        // Sort by priority (highest first)
        eligibleFields.sort((a, b) => b.priority - a.priority);
        // Return highest priority field
        return eligibleFields[0];
    }
    /**
     * Get missing profile fields
     */
    getMissingFields(profile) {
        const missing = [];
        if (!profile.name)
            missing.push('name');
        if (!profile.location)
            missing.push('location');
        if (!profile.userType)
            missing.push('userType');
        if (!profile.cropsGrown || profile.cropsGrown.length === 0)
            missing.push('cropsGrown');
        if (!profile.languagePreference)
            missing.push('languagePreference');
        if (!profile.farmSize)
            missing.push('farmSize');
        if (!profile.profilePicture)
            missing.push('profilePicture');
        if (!profile.bankAccount)
            missing.push('bankAccount');
        return missing;
    }
    /**
     * Get field priority
     */
    getFieldPriority(fieldName) {
        return profile_constants_1.FIELD_PRIORITY[fieldName] || 0;
    }
    /**
     * Get prompt reason based on field and context
     */
    getPromptReason(fieldName, context) {
        const reasons = {
            location: 'To provide accurate weather information and local market prices',
            name: 'To personalize your experience on Bharat Mandi',
            userType: 'To customize features and recommendations for you',
            cropsGrown: 'To provide relevant crop recommendations and market insights',
            languagePreference: 'To communicate in your preferred language',
            farmSize: 'To provide appropriately scaled farming advice',
            profilePicture: 'To build trust with other users in the marketplace',
            bankAccount: 'To enable payment features and transactions'
        };
        return reasons[fieldName] || 'To complete your profile';
    }
    /**
     * Check if field is eligible for prompting
     */
    async isFieldEligibleForPrompt(tracking) {
        if (!tracking) {
            return true; // Never prompted before
        }
        // Check if marked as user_declined
        if (tracking.status === 'user_declined') {
            return false;
        }
        // Check if already collected
        if (tracking.status === 'collected') {
            return false;
        }
        // Check dismissal cooldown (24 hours)
        if (tracking.lastDismissedAt) {
            const hoursSinceDismissal = (Date.now() - tracking.lastDismissedAt.getTime()) / (1000 * 60 * 60);
            if (hoursSinceDismissal < profile_constants_1.PROMPT_LIMITS.DISMISSAL_COOLDOWN_HOURS) {
                return false;
            }
        }
        // Check if dismissed too many times
        if (tracking.dismissalCount >= profile_constants_1.PROMPT_LIMITS.MAX_DISMISSALS) {
            return false;
        }
        return true;
    }
    /**
     * Check if user can receive a prompt now (timing check)
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    async canPromptNow(userId) {
        // Temporarily always return true until PromptTrackingModel is migrated
        return true;
    }
    /**
     * Record that a prompt was shown
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    async recordPromptShown(userId, fieldName) {
        // Temporarily disabled until PromptTrackingModel is migrated
        return;
    }
    /**
     * Record that a prompt was dismissed
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    async recordPromptDismissed(userId, fieldName) {
        // Temporarily disabled until PromptTrackingModel is migrated
        return;
    }
    /**
     * Record that a field was collected
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    async recordFieldCollected(userId, fieldName, source) {
        // Temporarily disabled until PromptTrackingModel is migrated
        return;
    }
    /**
     * Get prompt statistics for a user
     * TODO: Re-enable after migrating PromptTrackingModel to Sequelize
     */
    async getPromptStats(userId) {
        // Temporarily return empty stats until PromptTrackingModel is migrated
        return {
            totalFields: 0,
            collected: 0,
            pending: 0,
            declined: 0,
            trackings: []
        };
    }
}
exports.ContextualPromptService = ContextualPromptService;
//# sourceMappingURL=contextual-prompt.service.js.map