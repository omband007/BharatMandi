/**
 * Profile Picture Service
 *
 * Handles profile picture upload, processing, and storage.
 */
import type { ProfilePicture } from '../types/profile.types';
export declare class ProfilePictureService {
    private promptService;
    private storageBasePath;
    constructor();
    /**
     * Upload and process profile picture
     */
    uploadProfilePicture(userId: string, fileBuffer: Buffer, mimeType: string, originalSize: number): Promise<ProfilePicture>;
    /**
     * Resize and save image
     */
    private resizeAndSave;
    /**
     * Moderate content using AWS Rekognition or similar
     */
    private moderateContent;
    /**
     * Get file extension from MIME type
     */
    private getExtensionFromMimeType;
    /**
     * Delete stored images
     */
    private deleteStoredImages;
    /**
     * Remove profile picture
     */
    removeProfilePicture(userId: string): Promise<boolean>;
    /**
     * Get profile picture
     */
    getProfilePicture(userId: string): Promise<ProfilePicture | null>;
    /**
     * Get default avatar URL
     */
    getDefaultAvatar(): string;
}
//# sourceMappingURL=profile-picture.service.d.ts.map