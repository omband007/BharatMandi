/**
 * Authentication Service
 *
 * Handles PIN/biometric authentication, JWT token management, and account security.
 *
 * MIGRATED FROM: src/features/auth/auth.service.ts
 * ADAPTED FOR: UserProfile model (comprehensive profile data)
 * CHANGES:
 * - User → UserProfile type
 * - JWT expiration: 7d → 30d
 * - Uses UserProfileModel instead of DatabaseManager
 * - Account lockout uses profile fields (failedLoginAttempts, lockedUntil)
 */
import type { UserProfile } from '../types/profile.types';
export interface TokenPayload {
    userId: string;
    mobileNumber: string;
    name?: string;
}
export interface LoginResponse {
    success: boolean;
    token?: string;
    profile?: UserProfile;
    message: string;
}
export interface SetupPINResponse {
    success: boolean;
    message: string;
}
/**
 * Setup PIN for a user
 * Requirement 6: Optional PIN Setup
 */
export declare function setupPIN(userId: string, pin: string, confirmPin: string): Promise<SetupPINResponse>;
/**
 * Change PIN for a user (requires OTP verification first)
 * Requirement 23: Password Reset (PIN Reset)
 */
export declare function changePIN(userId: string, newPin: string, confirmNewPin: string): Promise<SetupPINResponse>;
/**
 * Login with PIN
 * Requirements: 10 (PIN Login), 24A (Account Lockout Protection)
 */
export declare function loginWithPIN(mobileNumber: string, pin: string): Promise<LoginResponse>;
/**
 * Login with biometric authentication
 * Requirements: 11 (Biometric Login), 24A (Account Lockout Protection)
 *
 * Note: This requires the mobile app to first verify biometric locally,
 * then call this endpoint with the mobile number
 */
export declare function loginWithBiometric(mobileNumber: string): Promise<LoginResponse>;
/**
 * Login with OTP (for existing users)
 * Always available, even when account is locked (account recovery)
 * Requirements: 9.1-9.7, 24A.8
 */
export declare function loginWithOTP(mobileNumber: string, otp: string): Promise<LoginResponse>;
/**
 * Generate JWT token for authenticated user
 * Requirement 12: Session Management
 */
export declare function generateToken(profile: UserProfile | any): string;
/**
 * Verify JWT token
 * Requirement 12.4: Validate tokens on protected API endpoints
 */
export declare function verifyToken(token: string): {
    valid: boolean;
    payload?: TokenPayload;
};
/**
 * Refresh JWT token
 * Requirement 12.5: Refresh tokens automatically before expiration
 */
export declare function refreshToken(currentToken: string): {
    success: boolean;
    token?: string;
    message: string;
};
/**
 * Check if account is locked
 * Requirement 24A.4: Auto-unlock after lockout period
 */
export declare function isAccountLocked(profile: UserProfile | any): boolean;
/**
 * Handle failed login attempt
 * Requirement 24A: Account Lockout Protection
 */
export declare function handleFailedLogin(userId: string, method: 'pin' | 'biometric'): Promise<void>;
/**
 * Handle successful login
 * Requirement 24A.5: Reset failed attempt counter on successful login
 */
export declare function handleSuccessfulLogin(userId: string): Promise<void>;
/**
 * Enable biometric authentication for a user
 * Requirement 7: Optional Biometric Setup
 */
export declare function enableBiometric(userId: string): Promise<SetupPINResponse>;
/**
 * Disable biometric authentication for a user
 * Requirement 7.7: Allow users to disable biometric authentication
 */
export declare function disableBiometric(userId: string): Promise<SetupPINResponse>;
//# sourceMappingURL=auth.service.d.ts.map