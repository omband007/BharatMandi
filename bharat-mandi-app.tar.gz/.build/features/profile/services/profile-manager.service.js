"use strict";
/**
 * Profile Manager Service
 *
 * Core service for profile CRUD operations, completeness calculation,
 * and privacy settings management.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProfileManagerService = void 0;
const profile_sequelize_model_1 = require("../models/profile.sequelize.model");
const profile_constants_1 = require("../constants/profile.constants");
const profile_cache_service_1 = require("./profile-cache.service");
const validators_1 = require("../utils/validators");
class ProfileManagerService {
    constructor() {
        this.cacheService = new profile_cache_service_1.ProfileCacheService();
    }
    /**
     * Get user profile by userId (with caching)
     */
    async getProfile(userId) {
        // Try cache first
        const cached = await this.cacheService.getCachedProfile(userId);
        if (cached) {
            return cached;
        }
        // Fetch from database using Sequelize
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            return null;
        }
        // Convert to plain object
        const profileObj = profile.toJSON();
        // Cache for next time
        await this.cacheService.cacheProfile(userId, profileObj);
        return profileObj;
    }
    /**
     * Update a single profile field
     */
    async updateProfileField(userId, fieldName, value) {
        // Get existing profile
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            throw new Error('Profile not found');
        }
        // Validate field value
        if (fieldName === 'mobileNumber') {
            throw new Error('Mobile number cannot be updated without re-verification');
        }
        const validation = (0, validators_1.validateField)(fieldName, value);
        if (!validation.valid) {
            throw new Error(validation.error);
        }
        // Transform location data if needed
        if (fieldName === 'location' && value) {
            // If location is in the format { type: 'manual', text: 'location string' }
            // Transform it to the full Location object format
            if (value.type === 'manual' && value.text) {
                const existingLocation = profile.location;
                value = {
                    latitude: existingLocation?.latitude || 0,
                    longitude: existingLocation?.longitude || 0,
                    addressLine1: value.text,
                    country: existingLocation?.country || profile.countryCode || 'IN',
                    locationType: 'manual',
                    isVerified: false,
                    lastUpdated: new Date()
                };
            }
            else if (value.type === 'gps' && value.latitude && value.longitude) {
                const existingLocation = profile.location;
                value = {
                    latitude: value.latitude,
                    longitude: value.longitude,
                    country: existingLocation?.country || profile.countryCode || 'IN',
                    locationType: 'gps',
                    isVerified: false,
                    lastUpdated: new Date()
                };
            }
            // Otherwise, assume it's already in the correct format
        }
        // Update the field
        profile[fieldName] = value;
        // Recalculate completion percentage
        const profileObj = profile.toJSON();
        const completionPercentage = this.calculateCompletionPercentage(profileObj);
        profile.completionPercentage = completionPercentage;
        // Save profile
        await profile.save();
        // Invalidate cache
        await this.cacheService.invalidateProfile(userId);
        return {
            updated: true,
            completionPercentage
        };
    }
    /**
     * Calculate profile completion percentage
     */
    calculateCompletionPercentage(profile) {
        let total = profile_constants_1.PROFILE_FIELD_WEIGHTS.mobileNumber; // Always present
        if (profile.name) {
            total += profile_constants_1.PROFILE_FIELD_WEIGHTS.name;
        }
        if (profile.location) {
            total += profile_constants_1.PROFILE_FIELD_WEIGHTS.location;
        }
        if (profile.userType) {
            total += profile_constants_1.PROFILE_FIELD_WEIGHTS.userType;
        }
        if (profile.cropsGrown && profile.cropsGrown.length > 0) {
            total += profile_constants_1.PROFILE_FIELD_WEIGHTS.cropsGrown;
        }
        if (profile.languagePreference) {
            total += profile_constants_1.PROFILE_FIELD_WEIGHTS.languagePreference;
        }
        if (profile.farmSize) {
            total += profile_constants_1.PROFILE_FIELD_WEIGHTS.farmSize;
        }
        if (profile.bankAccount) {
            total += profile_constants_1.PROFILE_FIELD_WEIGHTS.bankAccount;
        }
        if (profile.profilePicture) {
            total += profile_constants_1.PROFILE_FIELD_WEIGHTS.profilePicture;
        }
        return total;
    }
    /**
     * Export profile data as JSON
     */
    async exportProfileData(userId) {
        const profile = await this.getProfile(userId);
        if (!profile) {
            throw new Error('Profile not found');
        }
        // Include metadata
        return {
            profile,
            metadata: {
                exportedAt: new Date().toISOString(),
                version: '1.0'
            }
        };
    }
    /**
     * Update privacy setting for a field
     */
    async updatePrivacySetting(userId, fieldName, privacyLevel) {
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            throw new Error('Profile not found');
        }
        const settings = profile.privacySettings || {};
        settings[fieldName] = privacyLevel;
        profile.privacySettings = settings;
        await profile.save();
        return true;
    }
    /**
     * Get privacy setting for a field
     */
    async getPrivacySetting(userId, fieldName) {
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            throw new Error('Profile not found');
        }
        return profile.privacySettings?.[fieldName] || 'platform_only';
    }
    /**
     * Apply privacy filters to profile data
     */
    applyPrivacyFilters(profile, viewerContext) {
        if (viewerContext === 'self') {
            // User viewing their own profile - show everything
            return profile;
        }
        // For platform context, include all basic fields by default
        if (viewerContext === 'platform') {
            return {
                userId: profile.userId,
                mobileNumber: profile.mobileNumber,
                name: profile.name,
                userType: profile.userType,
                location: profile.location,
                profilePicture: profile.profilePicture,
                languagePreference: profile.languagePreference,
                cropsGrown: profile.cropsGrown,
                farmSize: profile.farmSize,
                completionPercentage: profile.completionPercentage,
                membershipTier: profile.membershipTier,
                trustScore: profile.trustScore,
                createdAt: profile.createdAt
            };
        }
        // For public context, only include public fields
        const filtered = {
            userId: profile.userId,
            profilePicture: profile.profilePicture,
            membershipTier: profile.membershipTier,
            trustScore: profile.trustScore
        };
        // Apply privacy filters for each field
        Object.keys(profile.privacySettings || {}).forEach(fieldName => {
            const privacyLevel = profile.privacySettings[fieldName];
            const fieldValue = profile[fieldName];
            if (privacyLevel === 'public') {
                filtered[fieldName] = fieldValue;
            }
        });
        return filtered;
    }
    /**
     * Delete user profile (mark for deletion)
     */
    async deleteProfile(userId) {
        const profile = await profile_sequelize_model_1.UserProfileModel.findOne({ where: { userId } });
        if (!profile) {
            throw new Error('Profile not found');
        }
        // Anonymize mobile number immediately
        profile.mobileNumber = `DELETED_${Date.now()}`;
        await profile.save();
        // TODO: Implement full deletion after 30 days
        // TODO: Retain transaction records as required by law
        return true;
    }
    /**
     * Update last active timestamp
     */
    async updateLastActive(userId) {
        await profile_sequelize_model_1.UserProfileModel.update({ lastActiveAt: new Date() }, { where: { userId } });
    }
}
exports.ProfileManagerService = ProfileManagerService;
//# sourceMappingURL=profile-manager.service.js.map