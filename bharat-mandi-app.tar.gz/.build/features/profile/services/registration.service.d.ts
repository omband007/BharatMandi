/**
 * Registration Service
 *
 * Handles minimal registration (mobile number + OTP) and initial profile creation.
 */
import type { RegisterRequest, RegisterResponse, VerifyOTPRequest, VerifyOTPResponse } from '../types/profile.types';
export declare class RegistrationService {
    private otpExpiryMinutes;
    private maxOTPAttempts;
    constructor();
    /**
     * Validate and normalize mobile number (international format support)
     *
     * Accepts:
     * - 10 digits (assumes India +91): "9876543210" → "+919876543210"
     * - Full international format: "+447700900123", "+919876543210"
     *
     * Returns normalized E.164 format and country code
     */
    validateMobileNumber(mobileNumber: string): {
        valid: boolean;
        normalized?: string;
        countryCode?: string;
        error?: string;
    };
    /**
     * Generate a 6-digit OTP
     */
    private generateOTP;
    /**
     * Generate a unique referral code
     */
    private generateReferralCode;
    /**
     * Send OTP via SMS gateway
     * TODO: Integrate with actual SMS gateway (Twilio/AWS SNS)
     */
    private sendOTP;
    /**
     * Initiate registration - validate mobile number and send OTP
     */
    register(request: RegisterRequest): Promise<RegisterResponse>;
    /**
     * Verify OTP and complete registration with mandatory fields
     * Collects name, userType, and location before creating profile
     */
    verifyOTP(request: VerifyOTPRequest): Promise<VerifyOTPResponse>;
    /**
     * Validate mandatory registration fields
     */
    private validateMandatoryFields;
    /**
     * Create initial user profile with mandatory fields
     * Stores mobile number in E.164 international format
     */
    private createInitialProfile;
    /**
     * Resend OTP
     */
    resendOTP(mobileNumber: string): Promise<{
        success: boolean;
        otp?: string;
    }>;
}
//# sourceMappingURL=registration.service.d.ts.map