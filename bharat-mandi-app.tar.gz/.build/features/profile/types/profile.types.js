"use strict";
/**
 * Profile Management Types
 *
 * Type definitions for the Progressive Profile Management feature.
 * Supports minimal registration, progressive data collection, gamification,
 * and trust scoring.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=profile.types.js.map