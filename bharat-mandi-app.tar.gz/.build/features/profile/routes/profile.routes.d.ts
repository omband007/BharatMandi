/**
 * Profile Management Routes
 *
 * API endpoints for profile registration, management, and gamification.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=profile.routes.d.ts.map