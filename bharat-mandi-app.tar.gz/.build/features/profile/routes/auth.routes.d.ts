/**
 * Authentication Routes
 *
 * API endpoints for PIN/biometric authentication, JWT token management, and account security.
 *
 * CREATED FOR: Unified authentication & profile management
 * INTEGRATES WITH: src/features/profile/services/auth.service.ts
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=auth.routes.d.ts.map