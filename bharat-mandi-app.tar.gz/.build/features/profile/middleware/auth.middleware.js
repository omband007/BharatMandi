"use strict";
/**
 * Authentication Middleware
 *
 * JWT token verification middleware for protecting API routes.
 *
 * CREATED FOR: Unified authentication & profile management
 * INTEGRATES WITH: src/features/profile/services/auth.service.ts
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireAuth = requireAuth;
exports.optionalAuth = optionalAuth;
exports.requireSelfOrAdmin = requireSelfOrAdmin;
const authService = __importStar(require("../services/auth.service"));
/**
 * Require authentication - reject requests without valid JWT token
 * Requirement 12.4: Validate tokens on protected API endpoints
 *
 * Usage:
 * router.get('/protected', requireAuth, (req, res) => {
 *   // req.user is available here
 * });
 */
function requireAuth(req, res, next) {
    try {
        // Extract token from Authorization header
        const authHeader = req.headers.authorization;
        if (!authHeader) {
            res.status(401).json({
                success: false,
                error: 'No authorization header provided'
            });
            return;
        }
        // Check if header starts with 'Bearer '
        if (!authHeader.startsWith('Bearer ')) {
            res.status(401).json({
                success: false,
                error: 'Invalid authorization header format. Expected: Bearer <token>'
            });
            return;
        }
        // Extract token
        const token = authHeader.substring(7); // Remove 'Bearer ' prefix
        // Verify token
        const verification = authService.verifyToken(token);
        if (!verification.valid || !verification.payload) {
            res.status(401).json({
                success: false,
                error: 'Invalid or expired token. Please log in again.'
            });
            return;
        }
        // Inject user context into request
        req.user = verification.payload;
        // Continue to next middleware/handler
        next();
    }
    catch (error) {
        console.error('[AuthMiddleware] Error in requireAuth:', error);
        res.status(500).json({
            success: false,
            error: 'Authentication failed'
        });
    }
}
/**
 * Optional authentication - allow requests with or without JWT token
 * If token is provided and valid, inject user context
 * If token is invalid or missing, continue without user context
 *
 * Usage:
 * router.get('/public-or-private', optionalAuth, (req, res) => {
 *   if (req.user) {
 *     // User is authenticated - show private content
 *   } else {
 *     // User is not authenticated - show public content
 *   }
 * });
 */
function optionalAuth(req, res, next) {
    try {
        // Extract token from Authorization header
        const authHeader = req.headers.authorization;
        // If no auth header, continue without user context
        if (!authHeader) {
            next();
            return;
        }
        // Check if header starts with 'Bearer '
        if (!authHeader.startsWith('Bearer ')) {
            // Invalid format, but don't reject - just continue without user context
            next();
            return;
        }
        // Extract token
        const token = authHeader.substring(7);
        // Verify token
        const verification = authService.verifyToken(token);
        // If valid, inject user context
        if (verification.valid && verification.payload) {
            req.user = verification.payload;
        }
        // Continue regardless of token validity
        next();
    }
    catch (error) {
        console.error('[AuthMiddleware] Error in optionalAuth:', error);
        // Don't fail the request - just continue without user context
        next();
    }
}
/**
 * Require specific user - ensure authenticated user matches the userId in the route
 *
 * Usage:
 * router.patch('/profiles/:userId', requireAuth, requireSelfOrAdmin, (req, res) => {
 *   // Only the user themselves or an admin can access this
 * });
 */
function requireSelfOrAdmin(req, res, next) {
    try {
        // This middleware should be used after requireAuth
        if (!req.user) {
            res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
            return;
        }
        // Get userId from route params
        const { userId } = req.params;
        // Check if authenticated user matches the userId in the route
        if (req.user.userId !== userId) {
            // TODO: Add admin role check here
            // For now, only allow users to access their own data
            res.status(403).json({
                success: false,
                error: 'Forbidden. You can only access your own data.'
            });
            return;
        }
        // User is authorized
        next();
    }
    catch (error) {
        console.error('[AuthMiddleware] Error in requireSelfOrAdmin:', error);
        res.status(500).json({
            success: false,
            error: 'Authorization failed'
        });
    }
}
//# sourceMappingURL=auth.middleware.js.map