/**
 * Authentication Middleware
 *
 * JWT token verification middleware for protecting API routes.
 *
 * CREATED FOR: Unified authentication & profile management
 * INTEGRATES WITH: src/features/profile/services/auth.service.ts
 */
import { Request, Response, NextFunction } from 'express';
import type { TokenPayload } from '../services/auth.service';
declare global {
    namespace Express {
        interface Request {
            user?: TokenPayload;
        }
    }
}
/**
 * Require authentication - reject requests without valid JWT token
 * Requirement 12.4: Validate tokens on protected API endpoints
 *
 * Usage:
 * router.get('/protected', requireAuth, (req, res) => {
 *   // req.user is available here
 * });
 */
export declare function requireAuth(req: Request, res: Response, next: NextFunction): void;
/**
 * Optional authentication - allow requests with or without JWT token
 * If token is provided and valid, inject user context
 * If token is invalid or missing, continue without user context
 *
 * Usage:
 * router.get('/public-or-private', optionalAuth, (req, res) => {
 *   if (req.user) {
 *     // User is authenticated - show private content
 *   } else {
 *     // User is not authenticated - show public content
 *   }
 * });
 */
export declare function optionalAuth(req: Request, res: Response, next: NextFunction): void;
/**
 * Require specific user - ensure authenticated user matches the userId in the route
 *
 * Usage:
 * router.patch('/profiles/:userId', requireAuth, requireSelfOrAdmin, (req, res) => {
 *   // Only the user themselves or an admin can access this
 * });
 */
export declare function requireSelfOrAdmin(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=auth.middleware.d.ts.map