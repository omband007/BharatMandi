"use strict";
/**
 * Profile Mongoose Models
 *
 * Mongoose model instances for profile management collections.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReferralModel = exports.PointsTransactionModel = exports.PromptTrackingModel = exports.UserProfileModel = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const profile_schema_1 = require("./profile.schema");
// Create models
exports.UserProfileModel = mongoose_1.default.model('UserProfile', profile_schema_1.UserProfileSchema);
exports.PromptTrackingModel = mongoose_1.default.model('PromptTracking', profile_schema_1.PromptTrackingSchema);
exports.PointsTransactionModel = mongoose_1.default.model('PointsTransaction', profile_schema_1.PointsTransactionSchema);
exports.ReferralModel = mongoose_1.default.model('Referral', profile_schema_1.ReferralSchema);
//# sourceMappingURL=profile.model.js.map