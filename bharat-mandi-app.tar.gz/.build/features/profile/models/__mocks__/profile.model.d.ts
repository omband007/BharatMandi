/**
 * Mock for UserProfileModel
 * Used in unit tests to avoid real MongoDB connections
 */
export declare const UserProfileModel: {
    findOne: jest.Mock<any, any, any>;
    create: jest.Mock<any, any, any>;
    findById: jest.Mock<any, any, any>;
    find: jest.Mock<any, any, any>;
    updateOne: jest.Mock<any, any, any>;
    deleteOne: jest.Mock<any, any, any>;
};
export declare const PromptTrackingModel: {
    findOne: jest.Mock<any, any, any>;
    create: jest.Mock<any, any, any>;
    find: jest.Mock<any, any, any>;
};
export declare const PointsTransactionModel: {
    create: jest.Mock<any, any, any>;
    find: jest.Mock<any, any, any>;
};
//# sourceMappingURL=profile.model.d.ts.map