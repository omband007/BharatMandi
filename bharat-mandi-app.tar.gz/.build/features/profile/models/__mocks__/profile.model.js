"use strict";
/**
 * Mock for UserProfileModel
 * Used in unit tests to avoid real MongoDB connections
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PointsTransactionModel = exports.PromptTrackingModel = exports.UserProfileModel = void 0;
exports.UserProfileModel = {
    findOne: jest.fn(),
    create: jest.fn(),
    findById: jest.fn(),
    find: jest.fn(),
    updateOne: jest.fn(),
    deleteOne: jest.fn(),
};
exports.PromptTrackingModel = {
    findOne: jest.fn(),
    create: jest.fn(),
    find: jest.fn(),
};
exports.PointsTransactionModel = {
    create: jest.fn(),
    find: jest.fn(),
};
//# sourceMappingURL=profile.model.js.map