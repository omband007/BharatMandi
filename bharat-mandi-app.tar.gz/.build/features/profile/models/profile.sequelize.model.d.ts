/**
 * User Profile Sequelize Model (PostgreSQL)
 *
 * Replaces MongoDB UserProfileModel with PostgreSQL implementation
 */
import { Model, Optional } from 'sequelize';
import type { UserProfile, Location, ProfilePicture, BankAccount, FarmSize, CropGrown, Points, TrustScoreHistoryEntry, PrivacyLevel } from '../types/profile.types';
interface UserProfileCreationAttributes extends Optional<UserProfile, 'name' | 'profilePicture' | 'location' | 'userType' | 'cropsGrown' | 'farmSize' | 'languagePreference' | 'bankAccount' | 'pinHash' | 'biometricEnabled' | 'failedLoginAttempts' | 'lockedUntil' | 'lastLoginAt' | 'completionPercentage' | 'createdAt' | 'updatedAt' | 'lastActiveAt' | 'privacySettings' | 'points' | 'membershipTier' | 'referralCode' | 'referredBy' | 'dailyStreak' | 'lastStreakDate' | 'trustScore'> {
}
declare class UserProfileModel extends Model<UserProfile, UserProfileCreationAttributes> implements UserProfile {
    userId: string;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    name?: string;
    profilePicture?: ProfilePicture;
    location?: Location;
    userType?: 'farmer' | 'buyer' | 'both';
    cropsGrown?: CropGrown[];
    farmSize?: FarmSize;
    languagePreference?: string;
    bankAccount?: BankAccount;
    pinHash?: string;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    lockedUntil?: Date;
    lastLoginAt?: Date;
    completionPercentage: number;
    createdAt: Date;
    updatedAt: Date;
    lastActiveAt?: Date;
    privacySettings: Record<string, PrivacyLevel>;
    points: Points;
    membershipTier: 'bronze' | 'silver' | 'gold' | 'platinum';
    referralCode: string;
    referredBy?: string;
    dailyStreak: number;
    lastStreakDate?: Date;
    trustScore: number;
    trustScoreHistory: TrustScoreHistoryEntry[];
}
export { UserProfileModel };
export default UserProfileModel;
//# sourceMappingURL=profile.sequelize.model.d.ts.map