/**
 * Profile Mongoose Models
 *
 * Mongoose model instances for profile management collections.
 */
import mongoose from 'mongoose';
export declare const UserProfileModel: mongoose.Model<{
    createdAt: NativeDate;
    updatedAt: NativeDate;
    userId: string;
    cropsGrown: mongoose.Types.DocumentArray<{
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }> & {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }>;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    completionPercentage: number;
    lastActiveAt: NativeDate;
    privacySettings: Map<string, string>;
    points: {
        current: number;
        lastUpdated: NativeDate;
        lifetime: number;
    };
    membershipTier: "bronze" | "silver" | "gold" | "platinum";
    referralCode: string;
    dailyStreak: number;
    trustScore: number;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    trustScoreHistory: mongoose.Types.DocumentArray<{
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }> & {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }>;
    name?: string | null | undefined;
    userType?: "farmer" | "buyer" | "both" | null | undefined;
    location?: {
        latitude: number;
        longitude: number;
        country: string;
        locationType: "gps" | "manual";
        isVerified: boolean;
        lastUpdated: NativeDate;
        addressLine1?: string | null | undefined;
        addressLine2?: string | null | undefined;
        city?: string | null | undefined;
        district?: string | null | undefined;
        state?: string | null | undefined;
        pincode?: string | null | undefined;
    } | null | undefined;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        verified: boolean;
    } | null | undefined;
    languagePreference?: "en" | "hi" | "pa" | "mr" | "ta" | "te" | null | undefined;
    profilePicture?: {
        thumbnailUrl: string;
        uploadedAt: NativeDate;
        url: string;
    } | null | undefined;
    farmSize?: {
        unit: "acres" | "hectares";
        value: number;
    } | null | undefined;
    pinHash?: string | null | undefined;
    lockedUntil?: NativeDate | null | undefined;
    lastLoginAt?: NativeDate | null | undefined;
    referredBy?: string | null | undefined;
    lastStreakDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps, {}, {}, {}, mongoose.Document<unknown, {}, {
    createdAt: NativeDate;
    updatedAt: NativeDate;
    userId: string;
    cropsGrown: mongoose.Types.DocumentArray<{
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }> & {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }>;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    completionPercentage: number;
    lastActiveAt: NativeDate;
    privacySettings: Map<string, string>;
    points: {
        current: number;
        lastUpdated: NativeDate;
        lifetime: number;
    };
    membershipTier: "bronze" | "silver" | "gold" | "platinum";
    referralCode: string;
    dailyStreak: number;
    trustScore: number;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    trustScoreHistory: mongoose.Types.DocumentArray<{
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }> & {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }>;
    name?: string | null | undefined;
    userType?: "farmer" | "buyer" | "both" | null | undefined;
    location?: {
        latitude: number;
        longitude: number;
        country: string;
        locationType: "gps" | "manual";
        isVerified: boolean;
        lastUpdated: NativeDate;
        addressLine1?: string | null | undefined;
        addressLine2?: string | null | undefined;
        city?: string | null | undefined;
        district?: string | null | undefined;
        state?: string | null | undefined;
        pincode?: string | null | undefined;
    } | null | undefined;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        verified: boolean;
    } | null | undefined;
    languagePreference?: "en" | "hi" | "pa" | "mr" | "ta" | "te" | null | undefined;
    profilePicture?: {
        thumbnailUrl: string;
        uploadedAt: NativeDate;
        url: string;
    } | null | undefined;
    farmSize?: {
        unit: "acres" | "hectares";
        value: number;
    } | null | undefined;
    pinHash?: string | null | undefined;
    lockedUntil?: NativeDate | null | undefined;
    lastLoginAt?: NativeDate | null | undefined;
    referredBy?: string | null | undefined;
    lastStreakDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps, {}, {
    timestamps: true;
    collection: string;
}> & {
    createdAt: NativeDate;
    updatedAt: NativeDate;
    userId: string;
    cropsGrown: mongoose.Types.DocumentArray<{
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }> & {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }>;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    completionPercentage: number;
    lastActiveAt: NativeDate;
    privacySettings: Map<string, string>;
    points: {
        current: number;
        lastUpdated: NativeDate;
        lifetime: number;
    };
    membershipTier: "bronze" | "silver" | "gold" | "platinum";
    referralCode: string;
    dailyStreak: number;
    trustScore: number;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    trustScoreHistory: mongoose.Types.DocumentArray<{
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }> & {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }>;
    name?: string | null | undefined;
    userType?: "farmer" | "buyer" | "both" | null | undefined;
    location?: {
        latitude: number;
        longitude: number;
        country: string;
        locationType: "gps" | "manual";
        isVerified: boolean;
        lastUpdated: NativeDate;
        addressLine1?: string | null | undefined;
        addressLine2?: string | null | undefined;
        city?: string | null | undefined;
        district?: string | null | undefined;
        state?: string | null | undefined;
        pincode?: string | null | undefined;
    } | null | undefined;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        verified: boolean;
    } | null | undefined;
    languagePreference?: "en" | "hi" | "pa" | "mr" | "ta" | "te" | null | undefined;
    profilePicture?: {
        thumbnailUrl: string;
        uploadedAt: NativeDate;
        url: string;
    } | null | undefined;
    farmSize?: {
        unit: "acres" | "hectares";
        value: number;
    } | null | undefined;
    pinHash?: string | null | undefined;
    lockedUntil?: NativeDate | null | undefined;
    lastLoginAt?: NativeDate | null | undefined;
    referredBy?: string | null | undefined;
    lastStreakDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    createdAt: NativeDate;
    updatedAt: NativeDate;
    userId: string;
    cropsGrown: mongoose.Types.DocumentArray<{
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }> & {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }>;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    completionPercentage: number;
    lastActiveAt: NativeDate;
    privacySettings: Map<string, string>;
    points: {
        current: number;
        lastUpdated: NativeDate;
        lifetime: number;
    };
    membershipTier: "bronze" | "silver" | "gold" | "platinum";
    referralCode: string;
    dailyStreak: number;
    trustScore: number;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    trustScoreHistory: mongoose.Types.DocumentArray<{
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }> & {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }>;
    name?: string | null | undefined;
    userType?: "farmer" | "buyer" | "both" | null | undefined;
    location?: {
        latitude: number;
        longitude: number;
        country: string;
        locationType: "gps" | "manual";
        isVerified: boolean;
        lastUpdated: NativeDate;
        addressLine1?: string | null | undefined;
        addressLine2?: string | null | undefined;
        city?: string | null | undefined;
        district?: string | null | undefined;
        state?: string | null | undefined;
        pincode?: string | null | undefined;
    } | null | undefined;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        verified: boolean;
    } | null | undefined;
    languagePreference?: "en" | "hi" | "pa" | "mr" | "ta" | "te" | null | undefined;
    profilePicture?: {
        thumbnailUrl: string;
        uploadedAt: NativeDate;
        url: string;
    } | null | undefined;
    farmSize?: {
        unit: "acres" | "hectares";
        value: number;
    } | null | undefined;
    pinHash?: string | null | undefined;
    lockedUntil?: NativeDate | null | undefined;
    lastLoginAt?: NativeDate | null | undefined;
    referredBy?: string | null | undefined;
    lastStreakDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps, mongoose.Document<unknown, {}, mongoose.FlatRecord<{
    createdAt: NativeDate;
    updatedAt: NativeDate;
    userId: string;
    cropsGrown: mongoose.Types.DocumentArray<{
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }> & {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }>;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    completionPercentage: number;
    lastActiveAt: NativeDate;
    privacySettings: Map<string, string>;
    points: {
        current: number;
        lastUpdated: NativeDate;
        lifetime: number;
    };
    membershipTier: "bronze" | "silver" | "gold" | "platinum";
    referralCode: string;
    dailyStreak: number;
    trustScore: number;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    trustScoreHistory: mongoose.Types.DocumentArray<{
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }> & {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }>;
    name?: string | null | undefined;
    userType?: "farmer" | "buyer" | "both" | null | undefined;
    location?: {
        latitude: number;
        longitude: number;
        country: string;
        locationType: "gps" | "manual";
        isVerified: boolean;
        lastUpdated: NativeDate;
        addressLine1?: string | null | undefined;
        addressLine2?: string | null | undefined;
        city?: string | null | undefined;
        district?: string | null | undefined;
        state?: string | null | undefined;
        pincode?: string | null | undefined;
    } | null | undefined;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        verified: boolean;
    } | null | undefined;
    languagePreference?: "en" | "hi" | "pa" | "mr" | "ta" | "te" | null | undefined;
    profilePicture?: {
        thumbnailUrl: string;
        uploadedAt: NativeDate;
        url: string;
    } | null | undefined;
    farmSize?: {
        unit: "acres" | "hectares";
        value: number;
    } | null | undefined;
    pinHash?: string | null | undefined;
    lockedUntil?: NativeDate | null | undefined;
    lastLoginAt?: NativeDate | null | undefined;
    referredBy?: string | null | undefined;
    lastStreakDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps>, {}, mongoose.MergeType<mongoose.DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & mongoose.FlatRecord<{
    createdAt: NativeDate;
    updatedAt: NativeDate;
    userId: string;
    cropsGrown: mongoose.Types.DocumentArray<{
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }> & {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }>;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    completionPercentage: number;
    lastActiveAt: NativeDate;
    privacySettings: Map<string, string>;
    points: {
        current: number;
        lastUpdated: NativeDate;
        lifetime: number;
    };
    membershipTier: "bronze" | "silver" | "gold" | "platinum";
    referralCode: string;
    dailyStreak: number;
    trustScore: number;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    trustScoreHistory: mongoose.Types.DocumentArray<{
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }, mongoose.Types.Subdocument<mongoose.mongo.BSON.ObjectId, any, {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }> & {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }>;
    name?: string | null | undefined;
    userType?: "farmer" | "buyer" | "both" | null | undefined;
    location?: {
        latitude: number;
        longitude: number;
        country: string;
        locationType: "gps" | "manual";
        isVerified: boolean;
        lastUpdated: NativeDate;
        addressLine1?: string | null | undefined;
        addressLine2?: string | null | undefined;
        city?: string | null | undefined;
        district?: string | null | undefined;
        state?: string | null | undefined;
        pincode?: string | null | undefined;
    } | null | undefined;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        verified: boolean;
    } | null | undefined;
    languagePreference?: "en" | "hi" | "pa" | "mr" | "ta" | "te" | null | undefined;
    profilePicture?: {
        thumbnailUrl: string;
        uploadedAt: NativeDate;
        url: string;
    } | null | undefined;
    farmSize?: {
        unit: "acres" | "hectares";
        value: number;
    } | null | undefined;
    pinHash?: string | null | undefined;
    lockedUntil?: NativeDate | null | undefined;
    lastLoginAt?: NativeDate | null | undefined;
    referredBy?: string | null | undefined;
    lastStreakDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps> & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>>;
export declare const PromptTrackingModel: mongoose.Model<{
    userId: string;
    status: "pending" | "collected" | "user_declined";
    fieldName: string;
    promptCount: number;
    dismissalCount: number;
    lastPromptedAt?: NativeDate | null | undefined;
    lastDismissedAt?: NativeDate | null | undefined;
    collectedAt?: NativeDate | null | undefined;
    collectionSource?: "explicit_prompt" | "implicit_update" | "manual_edit" | "import" | null | undefined;
} & mongoose.DefaultTimestampProps, {}, {}, {}, mongoose.Document<unknown, {}, {
    userId: string;
    status: "pending" | "collected" | "user_declined";
    fieldName: string;
    promptCount: number;
    dismissalCount: number;
    lastPromptedAt?: NativeDate | null | undefined;
    lastDismissedAt?: NativeDate | null | undefined;
    collectedAt?: NativeDate | null | undefined;
    collectionSource?: "explicit_prompt" | "implicit_update" | "manual_edit" | "import" | null | undefined;
} & mongoose.DefaultTimestampProps, {}, {
    timestamps: true;
    collection: string;
}> & {
    userId: string;
    status: "pending" | "collected" | "user_declined";
    fieldName: string;
    promptCount: number;
    dismissalCount: number;
    lastPromptedAt?: NativeDate | null | undefined;
    lastDismissedAt?: NativeDate | null | undefined;
    collectedAt?: NativeDate | null | undefined;
    collectionSource?: "explicit_prompt" | "implicit_update" | "manual_edit" | "import" | null | undefined;
} & mongoose.DefaultTimestampProps & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    userId: string;
    status: "pending" | "collected" | "user_declined";
    fieldName: string;
    promptCount: number;
    dismissalCount: number;
    lastPromptedAt?: NativeDate | null | undefined;
    lastDismissedAt?: NativeDate | null | undefined;
    collectedAt?: NativeDate | null | undefined;
    collectionSource?: "explicit_prompt" | "implicit_update" | "manual_edit" | "import" | null | undefined;
} & mongoose.DefaultTimestampProps, mongoose.Document<unknown, {}, mongoose.FlatRecord<{
    userId: string;
    status: "pending" | "collected" | "user_declined";
    fieldName: string;
    promptCount: number;
    dismissalCount: number;
    lastPromptedAt?: NativeDate | null | undefined;
    lastDismissedAt?: NativeDate | null | undefined;
    collectedAt?: NativeDate | null | undefined;
    collectionSource?: "explicit_prompt" | "implicit_update" | "manual_edit" | "import" | null | undefined;
} & mongoose.DefaultTimestampProps>, {}, mongoose.MergeType<mongoose.DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & mongoose.FlatRecord<{
    userId: string;
    status: "pending" | "collected" | "user_declined";
    fieldName: string;
    promptCount: number;
    dismissalCount: number;
    lastPromptedAt?: NativeDate | null | undefined;
    lastDismissedAt?: NativeDate | null | undefined;
    collectedAt?: NativeDate | null | undefined;
    collectionSource?: "explicit_prompt" | "implicit_update" | "manual_edit" | "import" | null | undefined;
} & mongoose.DefaultTimestampProps> & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>>;
export declare const PointsTransactionModel: mongoose.Model<{
    userId: string;
    transactionId: string;
    type: "earn" | "redeem";
    description: string;
    timestamp: NativeDate;
    points: number;
    activity: string;
    metadata?: any;
} & mongoose.DefaultTimestampProps, {}, {}, {}, mongoose.Document<unknown, {}, {
    userId: string;
    transactionId: string;
    type: "earn" | "redeem";
    description: string;
    timestamp: NativeDate;
    points: number;
    activity: string;
    metadata?: any;
} & mongoose.DefaultTimestampProps, {}, {
    timestamps: true;
    collection: string;
}> & {
    userId: string;
    transactionId: string;
    type: "earn" | "redeem";
    description: string;
    timestamp: NativeDate;
    points: number;
    activity: string;
    metadata?: any;
} & mongoose.DefaultTimestampProps & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    userId: string;
    transactionId: string;
    type: "earn" | "redeem";
    description: string;
    timestamp: NativeDate;
    points: number;
    activity: string;
    metadata?: any;
} & mongoose.DefaultTimestampProps, mongoose.Document<unknown, {}, mongoose.FlatRecord<{
    userId: string;
    transactionId: string;
    type: "earn" | "redeem";
    description: string;
    timestamp: NativeDate;
    points: number;
    activity: string;
    metadata?: any;
} & mongoose.DefaultTimestampProps>, {}, mongoose.MergeType<mongoose.DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & mongoose.FlatRecord<{
    userId: string;
    transactionId: string;
    type: "earn" | "redeem";
    description: string;
    timestamp: NativeDate;
    points: number;
    activity: string;
    metadata?: any;
} & mongoose.DefaultTimestampProps> & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>>;
export declare const ReferralModel: mongoose.Model<{
    status: "registered" | "active" | "inactive";
    referralCode: string;
    referralId: string;
    referrerId: string;
    refereeId: string;
    registrationDate: NativeDate;
    registrationPointsAwarded: boolean;
    transactionPointsAwarded: boolean;
    firstTransactionDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps, {}, {}, {}, mongoose.Document<unknown, {}, {
    status: "registered" | "active" | "inactive";
    referralCode: string;
    referralId: string;
    referrerId: string;
    refereeId: string;
    registrationDate: NativeDate;
    registrationPointsAwarded: boolean;
    transactionPointsAwarded: boolean;
    firstTransactionDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps, {}, {
    timestamps: true;
    collection: string;
}> & {
    status: "registered" | "active" | "inactive";
    referralCode: string;
    referralId: string;
    referrerId: string;
    refereeId: string;
    registrationDate: NativeDate;
    registrationPointsAwarded: boolean;
    transactionPointsAwarded: boolean;
    firstTransactionDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    status: "registered" | "active" | "inactive";
    referralCode: string;
    referralId: string;
    referrerId: string;
    refereeId: string;
    registrationDate: NativeDate;
    registrationPointsAwarded: boolean;
    transactionPointsAwarded: boolean;
    firstTransactionDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps, mongoose.Document<unknown, {}, mongoose.FlatRecord<{
    status: "registered" | "active" | "inactive";
    referralCode: string;
    referralId: string;
    referrerId: string;
    refereeId: string;
    registrationDate: NativeDate;
    registrationPointsAwarded: boolean;
    transactionPointsAwarded: boolean;
    firstTransactionDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps>, {}, mongoose.MergeType<mongoose.DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & mongoose.FlatRecord<{
    status: "registered" | "active" | "inactive";
    referralCode: string;
    referralId: string;
    referrerId: string;
    refereeId: string;
    registrationDate: NativeDate;
    registrationPointsAwarded: boolean;
    transactionPointsAwarded: boolean;
    firstTransactionDate?: NativeDate | null | undefined;
} & mongoose.DefaultTimestampProps> & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>>;
//# sourceMappingURL=profile.model.d.ts.map