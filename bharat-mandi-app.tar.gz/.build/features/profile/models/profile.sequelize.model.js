"use strict";
/**
 * User Profile Sequelize Model (PostgreSQL)
 *
 * Replaces MongoDB UserProfileModel with PostgreSQL implementation
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserProfileModel = void 0;
const sequelize_1 = require("sequelize");
const sequelize_config_1 = __importDefault(require("../../../shared/database/sequelize-config"));
// Sequelize Model Class
class UserProfileModel extends sequelize_1.Model {
}
exports.UserProfileModel = UserProfileModel;
// Initialize model
UserProfileModel.init({
    // Identity
    userId: {
        type: sequelize_1.DataTypes.STRING(255),
        primaryKey: true,
        field: 'user_id'
    },
    mobileNumber: {
        type: sequelize_1.DataTypes.STRING(20),
        allowNull: false,
        unique: true,
        field: 'mobile_number'
    },
    countryCode: {
        type: sequelize_1.DataTypes.STRING(10),
        allowNull: false,
        field: 'country_code'
    },
    mobileVerified: {
        type: sequelize_1.DataTypes.BOOLEAN,
        defaultValue: false,
        field: 'mobile_verified'
    },
    // Basic Information
    name: {
        type: sequelize_1.DataTypes.STRING(100),
        allowNull: true
    },
    profilePicture: {
        type: sequelize_1.DataTypes.JSONB,
        allowNull: true,
        field: 'profile_picture'
    },
    // Location (JSONB for flexibility)
    location: {
        type: sequelize_1.DataTypes.JSONB,
        allowNull: true
    },
    // User Details
    userType: {
        type: sequelize_1.DataTypes.STRING(20),
        allowNull: true,
        validate: {
            isIn: [['farmer', 'buyer', 'both']]
        },
        field: 'user_type'
    },
    cropsGrown: {
        type: sequelize_1.DataTypes.JSONB,
        defaultValue: [],
        field: 'crops_grown'
    },
    farmSize: {
        type: sequelize_1.DataTypes.JSONB,
        allowNull: true,
        field: 'farm_size'
    },
    languagePreference: {
        type: sequelize_1.DataTypes.STRING(10),
        allowNull: true,
        field: 'language_preference'
    },
    // Financial
    bankAccount: {
        type: sequelize_1.DataTypes.JSONB,
        allowNull: true,
        field: 'bank_account'
    },
    // Authentication & Security
    pinHash: {
        type: sequelize_1.DataTypes.STRING(255),
        allowNull: true,
        field: 'pin_hash'
    },
    biometricEnabled: {
        type: sequelize_1.DataTypes.BOOLEAN,
        defaultValue: false,
        field: 'biometric_enabled'
    },
    failedLoginAttempts: {
        type: sequelize_1.DataTypes.INTEGER,
        defaultValue: 0,
        field: 'failed_login_attempts'
    },
    lockedUntil: {
        type: sequelize_1.DataTypes.DATE,
        allowNull: true,
        field: 'locked_until'
    },
    lastLoginAt: {
        type: sequelize_1.DataTypes.DATE,
        allowNull: true,
        field: 'last_login_at'
    },
    // Metadata
    completionPercentage: {
        type: sequelize_1.DataTypes.INTEGER,
        defaultValue: 0,
        field: 'completion_percentage'
    },
    createdAt: {
        type: sequelize_1.DataTypes.DATE,
        defaultValue: sequelize_1.DataTypes.NOW,
        field: 'created_at'
    },
    updatedAt: {
        type: sequelize_1.DataTypes.DATE,
        defaultValue: sequelize_1.DataTypes.NOW,
        field: 'updated_at'
    },
    lastActiveAt: {
        type: sequelize_1.DataTypes.DATE,
        allowNull: true,
        field: 'last_active_at'
    },
    // Privacy (JSONB for flexible field-level settings)
    privacySettings: {
        type: sequelize_1.DataTypes.JSONB,
        defaultValue: {},
        field: 'privacy_settings'
    },
    // Gamification
    points: {
        type: sequelize_1.DataTypes.JSONB,
        defaultValue: {
            current: 0,
            lifetime: 0,
            lastUpdated: new Date()
        }
    },
    membershipTier: {
        type: sequelize_1.DataTypes.STRING(20),
        defaultValue: 'bronze',
        validate: {
            isIn: [['bronze', 'silver', 'gold', 'platinum']]
        },
        field: 'membership_tier'
    },
    referralCode: {
        type: sequelize_1.DataTypes.STRING(20),
        unique: true,
        field: 'referral_code'
    },
    referredBy: {
        type: sequelize_1.DataTypes.STRING(255),
        allowNull: true,
        field: 'referred_by'
    },
    dailyStreak: {
        type: sequelize_1.DataTypes.INTEGER,
        defaultValue: 0,
        field: 'daily_streak'
    },
    lastStreakDate: {
        type: sequelize_1.DataTypes.DATEONLY,
        allowNull: true,
        field: 'last_streak_date'
    },
    // Trust
    trustScore: {
        type: sequelize_1.DataTypes.INTEGER,
        defaultValue: 50,
        field: 'trust_score'
    },
    trustScoreHistory: {
        type: sequelize_1.DataTypes.JSONB,
        defaultValue: [],
        field: 'trust_score_history'
    }
}, {
    sequelize: sequelize_config_1.default,
    tableName: 'user_profiles',
    timestamps: true,
    underscored: true,
    indexes: [
        { fields: ['mobile_number'] },
        { fields: ['referral_code'] },
        { fields: ['membership_tier'] },
        { fields: ['trust_score'] },
        { fields: ['created_at'] }
    ]
});
exports.default = UserProfileModel;
//# sourceMappingURL=profile.sequelize.model.js.map