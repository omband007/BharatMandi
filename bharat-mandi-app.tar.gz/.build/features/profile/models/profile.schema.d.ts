/**
 * Profile Database Schemas
 *
 * MongoDB schemas for profile management collections.
 */
import { Schema } from 'mongoose';
export declare const UserProfileSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    createdAt: NativeDate;
    updatedAt: NativeDate;
    userId: string;
    cropsGrown: import("mongoose").Types.DocumentArray<{
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }> & {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }>;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    completionPercentage: number;
    lastActiveAt: NativeDate;
    privacySettings: Map<string, string>;
    points: {
        current: number;
        lastUpdated: NativeDate;
        lifetime: number;
    };
    membershipTier: "bronze" | "silver" | "gold" | "platinum";
    referralCode: string;
    dailyStreak: number;
    trustScore: number;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    trustScoreHistory: import("mongoose").Types.DocumentArray<{
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }> & {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }>;
    name?: string | null | undefined;
    userType?: "farmer" | "buyer" | "both" | null | undefined;
    location?: {
        latitude: number;
        longitude: number;
        country: string;
        locationType: "gps" | "manual";
        isVerified: boolean;
        lastUpdated: NativeDate;
        addressLine1?: string | null | undefined;
        addressLine2?: string | null | undefined;
        city?: string | null | undefined;
        district?: string | null | undefined;
        state?: string | null | undefined;
        pincode?: string | null | undefined;
    } | null | undefined;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        verified: boolean;
    } | null | undefined;
    languagePreference?: "en" | "hi" | "pa" | "mr" | "ta" | "te" | null | undefined;
    profilePicture?: {
        thumbnailUrl: string;
        uploadedAt: NativeDate;
        url: string;
    } | null | undefined;
    farmSize?: {
        unit: "acres" | "hectares";
        value: number;
    } | null | undefined;
    pinHash?: string | null | undefined;
    lockedUntil?: NativeDate | null | undefined;
    lastLoginAt?: NativeDate | null | undefined;
    referredBy?: string | null | undefined;
    lastStreakDate?: NativeDate | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    updatedAt: NativeDate;
    userId: string;
    cropsGrown: import("mongoose").Types.DocumentArray<{
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }> & {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }>;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    completionPercentage: number;
    lastActiveAt: NativeDate;
    privacySettings: Map<string, string>;
    points: {
        current: number;
        lastUpdated: NativeDate;
        lifetime: number;
    };
    membershipTier: "bronze" | "silver" | "gold" | "platinum";
    referralCode: string;
    dailyStreak: number;
    trustScore: number;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    trustScoreHistory: import("mongoose").Types.DocumentArray<{
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }> & {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }>;
    name?: string | null | undefined;
    userType?: "farmer" | "buyer" | "both" | null | undefined;
    location?: {
        latitude: number;
        longitude: number;
        country: string;
        locationType: "gps" | "manual";
        isVerified: boolean;
        lastUpdated: NativeDate;
        addressLine1?: string | null | undefined;
        addressLine2?: string | null | undefined;
        city?: string | null | undefined;
        district?: string | null | undefined;
        state?: string | null | undefined;
        pincode?: string | null | undefined;
    } | null | undefined;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        verified: boolean;
    } | null | undefined;
    languagePreference?: "en" | "hi" | "pa" | "mr" | "ta" | "te" | null | undefined;
    profilePicture?: {
        thumbnailUrl: string;
        uploadedAt: NativeDate;
        url: string;
    } | null | undefined;
    farmSize?: {
        unit: "acres" | "hectares";
        value: number;
    } | null | undefined;
    pinHash?: string | null | undefined;
    lockedUntil?: NativeDate | null | undefined;
    lastLoginAt?: NativeDate | null | undefined;
    referredBy?: string | null | undefined;
    lastStreakDate?: NativeDate | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    updatedAt: NativeDate;
    userId: string;
    cropsGrown: import("mongoose").Types.DocumentArray<{
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }> & {
        cropName: string;
        source: "image_upload" | "price_query" | "sale_post";
        addedAt: NativeDate;
    }>;
    biometricEnabled: boolean;
    failedLoginAttempts: number;
    completionPercentage: number;
    lastActiveAt: NativeDate;
    privacySettings: Map<string, string>;
    points: {
        current: number;
        lastUpdated: NativeDate;
        lifetime: number;
    };
    membershipTier: "bronze" | "silver" | "gold" | "platinum";
    referralCode: string;
    dailyStreak: number;
    trustScore: number;
    mobileNumber: string;
    countryCode: string;
    mobileVerified: boolean;
    trustScoreHistory: import("mongoose").Types.DocumentArray<{
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }> & {
        reason: string;
        timestamp: NativeDate;
        change: number;
        newScore: number;
    }>;
    name?: string | null | undefined;
    userType?: "farmer" | "buyer" | "both" | null | undefined;
    location?: {
        latitude: number;
        longitude: number;
        country: string;
        locationType: "gps" | "manual";
        isVerified: boolean;
        lastUpdated: NativeDate;
        addressLine1?: string | null | undefined;
        addressLine2?: string | null | undefined;
        city?: string | null | undefined;
        district?: string | null | undefined;
        state?: string | null | undefined;
        pincode?: string | null | undefined;
    } | null | undefined;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        verified: boolean;
    } | null | undefined;
    languagePreference?: "en" | "hi" | "pa" | "mr" | "ta" | "te" | null | undefined;
    profilePicture?: {
        thumbnailUrl: string;
        uploadedAt: NativeDate;
        url: string;
    } | null | undefined;
    farmSize?: {
        unit: "acres" | "hectares";
        value: number;
    } | null | undefined;
    pinHash?: string | null | undefined;
    lockedUntil?: NativeDate | null | undefined;
    lastLoginAt?: NativeDate | null | undefined;
    referredBy?: string | null | undefined;
    lastStreakDate?: NativeDate | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const PromptTrackingSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    userId: string;
    status: "pending" | "collected" | "user_declined";
    fieldName: string;
    promptCount: number;
    dismissalCount: number;
    lastPromptedAt?: NativeDate | null | undefined;
    lastDismissedAt?: NativeDate | null | undefined;
    collectedAt?: NativeDate | null | undefined;
    collectionSource?: "explicit_prompt" | "implicit_update" | "manual_edit" | "import" | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    userId: string;
    status: "pending" | "collected" | "user_declined";
    fieldName: string;
    promptCount: number;
    dismissalCount: number;
    lastPromptedAt?: NativeDate | null | undefined;
    lastDismissedAt?: NativeDate | null | undefined;
    collectedAt?: NativeDate | null | undefined;
    collectionSource?: "explicit_prompt" | "implicit_update" | "manual_edit" | "import" | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    userId: string;
    status: "pending" | "collected" | "user_declined";
    fieldName: string;
    promptCount: number;
    dismissalCount: number;
    lastPromptedAt?: NativeDate | null | undefined;
    lastDismissedAt?: NativeDate | null | undefined;
    collectedAt?: NativeDate | null | undefined;
    collectionSource?: "explicit_prompt" | "implicit_update" | "manual_edit" | "import" | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const PointsTransactionSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    userId: string;
    transactionId: string;
    type: "earn" | "redeem";
    description: string;
    timestamp: NativeDate;
    points: number;
    activity: string;
    metadata?: any;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    userId: string;
    transactionId: string;
    type: "earn" | "redeem";
    description: string;
    timestamp: NativeDate;
    points: number;
    activity: string;
    metadata?: any;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    userId: string;
    transactionId: string;
    type: "earn" | "redeem";
    description: string;
    timestamp: NativeDate;
    points: number;
    activity: string;
    metadata?: any;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const ReferralSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    status: "registered" | "active" | "inactive";
    referralCode: string;
    referralId: string;
    referrerId: string;
    refereeId: string;
    registrationDate: NativeDate;
    registrationPointsAwarded: boolean;
    transactionPointsAwarded: boolean;
    firstTransactionDate?: NativeDate | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    status: "registered" | "active" | "inactive";
    referralCode: string;
    referralId: string;
    referrerId: string;
    refereeId: string;
    registrationDate: NativeDate;
    registrationPointsAwarded: boolean;
    transactionPointsAwarded: boolean;
    firstTransactionDate?: NativeDate | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    status: "registered" | "active" | "inactive";
    referralCode: string;
    referralId: string;
    referrerId: string;
    refereeId: string;
    registrationDate: NativeDate;
    registrationPointsAwarded: boolean;
    transactionPointsAwarded: boolean;
    firstTransactionDate?: NativeDate | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
//# sourceMappingURL=profile.schema.d.ts.map