/**
 * Profile Field Validators
 *
 * Validation functions for all profile fields.
 */
export interface ValidationResult {
    valid: boolean;
    error?: string;
}
/**
 * Validate mobile number (Indian format)
 */
export declare function validateMobileNumber(mobileNumber: string): ValidationResult;
/**
 * Validate name
 */
export declare function validateName(name: string): ValidationResult;
/**
 * Validate location coordinates or text
 */
export declare function validateLocation(location: any): ValidationResult;
/**
 * Validate farm size
 */
export declare function validateFarmSize(farmSize: {
    value: number;
    unit: string;
}): ValidationResult;
/**
 * Validate language preference
 */
export declare function validateLanguage(language: string): ValidationResult;
/**
 * Validate user type
 */
export declare function validateUserType(userType: string): ValidationResult;
/**
 * Validate profile picture file
 */
export declare function validateProfilePicture(file: {
    size: number;
    mimetype: string;
}): ValidationResult;
/**
 * Validate any profile field
 */
export declare function validateField(fieldName: string, value: any): ValidationResult;
//# sourceMappingURL=validators.d.ts.map