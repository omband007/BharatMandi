"use strict";
/**
 * Profile Field Validators
 *
 * Validation functions for all profile fields.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateMobileNumber = validateMobileNumber;
exports.validateName = validateName;
exports.validateLocation = validateLocation;
exports.validateFarmSize = validateFarmSize;
exports.validateLanguage = validateLanguage;
exports.validateUserType = validateUserType;
exports.validateProfilePicture = validateProfilePicture;
exports.validateField = validateField;
const profile_constants_1 = require("../constants/profile.constants");
/**
 * Validate mobile number (Indian format)
 */
function validateMobileNumber(mobileNumber) {
    const cleaned = mobileNumber.replace(/[\s-]/g, '');
    if (cleaned.length !== profile_constants_1.VALIDATION_RULES.MOBILE_NUMBER.LENGTH) {
        return {
            valid: false,
            error: `Mobile number must be ${profile_constants_1.VALIDATION_RULES.MOBILE_NUMBER.LENGTH} digits`
        };
    }
    if (!profile_constants_1.VALIDATION_RULES.MOBILE_NUMBER.PATTERN.test(cleaned)) {
        return {
            valid: false,
            error: 'Invalid Indian mobile number format. Must start with 6-9'
        };
    }
    return { valid: true };
}
/**
 * Validate name
 */
function validateName(name) {
    if (typeof name !== 'string') {
        return { valid: false, error: 'Name must be a string' };
    }
    if (name.length < profile_constants_1.VALIDATION_RULES.NAME.MIN_LENGTH) {
        return {
            valid: false,
            error: `Name must be at least ${profile_constants_1.VALIDATION_RULES.NAME.MIN_LENGTH} characters`
        };
    }
    if (name.length > profile_constants_1.VALIDATION_RULES.NAME.MAX_LENGTH) {
        return {
            valid: false,
            error: `Name must not exceed ${profile_constants_1.VALIDATION_RULES.NAME.MAX_LENGTH} characters`
        };
    }
    if (!profile_constants_1.VALIDATION_RULES.NAME.PATTERN.test(name)) {
        return {
            valid: false,
            error: 'Name can only contain letters and spaces'
        };
    }
    return { valid: true };
}
/**
 * Validate location coordinates or text
 */
function validateLocation(location) {
    if (!location || typeof location !== 'object') {
        return {
            valid: false,
            error: 'Location must be an object'
        };
    }
    // Handle manual text location
    if (location.type === 'manual' && location.text) {
        if (typeof location.text !== 'string' || location.text.length < 3) {
            return {
                valid: false,
                error: 'Location text must be at least 3 characters'
            };
        }
        return { valid: true };
    }
    // Handle GPS coordinates
    if (location.type === 'gps' || (location.latitude && location.longitude)) {
        if (!location.latitude || !location.longitude) {
            return {
                valid: false,
                error: 'GPS location must include latitude and longitude'
            };
        }
        // Validate coordinates are within India boundaries (approximate)
        // India: Latitude 6°N to 37°N, Longitude 68°E to 98°E
        if (location.latitude < 6 ||
            location.latitude > 37 ||
            location.longitude < 68 ||
            location.longitude > 98) {
            return {
                valid: false,
                error: 'Location coordinates must be within India boundaries'
            };
        }
        return { valid: true };
    }
    return {
        valid: false,
        error: 'Location must include either text (manual) or coordinates (GPS)'
    };
}
/**
 * Validate farm size
 */
function validateFarmSize(farmSize) {
    if (!farmSize.value || !farmSize.unit) {
        return {
            valid: false,
            error: 'Farm size must include value and unit'
        };
    }
    if (typeof farmSize.value !== 'number') {
        return {
            valid: false,
            error: 'Farm size value must be a number'
        };
    }
    if (farmSize.value < profile_constants_1.VALIDATION_RULES.FARM_SIZE.MIN ||
        farmSize.value > profile_constants_1.VALIDATION_RULES.FARM_SIZE.MAX) {
        return {
            valid: false,
            error: `Farm size must be between ${profile_constants_1.VALIDATION_RULES.FARM_SIZE.MIN} and ${profile_constants_1.VALIDATION_RULES.FARM_SIZE.MAX}`
        };
    }
    if (!['acres', 'hectares'].includes(farmSize.unit)) {
        return {
            valid: false,
            error: 'Farm size unit must be acres or hectares'
        };
    }
    return { valid: true };
}
/**
 * Validate language preference
 */
function validateLanguage(language) {
    if (!profile_constants_1.SUPPORTED_LANGUAGES.includes(language)) {
        return {
            valid: false,
            error: `Language must be one of: ${profile_constants_1.SUPPORTED_LANGUAGES.join(', ')}`
        };
    }
    return { valid: true };
}
/**
 * Validate user type
 */
function validateUserType(userType) {
    if (!['farmer', 'buyer', 'both'].includes(userType)) {
        return {
            valid: false,
            error: 'User type must be farmer, buyer, or both'
        };
    }
    return { valid: true };
}
/**
 * Validate profile picture file
 */
function validateProfilePicture(file) {
    const maxSizeBytes = profile_constants_1.VALIDATION_RULES.PROFILE_PICTURE.MAX_SIZE_MB * 1024 * 1024;
    if (file.size > maxSizeBytes) {
        return {
            valid: false,
            error: `Profile picture must be less than ${profile_constants_1.VALIDATION_RULES.PROFILE_PICTURE.MAX_SIZE_MB}MB`
        };
    }
    if (!profile_constants_1.VALIDATION_RULES.PROFILE_PICTURE.ALLOWED_FORMATS.includes(file.mimetype)) {
        return {
            valid: false,
            error: `Profile picture must be one of: ${profile_constants_1.VALIDATION_RULES.PROFILE_PICTURE.ALLOWED_FORMATS.join(', ')}`
        };
    }
    return { valid: true };
}
/**
 * Validate any profile field
 */
function validateField(fieldName, value) {
    switch (fieldName) {
        case 'mobileNumber':
            return validateMobileNumber(value);
        case 'name':
            return validateName(value);
        case 'location':
            return validateLocation(value);
        case 'farmSize':
            return validateFarmSize(value);
        case 'languagePreference':
            return validateLanguage(value);
        case 'userType':
            return validateUserType(value);
        default:
            // Unknown field - allow it
            return { valid: true };
    }
}
//# sourceMappingURL=validators.js.map