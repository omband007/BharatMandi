export declare const usersController: import("express-serve-static-core").Router;
//# sourceMappingURL=users.controller.d.ts.map