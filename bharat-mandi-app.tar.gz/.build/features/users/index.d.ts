export { usersController } from './users.controller';
//# sourceMappingURL=index.d.ts.map