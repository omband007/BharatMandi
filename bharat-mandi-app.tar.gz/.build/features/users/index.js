"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usersController = void 0;
// Public API - only export what other features need
var users_controller_1 = require("./users.controller");
Object.defineProperty(exports, "usersController", { enumerable: true, get: function () { return users_controller_1.usersController; } });
//# sourceMappingURL=index.js.map