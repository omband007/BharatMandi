import { ProduceGrade } from '../../../shared/types/common.types';
interface CropAnalysis {
    cropType: string;
    grade: ProduceGrade;
    confidence: number;
    details: {
        size: string;
        color: string;
        defects: string;
    };
}
export declare class AIVisionService {
    private readonly HF_API_URL;
    private readonly cropKeywords;
    analyzeImage(imageBuffer: Buffer): Promise<CropAnalysis>;
    private preprocessImage;
    private detectCrop;
    private detectCropByColor;
    private matchCropType;
    private analyzeQuality;
    private calculateSaturation;
    private calculateColorUniformity;
    private calculateBrightness;
    private categorizeSize;
    private calculateGrade;
    private fallbackAnalysis;
}
export declare const aiVisionService: AIVisionService;
export {};
//# sourceMappingURL=ai-vision.service.d.ts.map