import type { GradingResult, DigitalQualityCertificate } from './grading.types';
export declare class GradingService {
    gradeProduceImage(imageBuffer: Buffer, location: {
        lat: number;
        lng: number;
    }): Promise<{
        gradingResult: GradingResult;
        analysis: any;
    }>;
    generateCertificate(farmerId: string, produceType: string, gradingResult: GradingResult, imageBuffer: Buffer, detectedCrop?: string): DigitalQualityCertificate;
}
export declare const gradingService: GradingService;
//# sourceMappingURL=grading.service.d.ts.map