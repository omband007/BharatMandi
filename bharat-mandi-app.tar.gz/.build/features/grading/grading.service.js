"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.gradingService = exports.GradingService = void 0;
// AI-powered grading service with real image analysis
const uuid_1 = require("uuid");
const crypto_1 = __importDefault(require("crypto"));
const memory_db_1 = require("../../shared/database/memory-db");
const ai_vision_service_1 = require("./ai/ai-vision.service");
class GradingService {
    // AI-powered grading with real image analysis
    async gradeProduceImage(imageBuffer, location) {
        // Use AI to analyze the image
        const analysis = await ai_vision_service_1.aiVisionService.analyzeImage(imageBuffer);
        const gradingResult = {
            grade: analysis.grade,
            confidence: analysis.confidence,
            timestamp: new Date(),
            location: {
                latitude: location.lat,
                longitude: location.lng,
                address: '' // Empty for now, can be filled with reverse geocoding
            }
        };
        return {
            gradingResult,
            analysis: {
                detectedCrop: analysis.cropType,
                details: analysis.details
            }
        };
    }
    // Generate digital quality certificate
    generateCertificate(farmerId, produceType, gradingResult, imageBuffer, detectedCrop) {
        // Generate image hash for certificate
        const imageHash = crypto_1.default.createHash('sha256').update(imageBuffer).digest('hex').substring(0, 16);
        // Use detected crop if available
        const finalProduceType = detectedCrop && detectedCrop !== 'unknown' ? detectedCrop : produceType;
        const certificate = {
            id: (0, uuid_1.v4)(),
            farmerId,
            produceType: finalProduceType,
            grade: gradingResult.grade,
            timestamp: gradingResult.timestamp,
            location: gradingResult.location,
            imageHash
        };
        return memory_db_1.db.createCertificate(certificate);
    }
}
exports.GradingService = GradingService;
exports.gradingService = new GradingService();
//# sourceMappingURL=grading.service.js.map