export declare const gradingController: import("express-serve-static-core").Router;
//# sourceMappingURL=grading.controller.d.ts.map