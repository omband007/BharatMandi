"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.gradingService = exports.gradingController = void 0;
// Public API - only export what other features need
var grading_controller_1 = require("./grading.controller");
Object.defineProperty(exports, "gradingController", { enumerable: true, get: function () { return grading_controller_1.gradingController; } });
var grading_service_1 = require("./grading.service");
Object.defineProperty(exports, "gradingService", { enumerable: true, get: function () { return grading_service_1.gradingService; } });
//# sourceMappingURL=index.js.map