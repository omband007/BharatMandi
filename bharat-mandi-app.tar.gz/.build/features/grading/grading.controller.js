"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.gradingController = void 0;
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const grading_service_1 = require("./grading.service");
const router = (0, express_1.Router)();
// Configure multer for memory storage
const upload = (0, multer_1.default)({
    storage: multer_1.default.memoryStorage(),
    limits: {
        fileSize: 10 * 1024 * 1024 // 10MB limit
    },
    fileFilter: (req, file, cb) => {
        // Accept images only
        if (!file.mimetype.startsWith('image/')) {
            return cb(new Error('Only image files are allowed'));
        }
        cb(null, true);
    }
});
// POST /api/grading/grade-with-image - Grade produce with actual image upload
router.post('/grade-with-image', upload.single('image'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No image file uploaded' });
        }
        const { farmerId, produceType, lat, lng, autoDetect } = req.body;
        if (!farmerId || !lat || !lng) {
            return res.status(400).json({
                error: 'Missing required fields: farmerId, lat, lng'
            });
        }
        const location = {
            lat: parseFloat(lat),
            lng: parseFloat(lng)
        };
        const shouldAutoDetect = autoDetect === 'true';
        // Grade the image using AI
        const { gradingResult, analysis } = await grading_service_1.gradingService.gradeProduceImage(req.file.buffer, location);
        // Determine final produce type
        let finalProduceType = produceType || 'unknown';
        if (shouldAutoDetect && analysis.detectedCrop !== 'unknown') {
            finalProduceType = analysis.detectedCrop;
        }
        // Generate certificate
        const certificate = grading_service_1.gradingService.generateCertificate(farmerId, finalProduceType, gradingResult, req.file.buffer, analysis.detectedCrop);
        res.json({
            gradingResult,
            certificate,
            analysis
        });
    }
    catch (error) {
        console.error('Grading error:', error);
        res.status(500).json({ error: error.message || 'Failed to grade image' });
    }
});
// POST /api/grading/grade - Legacy endpoint (base64)
router.post('/grade', async (req, res) => {
    try {
        const { farmerId, produceType, imageData, location } = req.body;
        if (!farmerId || !produceType || !imageData || !location) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        // Convert base64 to buffer if needed
        let imageBuffer;
        if (imageData.startsWith('data:image')) {
            const base64Data = imageData.split(',')[1];
            imageBuffer = Buffer.from(base64Data, 'base64');
        }
        else {
            imageBuffer = Buffer.from(imageData, 'base64');
        }
        // Grade the image
        const { gradingResult, analysis } = await grading_service_1.gradingService.gradeProduceImage(imageBuffer, location);
        // Generate certificate
        const certificate = grading_service_1.gradingService.generateCertificate(farmerId, produceType, gradingResult, imageBuffer, analysis.detectedCrop);
        res.json({
            gradingResult,
            certificate,
            analysis
        });
    }
    catch (error) {
        console.error('Grading error:', error);
        res.status(500).json({ error: error.message || 'Failed to grade image' });
    }
});
// GET /api/grading/certificates - Get certificates by farmer ID
router.get('/certificates', async (req, res) => {
    try {
        const { farmerId } = req.query;
        if (!farmerId) {
            return res.status(400).json({ error: 'farmerId query parameter is required' });
        }
        // Get all certificates from memory DB
        const { db } = await Promise.resolve().then(() => __importStar(require('../../shared/database/memory-db')));
        const allCertificates = Array.from(db['certificates'].values());
        // Filter by farmer ID
        const farmerCertificates = allCertificates.filter(cert => cert.farmerId === farmerId);
        res.json(farmerCertificates);
    }
    catch (error) {
        console.error('Get certificates error:', error);
        res.status(500).json({ error: error.message || 'Failed to fetch certificates' });
    }
});
// Export as gradingController for feature-based architecture
exports.gradingController = router;
//# sourceMappingURL=grading.controller.js.map