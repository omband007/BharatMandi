/**
 * Voice Controller
 *
 * Handles HTTP requests for voice operations:
 * - Speech-to-text (transcription)
 * - Text-to-speech (synthesis)
 */
export declare const voiceController: import("express-serve-static-core").Router;
//# sourceMappingURL=voice.controller.d.ts.map