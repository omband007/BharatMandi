"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const i18n_controller_1 = require("./i18n.controller");
const router = (0, express_1.Router)();
// Get translation bundle for a specific language
router.get('/translations/:lang', (req, res) => i18n_controller_1.i18nController.getTranslations(req, res));
// Get list of supported languages
router.get('/languages', (req, res) => i18n_controller_1.i18nController.getSupportedLanguages(req, res));
// Validate translation completeness
router.get('/validate', (req, res) => i18n_controller_1.i18nController.validateTranslations(req, res));
// Change user language preference
router.post('/change-language', (req, res) => i18n_controller_1.i18nController.changeLanguage(req, res));
// Get user language preference
router.get('/user-language/:userId', (req, res) => i18n_controller_1.i18nController.getUserLanguage(req, res));
// Translate text using AWS Translate
router.post('/translate', (req, res) => i18n_controller_1.i18nController.translateText(req, res));
// Translate multiple texts in batch
router.post('/translate-batch', (req, res) => i18n_controller_1.i18nController.translateBatch(req, res));
// Detect language of text
router.post('/detect-language', (req, res) => i18n_controller_1.i18nController.detectLanguage(req, res));
// Get cache statistics
router.get('/cache-stats', (req, res) => i18n_controller_1.i18nController.getCacheStats(req, res));
// Submit translation feedback
router.post('/translate/feedback', (req, res) => i18n_controller_1.i18nController.submitTranslationFeedback(req, res));
// Get translation feedback statistics
router.get('/translate/feedback/stats', (req, res) => i18n_controller_1.i18nController.getTranslationFeedbackStats(req, res));
exports.default = router;
//# sourceMappingURL=i18n.routes.js.map