declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=i18n.routes.d.ts.map