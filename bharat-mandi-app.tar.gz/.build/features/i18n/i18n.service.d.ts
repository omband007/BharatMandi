export interface LanguageConfig {
    code: string;
    name: string;
    direction: 'ltr' | 'rtl';
    dateFormat: string;
    numberFormat: string;
    currencyFormat: string;
}
export declare const SUPPORTED_LANGUAGES: LanguageConfig[];
export declare class I18nService {
    private initialized;
    initialize(defaultLanguage?: string): Promise<void>;
    private loadAllBundles;
    changeLanguage(userId: string, languageCode: string): Promise<void>;
    getUserLanguagePreference(userId: string): Promise<string>;
    updateUserLanguagePreference(userId: string, languageCode: string): Promise<void>;
    translate(key: string, options?: any): string;
    formatDate(date: Date, languageCode: string): string;
    formatNumber(value: number, languageCode: string): string;
    formatCurrency(value: number, languageCode: string): string;
    getCurrentLanguage(): string;
    getSupportedLanguages(): LanguageConfig[];
    validateTranslationCompleteness(): Promise<{
        missing: string[];
        incomplete: string[];
    }>;
    private getAllKeys;
    private flattenKeys;
}
export declare const i18nService: I18nService;
//# sourceMappingURL=i18n.service.d.ts.map