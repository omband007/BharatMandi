"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.i18nextBackend = exports.i18nextMiddleware = void 0;
const i18next_1 = __importDefault(require("i18next"));
exports.i18nextBackend = i18next_1.default;
const i18next_fs_backend_1 = __importDefault(require("i18next-fs-backend"));
const i18next_http_middleware_1 = __importDefault(require("i18next-http-middleware"));
const path_1 = __importDefault(require("path"));
const i18n_service_1 = require("./i18n.service");
// Initialize i18next for backend
i18next_1.default
    .use(i18next_fs_backend_1.default)
    .use(i18next_http_middleware_1.default.LanguageDetector)
    .init({
    fallbackLng: 'en',
    supportedLngs: i18n_service_1.SUPPORTED_LANGUAGES.map(l => l.code),
    preload: i18n_service_1.SUPPORTED_LANGUAGES.map(l => l.code),
    backend: {
        loadPath: path_1.default.join(__dirname, 'locales/{{lng}}/translation.json'),
    },
    detection: {
        order: ['header', 'querystring', 'cookie'],
        caches: false, // Don't cache on server
        lookupHeader: 'accept-language',
        lookupQuerystring: 'lang',
        lookupCookie: 'i18next',
    },
    interpolation: {
        escapeValue: false,
    },
    saveMissing: false,
    // Log missing keys in development
    missingKeyHandler: (lng, ns, key) => {
        if (process.env.NODE_ENV === 'development') {
            console.warn(`[i18n Backend] Missing translation key: ${key} for language: ${lng}`);
        }
    },
});
exports.i18nextMiddleware = i18next_http_middleware_1.default.handle(i18next_1.default);
//# sourceMappingURL=i18n-backend.config.js.map