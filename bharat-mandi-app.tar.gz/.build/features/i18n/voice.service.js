"use strict";
/**
 * Voice Service
 *
 * Handles speech-to-text (AWS Transcribe) and text-to-speech (AWS Polly) operations
 * for multi-language voice interface support.
 *
 * Features:
 * - Audio transcription with language detection
 * - Speech synthesis with voice selection
 * - Audio caching for offline playback
 * - S3 integration for temporary audio storage
 *
 * Requirements: 6.1, 6.6, 6.13, 7.1, 7.4, 7.5, 7.12, 7.13
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.voiceService = exports.VoiceService = void 0;
const client_transcribe_1 = require("@aws-sdk/client-transcribe");
const client_polly_1 = require("@aws-sdk/client-polly");
const client_s3_1 = require("@aws-sdk/client-s3");
const uuid_1 = require("uuid");
const crypto_1 = __importDefault(require("crypto"));
const audio_cache_service_1 = require("./audio-cache.service");
/**
 * Language code mapping: our codes to AWS Transcribe codes
 */
const LANGUAGE_CODE_MAP = {
    'en': 'en-IN',
    'hi': 'hi-IN',
    'pa': 'en-IN', // Punjabi not supported, fallback to English
    'mr': 'en-IN', // Marathi not supported, fallback to English
    'ta': 'ta-IN',
    'te': 'te-IN',
    'bn': 'en-IN', // Bengali not supported, fallback to English
    'gu': 'en-IN', // Gujarati not supported, fallback to English
    'kn': 'en-IN', // Kannada not supported, fallback to English
    'ml': 'en-IN', // Malayalam not supported, fallback to English
    'or': 'en-IN' // Odia not supported, fallback to English
};
/**
 * Reverse mapping: AWS Transcribe codes to our codes
 */
const REVERSE_LANGUAGE_CODE_MAP = {
    'en-IN': 'en',
    'hi-IN': 'hi',
    'ta-IN': 'ta',
    'te-IN': 'te'
};
/**
 * Voice ID mapping for AWS Polly
 * Maps our language codes to AWS Polly voice IDs
 *
 * IMPORTANT: AWS Polly voices can only read text in their native script.
 * - Hindi (Aditi): Can read Devanagari script only
 * - English (Raveena): Can read Latin script only
 *
 * For all non-Hindi Indian languages, we use English voice with English text
 * since Polly cannot read regional scripts (Gujarati, Tamil, Telugu, etc.)
 */
const VOICE_ID_MAP = {
    'en': 'Raveena', // Indian English female
    'hi': 'Aditi', // Hindi female - ONLY language with native support
    'pa': 'Raveena', // Punjabi - use English voice with English text
    'mr': 'Raveena', // Marathi - use English voice with English text
    'ta': 'Raveena', // Tamil - use English voice with English text
    'te': 'Raveena', // Telugu - use English voice with English text
    'bn': 'Raveena', // Bengali - use English voice with English text
    'gu': 'Raveena', // Gujarati - use English voice with English text
    'kn': 'Raveena', // Kannada - use English voice with English text
    'ml': 'Raveena', // Malayalam - use English voice with English text
    'or': 'Raveena' // Odia - use English voice with English text
};
/**
 * Voice Service
 *
 * Provides speech-to-text and text-to-speech capabilities using AWS services.
 */
class VoiceService {
    constructor() {
        const awsRegion = process.env.AWS_REGION || 'ap-south-1';
        const s3Bucket = process.env.AWS_S3_VOICE_BUCKET || 'bharat-mandi-voice-temp';
        this.config = {
            awsRegion,
            s3Bucket,
            transcribeClient: new client_transcribe_1.TranscribeClient({ region: awsRegion }),
            pollyClient: new client_polly_1.PollyClient({ region: awsRegion }),
            s3Client: new client_s3_1.S3Client({ region: awsRegion }),
            ttsCache: new Map(),
            audioCache: audio_cache_service_1.audioCacheService
        };
    }
    /**
     * Transcribe audio to text using AWS Transcribe
     *
     * Requirements: 6.1, 6.6, 6.13
     *
     * @param request - Transcription request with audio buffer and metadata
     * @returns Transcription response with text and detected language
     */
    async transcribeAudio(request) {
        try {
            // 1. Generate unique job name
            const jobName = `transcribe-${(0, uuid_1.v4)()}`;
            const s3Key = `audio/${jobName}.${request.audioFormat}`;
            // 2. Upload audio to S3
            await this.uploadAudioToS3(request.audioBuffer, s3Key, request.audioFormat);
            // 3. Start transcription job
            const languageCode = request.language
                ? LANGUAGE_CODE_MAP[request.language]
                : 'en-IN';
            const startCommand = new client_transcribe_1.StartTranscriptionJobCommand({
                TranscriptionJobName: jobName,
                LanguageCode: languageCode,
                MediaFormat: request.audioFormat,
                Media: {
                    MediaFileUri: `s3://${this.config.s3Bucket}/${s3Key}`
                }
                // Note: Removed Settings.ShowSpeakerLabels and MaxSpeakerLabels
                // AWS Transcribe requires MaxSpeakerLabels >= 2 when ShowSpeakerLabels is true
                // For simple transcription, we don't need speaker labels
            });
            await this.config.transcribeClient.send(startCommand);
            // 4. Poll for completion
            const transcriptionResult = await this.pollTranscriptionJob(jobName);
            // 5. Clean up S3 audio file
            await this.deleteAudioFromS3(s3Key);
            // 6. Parse and return result
            if (transcriptionResult && transcriptionResult.Transcript) {
                const transcriptUri = transcriptionResult.Transcript.TranscriptFileUri;
                if (transcriptUri) {
                    const transcriptText = await this.fetchTranscript(transcriptUri);
                    const detectedLanguage = this.mapTranscribeLanguageCode(transcriptionResult.LanguageCode);
                    return {
                        text: transcriptText,
                        detectedLanguage,
                        confidence: 0.9, // AWS Transcribe doesn't provide overall confidence
                        success: true
                    };
                }
            }
            throw new Error('Transcription failed: No transcript available');
        }
        catch (error) {
            console.error('[VoiceService] Transcription error:', error);
            return {
                text: '',
                success: false,
                error: error instanceof Error ? error.message : 'Transcription failed'
            };
        }
    }
    /**
     * Upload audio buffer to S3
     *
     * @param audioBuffer - Audio data
     * @param s3Key - S3 object key
     * @param format - Audio format
     */
    async uploadAudioToS3(audioBuffer, s3Key, format) {
        const contentType = this.getContentType(format);
        const command = new client_s3_1.PutObjectCommand({
            Bucket: this.config.s3Bucket,
            Key: s3Key,
            Body: audioBuffer,
            ContentType: contentType
        });
        await this.config.s3Client.send(command);
    }
    /**
     * Delete audio file from S3
     *
     * Requirements: 19.3
     *
     * @param s3Key - S3 object key
     */
    async deleteAudioFromS3(s3Key) {
        try {
            const command = new client_s3_1.DeleteObjectCommand({
                Bucket: this.config.s3Bucket,
                Key: s3Key
            });
            await this.config.s3Client.send(command);
        }
        catch (error) {
            console.error('[VoiceService] Failed to delete audio from S3:', error);
            // Non-fatal error, continue
        }
    }
    /**
     * Poll transcription job until completion
     *
     * @param jobName - Transcription job name
     * @returns Transcription job result
     */
    async pollTranscriptionJob(jobName, maxAttempts = 60, intervalMs = 2000) {
        for (let attempt = 0; attempt < maxAttempts; attempt++) {
            const command = new client_transcribe_1.GetTranscriptionJobCommand({
                TranscriptionJobName: jobName
            });
            const response = await this.config.transcribeClient.send(command);
            const job = response.TranscriptionJob;
            if (!job) {
                throw new Error('Transcription job not found');
            }
            if (job.TranscriptionJobStatus === 'COMPLETED') {
                return job;
            }
            if (job.TranscriptionJobStatus === 'FAILED') {
                throw new Error(`Transcription failed: ${job.FailureReason}`);
            }
            // Wait before next poll
            await new Promise(resolve => setTimeout(resolve, intervalMs));
        }
        throw new Error('Transcription timeout: Job did not complete in time');
    }
    /**
     * Fetch transcript text from S3 URL
     *
     * @param transcriptUri - S3 URI of transcript JSON
     * @returns Transcript text
     */
    async fetchTranscript(transcriptUri) {
        try {
            const response = await fetch(transcriptUri);
            const data = await response.json();
            // AWS Transcribe transcript format
            if (data.results && data.results.transcripts && data.results.transcripts[0]) {
                return data.results.transcripts[0].transcript;
            }
            throw new Error('Invalid transcript format');
        }
        catch (error) {
            console.error('[VoiceService] Failed to fetch transcript:', error);
            throw error;
        }
    }
    /**
     * Map AWS Transcribe language code to our language code
     *
     * @param transcribeCode - AWS Transcribe language code
     * @returns Our language code
     */
    mapTranscribeLanguageCode(transcribeCode) {
        return REVERSE_LANGUAGE_CODE_MAP[transcribeCode] || 'en';
    }
    /**
     * Get content type for audio format
     *
     * @param format - Audio format
     * @returns MIME type
     */
    getContentType(format) {
        const contentTypes = {
            'mp3': 'audio/mpeg',
            'wav': 'audio/wav',
            'flac': 'audio/flac',
            'ogg': 'audio/ogg'
        };
        return contentTypes[format] || 'application/octet-stream';
    }
    /**
     * Synthesize speech from text using AWS Polly
     *
     * Requirements: 7.1, 7.4, 7.5, 7.12, 7.13, 7.14
     *
     * @param request - Synthesis request with text and language
     * @returns Synthesis response with audio URL
     */
    async synthesizeSpeech(request) {
        try {
            // The text is already in the target language from the translation service
            // We just need to select the appropriate voice
            const textToSpeak = request.text;
            console.log(`[VoiceService] Synthesizing speech for ${request.language}: "${textToSpeak.substring(0, 100)}..."`);
            // 1. Generate cache key
            const cacheKey = this.generateTTSCacheKey(textToSpeak, request.language, request.speed || 1.0);
            // 2. Check local audio cache first (for offline support)
            const cachedAudio = this.config.audioCache.getCachedAudio(cacheKey);
            if (cachedAudio) {
                console.log(`[VoiceService] Using cached audio for ${request.language}`);
                // Return cached audio as data URL for offline playback
                const base64Audio = cachedAudio.audioData.toString('base64');
                const audioUrl = `data:audio/mpeg;base64,${base64Audio}`;
                return {
                    audioUrl,
                    audioBuffer: cachedAudio.audioData,
                    success: true
                };
            }
            // 3. Check in-memory cache (S3 URLs)
            const cachedUrl = this.config.ttsCache.get(cacheKey);
            if (cachedUrl) {
                console.log(`[VoiceService] Using cached S3 URL for ${request.language}`);
                return {
                    audioUrl: cachedUrl,
                    success: true
                };
            }
            // 4. Get voice ID for language
            const voiceId = VOICE_ID_MAP[request.language];
            console.log(`[VoiceService] Using voice: ${voiceId} for language: ${request.language}`);
            // 5. Prepare text with SSML if speed adjustment needed
            let textToSynthesize = textToSpeak;
            let textType = 'text';
            if (request.ssml) {
                textType = 'ssml';
            }
            else if (request.speed && request.speed !== 1.0) {
                // Wrap in SSML for speed control
                const speedPercent = Math.round(request.speed * 100);
                textToSynthesize = `<speak><prosody rate="${speedPercent}%">${textToSpeak}</prosody></speak>`;
                textType = 'ssml';
            }
            // 6. Synthesize speech - try neural first, fallback to standard
            let response;
            try {
                const command = new client_polly_1.SynthesizeSpeechCommand({
                    Text: textToSynthesize,
                    TextType: textType,
                    VoiceId: voiceId,
                    OutputFormat: 'mp3',
                    Engine: 'neural', // Try neural engine for better quality
                    LanguageCode: this.getPollyLanguageCode(request.language)
                });
                response = await this.config.pollyClient.send(command);
            }
            catch (error) {
                // If neural engine not supported, fallback to standard engine
                if (error.message && error.message.includes('does not support the selected engine')) {
                    console.log(`[VoiceService] Neural engine not supported for ${voiceId}, falling back to standard`);
                    const standardCommand = new client_polly_1.SynthesizeSpeechCommand({
                        Text: textToSynthesize,
                        TextType: textType,
                        VoiceId: voiceId,
                        OutputFormat: 'mp3',
                        Engine: 'standard', // Fallback to standard engine
                        LanguageCode: this.getPollyLanguageCode(request.language)
                    });
                    response = await this.config.pollyClient.send(standardCommand);
                }
                else {
                    throw error;
                }
            }
            if (!response.AudioStream) {
                throw new Error('No audio stream in response');
            }
            // 7. Convert stream to buffer
            const audioBuffer = await this.streamToBuffer(response.AudioStream);
            // 8. Store in local audio cache for offline playback
            await this.config.audioCache.storeCachedAudio(cacheKey, audioBuffer, request.language, textToSpeak, request.speed || 1.0);
            // 9. Upload to S3
            const s3Key = `tts/${cacheKey}.mp3`;
            await this.uploadAudioToS3(audioBuffer, s3Key, 'mp3');
            // 10. Generate S3 URL
            const audioUrl = `https://${this.config.s3Bucket}.s3.${this.config.awsRegion}.amazonaws.com/${s3Key}`;
            // 11. Cache the URL (7-day TTL handled by S3 lifecycle policy)
            this.config.ttsCache.set(cacheKey, audioUrl);
            console.log(`[VoiceService] Speech synthesis complete for ${request.language}`);
            return {
                audioUrl,
                audioBuffer,
                success: true
            };
        }
        catch (error) {
            console.error('[VoiceService] Speech synthesis error:', error);
            return {
                audioUrl: '',
                success: false,
                error: error instanceof Error ? error.message : 'Speech synthesis failed'
            };
        }
    }
    /**
     * Generate cache key for TTS
     *
     * Requirements: 7.12, 7.13
     *
     * @param text - Text to synthesize
     * @param language - Language code
     * @param speed - Speech speed
     * @returns Cache key
     */
    generateTTSCacheKey(text, language, speed) {
        const data = `${text}|${language}|${speed}`;
        return crypto_1.default.createHash('sha256').update(data).digest('hex');
    }
    /**
     * Get Polly language code from our language code
     *
     * @param languageCode - Our language code
     * @returns Polly language code
     */
    getPollyLanguageCode(languageCode) {
        const pollyLanguageCodes = {
            'en': 'en-IN',
            'hi': 'hi-IN',
            'pa': 'en-IN',
            'mr': 'en-IN',
            'ta': 'en-IN',
            'te': 'en-IN',
            'bn': 'en-IN',
            'gu': 'en-IN',
            'kn': 'en-IN',
            'ml': 'en-IN',
            'or': 'en-IN'
        };
        return pollyLanguageCodes[languageCode];
    }
    /**
     * Convert readable stream to buffer
     *
     * @param stream - Readable stream
     * @returns Buffer
     */
    async streamToBuffer(stream) {
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        return Buffer.concat(chunks);
    }
    /**
     * Clear TTS cache
     *
     * @param cacheKey - Optional specific cache key to clear
     */
    clearTTSCache(cacheKey) {
        if (cacheKey) {
            this.config.ttsCache.delete(cacheKey);
        }
        else {
            this.config.ttsCache.clear();
        }
    }
    /**
     * Get TTS cache statistics
     *
     * @returns Cache statistics
     */
    getTTSCacheStats() {
        return {
            size: this.config.ttsCache.size,
            keys: Array.from(this.config.ttsCache.keys())
        };
    }
    /**
     * Get audio cache statistics (local SQLite cache)
     *
     * Requirements: 13.8
     *
     * @returns Audio cache statistics
     */
    getAudioCacheStats() {
        return this.config.audioCache.getStats();
    }
    /**
     * Clear audio cache (local SQLite cache)
     *
     * @param cacheKey - Optional specific cache key to clear
     */
    clearAudioCache(cacheKey) {
        if (cacheKey) {
            this.config.audioCache.deleteCachedAudio(cacheKey);
        }
        else {
            this.config.audioCache.clearCache();
        }
    }
    /**
     * Get cached audio by language
     *
     * @param language - Language code
     * @returns Array of cached audio entries
     */
    getCachedAudioByLanguage(language) {
        return this.config.audioCache.getCachedAudioByLanguage(language);
    }
    /**
     * Preload common phrases for offline playback
     *
     * Requirements: 12.6
     *
     * @param language - Language code
     * @param phrases - Array of common phrases to preload
     */
    async preloadCommonPhrases(language, phrases) {
        console.log(`[VoiceService] Preloading ${phrases.length} phrases for ${language}`);
        const preloadPromises = phrases.map(async (phrase) => {
            try {
                // Check if already cached
                const cacheKey = this.generateTTSCacheKey(phrase, language, 1.0);
                const cached = this.config.audioCache.getCachedAudio(cacheKey);
                if (cached) {
                    return; // Already cached
                }
                // Synthesize and cache
                await this.synthesizeSpeech({
                    text: phrase,
                    language,
                    speed: 1.0
                });
            }
            catch (error) {
                console.error(`[VoiceService] Failed to preload phrase: ${phrase}`, error);
            }
        });
        await Promise.all(preloadPromises);
        console.log(`[VoiceService] Preloading complete for ${language}`);
    }
    /**
     * Preload user's recent voice outputs
     *
     * Requirements: 12.6
     *
     * @param language - Language code
     * @param limit - Number of recent entries to preload (default 10)
     */
    async preloadRecentVoiceOutputs(language, limit = 10) {
        try {
            const recentEntries = this.config.audioCache.getCachedAudioByLanguage(language);
            // Sort by last accessed (most recent first) and take top N
            const topEntries = recentEntries
                .sort((a, b) => b.lastAccessedAt.getTime() - a.lastAccessedAt.getTime())
                .slice(0, limit);
            console.log(`[VoiceService] Found ${topEntries.length} recent voice outputs for ${language}`);
            // These are already cached, so just log for monitoring
            for (const entry of topEntries) {
                console.log(`[VoiceService] Cached: "${entry.text.substring(0, 50)}..." (accessed ${entry.accessCount} times)`);
            }
        }
        catch (error) {
            console.error('[VoiceService] Failed to preload recent voice outputs:', error);
        }
    }
    /**
     * Get common phrases for preloading
     *
     * @returns Array of common phrases
     */
    static getCommonPhrases() {
        return [
            // Greetings
            'Welcome to Bharat Mandi',
            'Hello',
            'Good morning',
            'Good afternoon',
            'Good evening',
            // Navigation
            'Home',
            'My Listings',
            'Search',
            'Messages',
            'Profile',
            'Settings',
            // Actions
            'Create Listing',
            'View Orders',
            'Check Prices',
            'Save',
            'Cancel',
            'Submit',
            'Delete',
            'Edit',
            // Notifications
            'New message received',
            'Listing created successfully',
            'Order placed successfully',
            'Payment received',
            'Order completed',
            // Errors
            'Error occurred',
            'Please try again',
            'Invalid input',
            'Connection failed',
            // Voice commands
            'Listening',
            'Processing',
            'Command not recognized',
            'Please speak clearly'
        ];
    }
}
exports.VoiceService = VoiceService;
// Export singleton instance
exports.voiceService = new VoiceService();
//# sourceMappingURL=voice.service.js.map