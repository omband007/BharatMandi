/**
 * Format a date according to the user's locale
 * @param date - Date to format
 * @param languageCode - Language code (e.g., 'hi', 'en')
 * @returns Formatted date string
 */
export declare function formatDate(date: Date, languageCode: string): string;
/**
 * Format a date as relative time (e.g., "2 days ago")
 * @param date - Date to format
 * @param languageCode - Language code
 * @returns Relative time string
 */
export declare function formatRelativeDate(date: Date, languageCode: string): string;
/**
 * Format a number according to the user's locale
 * @param value - Number to format
 * @param languageCode - Language code
 * @returns Formatted number string
 */
export declare function formatNumber(value: number, languageCode: string): string;
/**
 * Format a currency value (INR) according to the user's locale
 * @param value - Amount to format
 * @param languageCode - Language code
 * @returns Formatted currency string
 */
export declare function formatCurrency(value: number, languageCode: string): string;
/**
 * Format a number in Indian numbering system (lakhs, crores)
 * @param value - Number to format
 * @param languageCode - Language code
 * @returns Formatted number with lakhs/crores
 */
export declare function formatIndianNumber(value: number, languageCode: string): string;
/**
 * Format a weight value with appropriate unit
 * @param value - Weight in kg
 * @param languageCode - Language code
 * @returns Formatted weight string
 */
export declare function formatWeight(value: number, languageCode: string): string;
/**
 * Format a percentage value
 * @param value - Percentage value (0-100)
 * @param languageCode - Language code
 * @returns Formatted percentage string
 */
export declare function formatPercentage(value: number, languageCode: string): string;
//# sourceMappingURL=formatting.utils.d.ts.map