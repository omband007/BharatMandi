import { Request, Response } from 'express';
export declare class I18nController {
    /**
     * Get translation bundle for a specific language
     * GET /api/i18n/translations/:lang
     */
    getTranslations(req: Request, res: Response): Promise<void>;
    /**
     * Get list of supported languages
     * GET /api/i18n/languages
     */
    getSupportedLanguages(req: Request, res: Response): Promise<void>;
    /**
     * Validate translation completeness
     * GET /api/i18n/validate
     */
    validateTranslations(req: Request, res: Response): Promise<void>;
    /**
     * Change user language preference
     * POST /api/i18n/change-language
     */
    changeLanguage(req: Request, res: Response): Promise<void>;
    /**
     * Get user language preference
     * GET /api/i18n/user-language/:userId
     */
    getUserLanguage(req: Request, res: Response): Promise<void>;
    /**
     * Translate text using AWS Translate
     * POST /api/i18n/translate
     * Body: { text, sourceLanguage?, targetLanguage }
     */
    translateText(req: Request, res: Response): Promise<void>;
    /**
     * Translate multiple texts in batch
     * POST /api/i18n/translate-batch
     * Body: { texts: string[], sourceLanguage, targetLanguage }
     */
    translateBatch(req: Request, res: Response): Promise<void>;
    /**
     * Detect language of text
     * POST /api/i18n/detect-language
     * Body: { text }
     */
    detectLanguage(req: Request, res: Response): Promise<void>;
    /**
     * Get cache statistics
     * GET /api/i18n/cache-stats
     */
    getCacheStats(req: Request, res: Response): Promise<void>;
    /**
     * Submit translation feedback
     * POST /api/translate/feedback
     * Body: { userId, originalText, translatedText, sourceLanguage, targetLanguage, suggestedTranslation?, feedbackType, context? }
     *
     * Requirements: 16.1, 16.2, 16.3
     */
    submitTranslationFeedback(req: Request, res: Response): Promise<void>;
    /**
     * Get translation feedback statistics
     * GET /api/translate/feedback/stats
     * Query params: targetLanguage? (optional language filter)
     *
     * Requirements: 16.5
     */
    getTranslationFeedbackStats(req: Request, res: Response): Promise<void>;
}
export declare const i18nController: I18nController;
//# sourceMappingURL=i18n.controller.d.ts.map