"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.i18nService = exports.I18nService = exports.SUPPORTED_LANGUAGES = void 0;
const i18next_1 = __importDefault(require("i18next"));
exports.SUPPORTED_LANGUAGES = [
    { code: 'en', name: 'English', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'en-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'hi', name: 'हिन्दी', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'hi-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'pa', name: 'ਪੰਜਾਬੀ', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'pa-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'mr', name: 'मराठी', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'mr-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'ta', name: 'தமிழ்', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'ta-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'te', name: 'తెలుగు', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'te-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'bn', name: 'বাংলা', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'bn-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'gu', name: 'ગુજરાતી', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'gu-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'kn', name: 'ಕನ್ನಡ', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'kn-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'ml', name: 'മലയാളം', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'ml-IN', currencyFormat: '₹#,##,###.##' },
    { code: 'or', name: 'ଓଡ଼ିଆ', direction: 'ltr', dateFormat: 'DD/MM/YYYY', numberFormat: 'or-IN', currencyFormat: '₹#,##,###.##' },
];
class I18nService {
    constructor() {
        this.initialized = false;
    }
    async initialize(defaultLanguage = 'en') {
        if (this.initialized)
            return;
        await i18next_1.default.init({
            lng: defaultLanguage,
            fallbackLng: 'en',
            supportedLngs: exports.SUPPORTED_LANGUAGES.map(l => l.code),
            resources: await this.loadAllBundles(),
            interpolation: {
                escapeValue: false,
            },
            detection: {
                order: ['querystring', 'cookie', 'localStorage', 'navigator'],
                caches: ['localStorage', 'cookie'],
            },
            debug: false, // Suppress i18next maintenance message
        });
        this.initialized = true;
    }
    async loadAllBundles() {
        const resources = {};
        for (const lang of exports.SUPPORTED_LANGUAGES) {
            try {
                // Load from local bundle files
                const bundle = await Promise.resolve(`${`./locales/${lang.code}/translation.json`}`).then(s => __importStar(require(s)));
                resources[lang.code] = { translation: bundle };
            }
            catch (error) {
                console.error(`Failed to load bundle for ${lang.code}:`, error);
            }
        }
        return resources;
    }
    async changeLanguage(userId, languageCode) {
        if (!exports.SUPPORTED_LANGUAGES.find(l => l.code === languageCode)) {
            throw new Error(`Unsupported language: ${languageCode}`);
        }
        await i18next_1.default.changeLanguage(languageCode);
        // Persist preference to database
        const db = global.sharedDbManager;
        if (db) {
            await db.updateUser(userId, {
                languagePreference: languageCode,
                updatedAt: new Date()
            });
        }
    }
    async getUserLanguagePreference(userId) {
        const db = global.sharedDbManager;
        if (!db)
            return 'en';
        const user = await db.getUserById(userId);
        return user?.languagePreference || 'en';
    }
    async updateUserLanguagePreference(userId, languageCode) {
        if (!exports.SUPPORTED_LANGUAGES.find(l => l.code === languageCode)) {
            throw new Error(`Unsupported language: ${languageCode}`);
        }
        const db = global.sharedDbManager;
        if (db) {
            await db.updateUser(userId, {
                languagePreference: languageCode,
                updatedAt: new Date()
            });
        }
    }
    translate(key, options) {
        const translation = i18next_1.default.t(key, options);
        // Log missing translations in development
        if (translation === key && process.env.NODE_ENV === 'development') {
            console.warn(`[I18n] Missing translation key: ${key}`);
        }
        return String(translation);
    }
    formatDate(date, languageCode) {
        // Validate date is not invalid (NaN)
        if (!date || isNaN(date.getTime())) {
            return 'Invalid Date';
        }
        const config = exports.SUPPORTED_LANGUAGES.find(l => l.code === languageCode);
        if (!config)
            return date.toLocaleDateString();
        return new Intl.DateTimeFormat(config.numberFormat).format(date);
    }
    formatNumber(value, languageCode) {
        const config = exports.SUPPORTED_LANGUAGES.find(l => l.code === languageCode);
        if (!config)
            return value.toString();
        return new Intl.NumberFormat(config.numberFormat).format(value);
    }
    formatCurrency(value, languageCode) {
        const config = exports.SUPPORTED_LANGUAGES.find(l => l.code === languageCode);
        if (!config)
            return `₹${value}`;
        return new Intl.NumberFormat(config.numberFormat, {
            style: 'currency',
            currency: 'INR',
        }).format(value);
    }
    getCurrentLanguage() {
        return i18next_1.default.language;
    }
    getSupportedLanguages() {
        return exports.SUPPORTED_LANGUAGES;
    }
    async validateTranslationCompleteness() {
        const englishKeys = this.getAllKeys('en');
        const missing = [];
        const incomplete = [];
        for (const lang of exports.SUPPORTED_LANGUAGES) {
            if (lang.code === 'en')
                continue;
            const langKeys = this.getAllKeys(lang.code);
            const missingKeys = englishKeys.filter(key => !langKeys.includes(key));
            if (missingKeys.length > 0) {
                incomplete.push(lang.code);
                missing.push(...missingKeys.map(key => `${lang.code}:${key}`));
            }
        }
        return { missing, incomplete };
    }
    getAllKeys(languageCode) {
        const bundle = i18next_1.default.getResourceBundle(languageCode, 'translation');
        return this.flattenKeys(bundle);
    }
    flattenKeys(obj, prefix = '') {
        let keys = [];
        for (const key in obj) {
            const fullKey = prefix ? `${prefix}.${key}` : key;
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                keys = keys.concat(this.flattenKeys(obj[key], fullKey));
            }
            else {
                keys.push(fullKey);
            }
        }
        return keys;
    }
}
exports.I18nService = I18nService;
exports.i18nService = new I18nService();
//# sourceMappingURL=i18n.service.js.map