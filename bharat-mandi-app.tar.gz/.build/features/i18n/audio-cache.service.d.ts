/**
 * Audio Cache Service
 *
 * Handles local SQLite caching of TTS audio for offline playback.
 * Implements LRU eviction when cache exceeds 50MB limit.
 *
 * Features:
 * - Local audio storage in SQLite
 * - LRU (Least Recently Used) eviction
 * - Storage monitoring and limits
 * - Cache statistics
 *
 * Requirements: 7.12, 13.2
 */
/**
 * Cached audio entry
 */
export interface CachedAudio {
    id: string;
    cacheKey: string;
    audioData: Buffer;
    language: string;
    text: string;
    speed: number;
    sizeBytes: number;
    createdAt: Date;
    lastAccessedAt: Date;
    accessCount: number;
}
/**
 * Audio cache statistics
 */
export interface AudioCacheStats {
    totalEntries: number;
    totalSizeBytes: number;
    totalSizeMB: number;
    oldestEntry?: Date;
    newestEntry?: Date;
    mostAccessed?: {
        cacheKey: string;
        text: string;
        accessCount: number;
    };
}
/**
 * Audio Cache Service
 *
 * Provides local SQLite caching for TTS audio with LRU eviction.
 */
export declare class AudioCacheService {
    private db;
    private config;
    private readonly MAX_SIZE_BYTES;
    constructor(dbPath?: string);
    /**
     * Initialize database schema
     */
    private initializeDatabase;
    /**
     * Get cached audio by cache key
     *
     * Requirements: 7.12, 13.2
     *
     * @param cacheKey - Cache key
     * @returns Cached audio or null if not found
     */
    getCachedAudio(cacheKey: string): CachedAudio | null;
    /**
     * Store audio in cache
     *
     * Requirements: 7.12, 13.2, 13.8
     *
     * @param cacheKey - Cache key
     * @param audioData - Audio buffer
     * @param language - Language code
     * @param text - Original text
     * @param speed - Speech speed
     */
    storeCachedAudio(cacheKey: string, audioData: Buffer, language: string, text: string, speed: number): Promise<void>;
    /**
     * Update access statistics for cached audio
     *
     * @param cacheKey - Cache key
     */
    private updateAccessStats;
    /**
     * Ensure storage limit is not exceeded using LRU eviction
     *
     * Requirements: 13.8
     *
     * @param newEntrySize - Size of new entry to be added
     */
    private ensureStorageLimit;
    /**
     * Get cache statistics
     *
     * Requirements: 13.8
     *
     * @returns Cache statistics
     */
    getStats(): AudioCacheStats;
    /**
     * Clear all cached audio
     */
    clearCache(): void;
    /**
     * Delete specific cached audio by cache key
     *
     * @param cacheKey - Cache key
     */
    deleteCachedAudio(cacheKey: string): void;
    /**
     * Get cached audio entries by language
     *
     * @param language - Language code
     * @returns Array of cached audio entries
     */
    getCachedAudioByLanguage(language: string): CachedAudio[];
    /**
     * Close database connection
     */
    close(): void;
}
export declare const audioCacheService: AudioCacheService;
//# sourceMappingURL=audio-cache.service.d.ts.map