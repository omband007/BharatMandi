export interface TranslationRequest {
    text: string;
    sourceLanguage?: string;
    targetLanguage: string;
    context?: string;
}
export interface TranslationResult {
    translatedText: string;
    sourceLanguage: string;
    targetLanguage: string;
    confidence: number;
    cached: boolean;
}
export declare class TranslationService {
    private readonly CACHE_TTL;
    private readonly CACHE_PREFIX;
    translateText(request: TranslationRequest): Promise<TranslationResult>;
    translateBatch(texts: string[], sourceLanguage: string, targetLanguage: string): Promise<string[]>;
    detectLanguage(text: string): Promise<string>;
    generateCacheKey(text: string, sourceLanguage: string, targetLanguage: string): string;
    private getFromCache;
    private saveToCache;
    private mapToAWSLanguageCode;
    private mapFromAWSLanguageCode;
    getCacheStats(): Promise<{
        hitRate: number;
        size: number;
    }>;
    clearCache(): Promise<number>;
    preloadCommonTranslations(language: string): Promise<void>;
}
export declare const translationService: TranslationService;
//# sourceMappingURL=translation.service.d.ts.map