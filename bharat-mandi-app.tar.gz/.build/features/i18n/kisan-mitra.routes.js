"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const kisan_mitra_service_1 = require("./kisan-mitra.service");
const uuid_1 = require("uuid");
const router = (0, express_1.Router)();
/**
 * POST /api/kisan-mitra/query
 * Send a query to Kisan Mitra assistant
 *
 * Body:
 * - userId: string (required)
 * - sessionId?: string (optional, will be generated if not provided)
 * - query: string (required for text input)
 * - language: string (required, e.g., 'hi', 'en', 'ta')
 * - audioInput?: base64 string (optional, for voice input)
 *
 * Response:
 * - text: string (response text)
 * - audioUrl?: string (URL to audio response)
 * - intent: string (recognized intent)
 * - confidence: number (0-1)
 * - slots?: object (extracted slot values)
 * - sessionId: string (session ID for follow-up questions)
 */
router.post('/query', async (req, res) => {
    try {
        const { userId, sessionId, query, language, audioInput } = req.body;
        // Validation
        if (!userId) {
            return res.status(400).json({
                success: false,
                error: 'userId is required',
            });
        }
        if (!query && !audioInput) {
            return res.status(400).json({
                success: false,
                error: 'Either query or audioInput is required',
            });
        }
        if (!language) {
            return res.status(400).json({
                success: false,
                error: 'language is required',
            });
        }
        // Generate session ID if not provided
        const effectiveSessionId = sessionId || `session-${userId}-${(0, uuid_1.v4)()}`;
        // Convert base64 audio to buffer if provided
        let audioBuffer;
        if (audioInput) {
            try {
                audioBuffer = Buffer.from(audioInput, 'base64');
            }
            catch (error) {
                return res.status(400).json({
                    success: false,
                    error: 'Invalid audioInput format. Must be base64 encoded.',
                });
            }
        }
        // Process query
        const response = await kisan_mitra_service_1.kisanMitraService.processQuery({
            userId,
            sessionId: effectiveSessionId,
            query: query || '',
            language,
            audioInput: audioBuffer,
        });
        res.json({
            success: true,
            ...response,
            sessionId: effectiveSessionId,
        });
    }
    catch (error) {
        console.error('[API] Kisan Mitra query failed:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to process query',
        });
    }
});
/**
 * GET /api/kisan-mitra/history/:userId
 * Get conversation history for a user
 *
 * Query params:
 * - limit?: number (default: 10, max: 50)
 *
 * Response:
 * - conversations: array of conversation records
 */
router.get('/history/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const limit = Math.min(parseInt(req.query.limit) || 10, 50);
        if (!userId) {
            return res.status(400).json({
                success: false,
                error: 'userId is required',
            });
        }
        const conversations = await kisan_mitra_service_1.kisanMitraService.getConversationHistory(userId, limit);
        res.json({
            success: true,
            conversations,
            count: conversations.length,
        });
    }
    catch (error) {
        console.error('[API] Failed to fetch conversation history:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch conversation history',
        });
    }
});
/**
 * DELETE /api/kisan-mitra/session/:sessionId
 * Clear a conversation session
 *
 * Response:
 * - success: boolean
 */
router.delete('/session/:sessionId', async (req, res) => {
    try {
        const { sessionId } = req.params;
        if (!sessionId) {
            return res.status(400).json({
                success: false,
                error: 'sessionId is required',
            });
        }
        await kisan_mitra_service_1.kisanMitraService.clearSession(sessionId);
        res.json({
            success: true,
            message: 'Session cleared successfully',
        });
    }
    catch (error) {
        console.error('[API] Failed to clear session:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to clear session',
        });
    }
});
/**
 * GET /api/kisan-mitra/stats
 * Get Kisan Mitra usage statistics
 *
 * Response:
 * - totalQueries: number
 * - uniqueUsers: number
 * - topIntents: array of {intent, count}
 * - averageConfidence: number
 */
router.get('/stats', async (req, res) => {
    try {
        const stats = await kisan_mitra_service_1.kisanMitraService.getStats();
        res.json({
            success: true,
            stats,
        });
    }
    catch (error) {
        console.error('[API] Failed to fetch stats:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch statistics',
        });
    }
});
/**
 * POST /api/kisan-mitra/generate-audio
 * Generate audio for a text response
 *
 * Body:
 * - text: string (required)
 * - language: string (required)
 *
 * Response:
 * - audioUrl: string (URL to audio file)
 */
router.post('/generate-audio', async (req, res) => {
    try {
        const { text, language } = req.body;
        if (!text) {
            return res.status(400).json({
                success: false,
                error: 'text is required',
            });
        }
        if (!language) {
            return res.status(400).json({
                success: false,
                error: 'language is required',
            });
        }
        // Import voice service
        const { voiceService } = await Promise.resolve().then(() => __importStar(require('./voice.service')));
        // Generate audio
        const synthesis = await voiceService.synthesizeSpeech({
            text,
            language: language,
        });
        if (!synthesis.success) {
            return res.status(500).json({
                success: false,
                error: synthesis.error || 'Failed to generate audio',
            });
        }
        res.json({
            success: true,
            audioUrl: synthesis.audioUrl,
        });
    }
    catch (error) {
        console.error('[API] Failed to generate audio:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to generate audio',
        });
    }
});
/**
 * GET /api/kisan-mitra/health
 * Health check endpoint
 */
router.get('/health', async (req, res) => {
    try {
        // Check if Lex bot is configured
        const botConfigured = !!(process.env.LEX_BOT_ID && process.env.LEX_BOT_ALIAS_ID);
        res.json({
            success: true,
            status: botConfigured ? 'healthy' : 'not_configured',
            botConfigured,
            message: botConfigured
                ? 'Kisan Mitra is ready'
                : 'Lex bot not configured. Set LEX_BOT_ID and LEX_BOT_ALIAS_ID environment variables.',
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            status: 'unhealthy',
            error: error.message,
        });
    }
});
exports.default = router;
//# sourceMappingURL=kisan-mitra.routes.js.map