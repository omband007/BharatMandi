declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=kisan-mitra.routes.d.ts.map