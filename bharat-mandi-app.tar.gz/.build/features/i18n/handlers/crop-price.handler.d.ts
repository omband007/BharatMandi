import type { DatabaseManager } from '../../../shared/database/db-abstraction';
export interface CropPriceResponse {
    crop: string;
    averagePrice: number;
    minPrice: number;
    maxPrice: number;
    trend: 'up' | 'down' | 'stable';
    unit: string;
    lastUpdated: Date;
    sampleSize: number;
}
export interface FormattedCropPriceResponse {
    text: string;
    data: CropPriceResponse;
}
/**
 * Handler for crop price queries
 * Queries marketplace database for active listings and calculates price statistics
 */
export declare class CropPriceHandler {
    private dbManager;
    constructor(dbManager: DatabaseManager);
    /**
     * Handle crop price query
     * @param crop - Crop name to query
     * @param location - Optional location filter
     * @returns Price statistics and trend
     */
    handle(crop: string, location?: string): Promise<CropPriceResponse>;
    /**
     * Get general market price information for common crops
     * This provides typical market prices without querying the database
     * @param crop - Normalized crop name
     * @param location - Optional location (affects prices)
     * @returns Price information or null if crop not found
     */
    private getGeneralMarketPrice;
    /**
     * Format crop price response in user's language
     * @param priceData - Price statistics
     * @param language - Target language code
     * @returns Formatted response with translated text
     */
    formatResponse(priceData: CropPriceResponse, language: string): Promise<FormattedCropPriceResponse>;
    /**
     * Normalize crop name for consistent querying
     * Converts to lowercase and trims whitespace
     */
    private normalizeCropName;
    /**
     * Get active listings for a specific crop
     * @param crop - Normalized crop name
     * @param location - Optional location filter (not implemented yet)
     * @returns Array of matching listings
     */
    private getActiveListings;
    /**
     * Calculate average of an array of numbers
     */
    private average;
    /**
     * Calculate price trend by comparing current price with historical data
     * @param crop - Normalized crop name
     * @param currentAvgPrice - Current average price
     * @returns Trend indicator
     */
    private calculateTrend;
    /**
     * Get similar crop names for suggestions
     * Uses simple string similarity (Levenshtein distance)
     * @param crop - Crop name that wasn't found
     * @returns Array of similar crop names
     */
    private getSimilarCrops;
    /**
     * Calculate string similarity using simple character overlap
     * @param str1 - First string
     * @param str2 - Second string
     * @returns Similarity score between 0 and 1
     */
    private calculateSimilarity;
}
//# sourceMappingURL=crop-price.handler.d.ts.map