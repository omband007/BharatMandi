export interface FarmingAdviceResponse {
    crop: string;
    topic: string;
    advice: string;
    tips: string[];
    references: string[];
}
export interface FormattedFarmingAdviceResponse {
    text: string;
    data: FarmingAdviceResponse;
}
/**
 * Handler for farming advice queries
 * Queries MongoDB knowledge base for farming tips and advice
 */
export declare class FarmingAdviceHandler {
    /**
     * Handle farming advice query
     * @param crop - Crop name to query
     * @param topic - Topic (planting, irrigation, pest-control, harvesting)
     * @param language - User's language for response
     * @returns Farming advice and tips
     */
    handle(crop: string, topic: string, language?: string): Promise<FarmingAdviceResponse>;
    /**
     * Format farming advice response in user's language
     * @param adviceData - Farming advice data
     * @param language - Target language code
     * @returns Formatted response with translated text
     */
    formatResponse(adviceData: FarmingAdviceResponse, language: string): Promise<FormattedFarmingAdviceResponse>;
    /**
     * Normalize crop name for consistent querying
     */
    private normalizeCropName;
    /**
     * Normalize topic name and map variations to standard topics
     */
    private normalizeTopic;
    /**
     * Query knowledge base with fuzzy matching for crop names
     * @param crop - Normalized crop name
     * @param topic - Normalized topic
     * @param language - User's language
     * @returns Array of matching farming tips
     */
    private queryKnowledgeBase;
    /**
     * Aggregate advice from multiple tips
     * Combines advice, tips, and references from all matching entries
     */
    private aggregateAdvice;
    /**
     * Get similar crop names for suggestions
     * @param crop - Crop name that wasn't found
     * @param language - User's language
     * @returns Array of similar crop names
     */
    private getSimilarCrops;
    /**
     * Calculate string similarity using simple character overlap
     * @param str1 - First string
     * @param str2 - Second string
     * @returns Similarity score between 0 and 1
     */
    private calculateSimilarity;
}
//# sourceMappingURL=farming-advice.handler.d.ts.map