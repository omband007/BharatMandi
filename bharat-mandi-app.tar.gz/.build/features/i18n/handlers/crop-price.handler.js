"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CropPriceHandler = void 0;
const translation_service_1 = require("../translation.service");
/**
 * Handler for crop price queries
 * Queries marketplace database for active listings and calculates price statistics
 */
class CropPriceHandler {
    constructor(dbManager) {
        this.dbManager = dbManager;
    }
    /**
     * Handle crop price query
     * @param crop - Crop name to query
     * @param location - Optional location filter
     * @returns Price statistics and trend
     */
    async handle(crop, location) {
        // 1. Normalize crop name
        const normalizedCrop = this.normalizeCropName(crop);
        // 2. Get general market prices (not from database)
        const priceData = this.getGeneralMarketPrice(normalizedCrop, location);
        if (!priceData) {
            throw new Error(`I don't have price information for "${normalizedCrop}" right now. I can help with common crops like tomato, potato, onion, wheat, rice, and more.`);
        }
        return priceData;
    }
    /**
     * Get general market price information for common crops
     * This provides typical market prices without querying the database
     * @param crop - Normalized crop name
     * @param location - Optional location (affects prices)
     * @returns Price information or null if crop not found
     */
    getGeneralMarketPrice(crop, location) {
        // General market prices for common crops (₹ per kg)
        // These are typical Indian market prices and can be updated
        const cropPrices = {
            'tomato': { min: 15, max: 35, avg: 25, trend: 'stable' },
            'potato': { min: 12, max: 25, avg: 18, trend: 'stable' },
            'onion': { min: 18, max: 30, avg: 22, trend: 'up' },
            'wheat': { min: 22, max: 28, avg: 25, trend: 'stable' },
            'rice': { min: 30, max: 45, avg: 35, trend: 'stable' },
            'cabbage': { min: 10, max: 20, avg: 15, trend: 'stable' },
            'cauliflower': { min: 15, max: 30, avg: 22, trend: 'down' },
            'carrot': { min: 20, max: 35, avg: 28, trend: 'stable' },
            'brinjal': { min: 18, max: 30, avg: 24, trend: 'stable' },
            'eggplant': { min: 18, max: 30, avg: 24, trend: 'stable' },
            'okra': { min: 25, max: 40, avg: 32, trend: 'up' },
            'ladyfinger': { min: 25, max: 40, avg: 32, trend: 'up' },
            'spinach': { min: 15, max: 25, avg: 20, trend: 'stable' },
            'coriander': { min: 20, max: 40, avg: 30, trend: 'stable' },
            'chilli': { min: 30, max: 60, avg: 45, trend: 'up' },
            'pepper': { min: 30, max: 60, avg: 45, trend: 'up' },
            'cucumber': { min: 12, max: 22, avg: 17, trend: 'stable' },
            'pumpkin': { min: 10, max: 18, avg: 14, trend: 'stable' },
            'bitter gourd': { min: 20, max: 35, avg: 28, trend: 'stable' },
            'bottle gourd': { min: 15, max: 25, avg: 20, trend: 'stable' },
            'beans': { min: 25, max: 40, avg: 32, trend: 'stable' },
            'peas': { min: 30, max: 50, avg: 40, trend: 'stable' },
            'corn': { min: 15, max: 25, avg: 20, trend: 'stable' },
            'maize': { min: 15, max: 25, avg: 20, trend: 'stable' },
            'sugarcane': { min: 2.5, max: 3.5, avg: 3, trend: 'stable' },
            'cotton': { min: 50, max: 70, avg: 60, trend: 'stable' },
            'soybean': { min: 40, max: 55, avg: 48, trend: 'stable' },
            'groundnut': { min: 50, max: 70, avg: 60, trend: 'stable' },
            'peanut': { min: 50, max: 70, avg: 60, trend: 'stable' },
        };
        // Try exact match first
        if (cropPrices[crop]) {
            const price = cropPrices[crop];
            return {
                crop: crop,
                averagePrice: price.avg,
                minPrice: price.min,
                maxPrice: price.max,
                trend: price.trend,
                unit: 'kg',
                lastUpdated: new Date(),
                sampleSize: 10, // Simulated sample size
            };
        }
        // Try partial match
        for (const [key, price] of Object.entries(cropPrices)) {
            if (key.includes(crop) || crop.includes(key)) {
                return {
                    crop: key,
                    averagePrice: price.avg,
                    minPrice: price.min,
                    maxPrice: price.max,
                    trend: price.trend,
                    unit: 'kg',
                    lastUpdated: new Date(),
                    sampleSize: 10,
                };
            }
        }
        return null;
    }
    /**
     * Format crop price response in user's language
     * @param priceData - Price statistics
     * @param language - Target language code
     * @returns Formatted response with translated text
     */
    async formatResponse(priceData, language) {
        // Create English response template with farm gate and retail prices
        const trendText = priceData.trend === 'up' ? 'increasing' :
            priceData.trend === 'down' ? 'decreasing' : 'stable';
        // Calculate estimated retail price (typically 30-50% markup from farm gate)
        const retailMarkup = 1.4; // 40% markup
        const estimatedRetailPrice = Math.round(priceData.averagePrice * retailMarkup * 100) / 100;
        const retailMinPrice = Math.round(priceData.minPrice * retailMarkup * 100) / 100;
        const retailMaxPrice = Math.round(priceData.maxPrice * retailMarkup * 100) / 100;
        const englishText = `📊 ${priceData.crop.toUpperCase()} PRICE INFORMATION\n\n` +
            `🌾 FARM GATE PRICE (What farmers are selling at):\n` +
            `Average: ₹${priceData.averagePrice} per ${priceData.unit}\n` +
            `Range: ₹${priceData.minPrice} - ₹${priceData.maxPrice} per ${priceData.unit}\n\n` +
            `🏪 ESTIMATED RETAIL PRICE (Market price for consumers):\n` +
            `Average: ₹${estimatedRetailPrice} per ${priceData.unit}\n` +
            `Range: ₹${retailMinPrice} - ₹${retailMaxPrice} per ${priceData.unit}\n\n` +
            `📈 Price Trend: ${trendText.toUpperCase()}\n` +
            `📍 General market prices across India`;
        // Translate to user's language if needed
        let responseText = englishText;
        if (language !== 'en') {
            try {
                const translation = await translation_service_1.translationService.translateText({
                    text: englishText,
                    sourceLanguage: 'en',
                    targetLanguage: language,
                });
                responseText = translation.translatedText;
            }
            catch (error) {
                console.error('[CropPriceHandler] Translation failed:', error);
                // Fall back to English if translation fails
            }
        }
        return {
            text: responseText,
            data: priceData,
        };
    }
    /**
     * Normalize crop name for consistent querying
     * Converts to lowercase and trims whitespace
     */
    normalizeCropName(crop) {
        return crop.toLowerCase().trim();
    }
    /**
     * Get active listings for a specific crop
     * @param crop - Normalized crop name
     * @param location - Optional location filter (not implemented yet)
     * @returns Array of matching listings
     */
    async getActiveListings(crop, location) {
        // Get all active listings
        const allListings = await this.dbManager.getActiveListings();
        // Filter by crop name (case-insensitive partial match)
        const filteredListings = allListings.filter(listing => listing.produceType.toLowerCase().includes(crop));
        // TODO: Add location filtering when location data is available
        // if (location) {
        //   filteredListings = filteredListings.filter(listing => 
        //     listing.location?.toLowerCase().includes(location.toLowerCase())
        //   );
        // }
        return filteredListings;
    }
    /**
     * Calculate average of an array of numbers
     */
    average(numbers) {
        if (numbers.length === 0)
            return 0;
        const sum = numbers.reduce((acc, val) => acc + val, 0);
        return sum / numbers.length;
    }
    /**
     * Calculate price trend by comparing current price with historical data
     * @param crop - Normalized crop name
     * @param currentAvgPrice - Current average price
     * @returns Trend indicator
     */
    async calculateTrend(crop, currentAvgPrice) {
        // Get historical data (last 7 days)
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        // Get all active listings (in a real implementation, we'd query by date range)
        const allListings = await this.dbManager.getActiveListings();
        // Filter by crop and date
        const historicalListings = allListings.filter(listing => listing.produceType.toLowerCase().includes(crop) &&
            listing.createdAt < sevenDaysAgo);
        // If no historical data, trend is stable
        if (historicalListings.length === 0) {
            return 'stable';
        }
        // Calculate historical average
        const historicalPrices = historicalListings.map(l => l.pricePerKg);
        const historicalAvgPrice = this.average(historicalPrices);
        // Compare current vs historical (5% threshold for stability)
        const percentChange = ((currentAvgPrice - historicalAvgPrice) / historicalAvgPrice) * 100;
        if (percentChange > 5) {
            return 'up';
        }
        else if (percentChange < -5) {
            return 'down';
        }
        else {
            return 'stable';
        }
    }
    /**
     * Get similar crop names for suggestions
     * Uses simple string similarity (Levenshtein distance)
     * @param crop - Crop name that wasn't found
     * @returns Array of similar crop names
     */
    async getSimilarCrops(crop) {
        // Get all active listings
        const allListings = await this.dbManager.getActiveListings();
        // Extract unique crop names
        const uniqueCrops = [...new Set(allListings.map(l => l.produceType.toLowerCase()))];
        // Calculate similarity scores
        const similarities = uniqueCrops.map(existingCrop => ({
            crop: existingCrop,
            score: this.calculateSimilarity(crop, existingCrop),
        }));
        // Sort by similarity and return top 3
        return similarities
            .filter(s => s.score > 0.5) // Only return if similarity > 50%
            .sort((a, b) => b.score - a.score)
            .slice(0, 3)
            .map(s => s.crop);
    }
    /**
     * Calculate string similarity using simple character overlap
     * @param str1 - First string
     * @param str2 - Second string
     * @returns Similarity score between 0 and 1
     */
    calculateSimilarity(str1, str2) {
        const longer = str1.length > str2.length ? str1 : str2;
        const shorter = str1.length > str2.length ? str2 : str1;
        if (longer.length === 0)
            return 1.0;
        // Check if shorter is contained in longer (but only if lengths are close)
        const lengthRatio = shorter.length / longer.length;
        if (longer.includes(shorter) && lengthRatio > 0.7) {
            return 0.85;
        }
        // Count matching characters
        let matches = 0;
        for (let i = 0; i < shorter.length; i++) {
            if (longer.includes(shorter[i])) {
                matches++;
            }
        }
        return matches / longer.length;
    }
}
exports.CropPriceHandler = CropPriceHandler;
//# sourceMappingURL=crop-price.handler.js.map