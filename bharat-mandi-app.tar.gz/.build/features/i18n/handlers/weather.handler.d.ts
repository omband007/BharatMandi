export interface WeatherResponse {
    location: string;
    current: {
        temperature: number;
        humidity: number;
        rainfall: number;
        condition: string;
    };
    forecast: Array<{
        date: Date;
        temperature: {
            min: number;
            max: number;
        };
        rainfall: number;
        condition: string;
    }>;
    farmingAdvice: string;
}
export interface FormattedWeatherResponse {
    text: string;
    data: WeatherResponse;
}
/**
 * Handler for weather queries
 * Integrates with OpenWeatherMap API to provide weather data and farming advice
 */
export declare class WeatherHandler {
    private apiKey;
    private baseUrl;
    private geocodingCache;
    constructor(apiKey?: string);
    /**
     * Handle weather query
     * @param location - Location name to query
     * @returns Weather data with farming advice
     */
    handle(location: string): Promise<WeatherResponse>;
    /**
     * Format weather response in user's language
     * @param weatherData - Weather data
     * @param language - Target language code
     * @returns Formatted response with translated text
     */
    formatResponse(weatherData: WeatherResponse, language: string): Promise<FormattedWeatherResponse>;
    /**
     * Convert location name to coordinates using OpenWeatherMap Geocoding API
     * Results are cached to reduce API calls
     * @param location - Location name
     * @returns Coordinates and location details
     */
    private geocode;
    /**
     * Fetch current weather from OpenWeatherMap API
     * @param lat - Latitude
     * @param lon - Longitude
     * @returns Current weather data
     */
    private getCurrentWeather;
    /**
     * Fetch 3-day forecast from OpenWeatherMap API
     * @param lat - Latitude
     * @param lon - Longitude
     * @returns Array of forecast data for next 3 days
     */
    private getForecast;
    /**
     * Get most common weather condition from array
     * @param conditions - Array of weather conditions
     * @returns Most frequent condition
     */
    private getMostCommonCondition;
    /**
     * Generate farming advice based on weather conditions
     * Uses rule-based logic to provide actionable recommendations
     * @param current - Current weather data
     * @param forecast - 3-day forecast
     * @returns Farming advice string
     */
    private generateFarmingAdvice;
}
//# sourceMappingURL=weather.handler.d.ts.map