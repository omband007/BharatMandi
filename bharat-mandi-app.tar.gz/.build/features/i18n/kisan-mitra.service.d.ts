export interface KisanMitraRequest {
    userId: string;
    sessionId: string;
    query: string;
    language: string;
    audioInput?: Buffer;
}
export interface KisanMitraResponse {
    text: string;
    audioUrl?: string;
    intent: string;
    confidence: number;
    slots?: Record<string, string>;
    sessionAttributes?: Record<string, string>;
}
export interface VoiceQuery {
    userId: string;
    sessionId: string;
    query: string;
    response: string;
    intent: string;
    confidence: number;
    language: string;
    timestamp: Date;
}
export declare class KisanMitraService {
    private mongoClient;
    private db;
    private dbManager;
    private handlerRegistry;
    constructor();
    /**
     * Register all intent handlers
     * Maps Lex intent names to their corresponding handler instances
     */
    private registerHandlers;
    private getDb;
    /**
     * Process a user query through Kisan Mitra
     * Handles voice input, translation, Lex interaction, and response generation
     */
    processQuery(request: KisanMitraRequest): Promise<KisanMitraResponse>;
    /**
     * Extract slot values from Lex response
     */
    private extractSlotValues;
    /**
     * Log conversation to MongoDB for analytics and improvement
     */
    private logConversation;
    /**
     * Get conversation history for a user
     */
    getConversationHistory(userId: string, limit?: number): Promise<VoiceQuery[]>;
    /**
     * Clear conversation session
     * Note: AWS Lex sessions expire automatically after 5 minutes of inactivity
     */
    clearSession(sessionId: string): Promise<void>;
    /**
     * Get conversation statistics
     */
    getStats(): Promise<{
        totalQueries: number;
        uniqueUsers: number;
        topIntents: Array<{
            intent: string;
            count: number;
        }>;
        averageConfidence: number;
    }>;
    /**
     * Call the appropriate handler based on intent and slots
     * @param intent - Intent name
     * @param handler - Handler instance
     * @param slots - Lex slots
     * @param language - User's language
     * @returns Formatted response text
     */
    private callHandler;
    /**
     * Get user-friendly error message for handler errors
     * @param error - Error object
     * @param language - User's language
     * @returns Error message in user's language
     */
    private getHandlerErrorMessage;
    /**
     * Close MongoDB connection
     */
    close(): Promise<void>;
}
export declare const kisanMitraService: KisanMitraService;
//# sourceMappingURL=kisan-mitra.service.d.ts.map