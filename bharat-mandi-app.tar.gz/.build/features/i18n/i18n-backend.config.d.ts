import i18next from 'i18next';
export declare const i18nextMiddleware: import("express-serve-static-core").Handler;
export { i18next as i18nextBackend };
//# sourceMappingURL=i18n-backend.config.d.ts.map