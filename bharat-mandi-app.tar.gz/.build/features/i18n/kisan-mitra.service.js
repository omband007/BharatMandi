"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.kisanMitraService = exports.KisanMitraService = void 0;
const client_lex_runtime_v2_1 = require("@aws-sdk/client-lex-runtime-v2");
const translation_service_1 = require("./translation.service");
const voice_service_1 = require("./voice.service");
const mongodb_1 = require("mongodb");
const db_abstraction_1 = require("../../shared/database/db-abstraction");
const crop_price_handler_1 = require("./handlers/crop-price.handler");
const weather_handler_1 = require("./handlers/weather.handler");
const farming_advice_handler_1 = require("./handlers/farming-advice.handler");
const lexClient = new client_lex_runtime_v2_1.LexRuntimeV2Client({
    region: process.env.AWS_REGION || process.env.LEX_REGION || 'ap-south-1',
});
const BOT_ID = process.env.LEX_BOT_ID || '';
const BOT_ALIAS_ID = process.env.LEX_BOT_ALIAS_ID || '';
// AWS Lex V2 locale configuration
// Currently only en_IN is configured in the bot
// All non-English queries are translated to English before sending to Lex
// Responses are translated back to the user's language
const LOCALE_ID_MAP = {
    en: 'en_IN',
    hi: 'en_IN', // Hindi queries are translated to English first
    pa: 'en_IN', // Punjabi queries are translated to English first
    mr: 'en_IN', // Marathi queries are translated to English first
    ta: 'en_IN', // Tamil queries are translated to English first
    te: 'en_IN', // Telugu queries are translated to English first
    bn: 'en_IN', // Bengali queries are translated to English first
    gu: 'en_IN', // Gujarati queries are translated to English first
    kn: 'en_IN', // Kannada queries are translated to English first
    ml: 'en_IN', // Malayalam queries are translated to English first
    or: 'en_IN', // Odia queries are translated to English first
};
class KisanMitraService {
    constructor() {
        this.db = null;
        const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017';
        this.mongoClient = new mongodb_1.MongoClient(mongoUri);
        // Initialize database manager for handlers
        this.dbManager = new db_abstraction_1.DatabaseManager();
        // Initialize handler registry
        this.handlerRegistry = new Map();
        this.registerHandlers();
    }
    /**
     * Register all intent handlers
     * Maps Lex intent names to their corresponding handler instances
     */
    registerHandlers() {
        // Register CropPriceHandler for GetCropPrice intent
        this.handlerRegistry.set('GetCropPrice', new crop_price_handler_1.CropPriceHandler(this.dbManager));
        // Register WeatherHandler for GetWeather intent
        this.handlerRegistry.set('GetWeather', new weather_handler_1.WeatherHandler());
        // Register FarmingAdviceHandler for GetFarmingAdvice intent
        this.handlerRegistry.set('GetFarmingAdvice', new farming_advice_handler_1.FarmingAdviceHandler());
        console.log('[KisanMitra] Registered handlers:', Array.from(this.handlerRegistry.keys()));
    }
    async getDb() {
        if (!this.db) {
            await this.mongoClient.connect();
            this.db = this.mongoClient.db('bharat_mandi');
        }
        return this.db;
    }
    /**
     * Process a user query through Kisan Mitra
     * Handles voice input, translation, Lex interaction, and response generation
     */
    async processQuery(request) {
        let queryText = request.query;
        let sourceLanguage = request.language;
        // Step 1: If audio input provided, transcribe first
        if (request.audioInput) {
            try {
                const transcription = await voice_service_1.voiceService.transcribeAudio({
                    audioBuffer: request.audioInput,
                    audioFormat: 'mp3',
                    language: request.language,
                });
                queryText = transcription.text;
                sourceLanguage = transcription.detectedLanguage || request.language;
            }
            catch (error) {
                console.error('[KisanMitra] Transcription failed:', error);
                throw new Error('Failed to transcribe audio input');
            }
        }
        // Step 2: Translate to English if needed (Lex only supports en_IN locale)
        let lexQuery = queryText;
        let needsTranslation = sourceLanguage !== 'en';
        if (needsTranslation) {
            try {
                console.log(`[KisanMitra] Translating from ${sourceLanguage} to English:`, queryText);
                const translation = await translation_service_1.translationService.translateText({
                    text: queryText,
                    sourceLanguage,
                    targetLanguage: 'en',
                });
                lexQuery = translation.translatedText;
                console.log('[KisanMitra] Translated query:', lexQuery);
            }
            catch (error) {
                console.error('[KisanMitra] Translation to English failed:', error);
                // Continue with original text
                lexQuery = queryText;
            }
        }
        // Step 3: Send to AWS Lex
        const localeId = LOCALE_ID_MAP[sourceLanguage] || LOCALE_ID_MAP['en'];
        const command = {
            botId: BOT_ID,
            botAliasId: BOT_ALIAS_ID,
            localeId,
            sessionId: request.sessionId,
            text: lexQuery,
        };
        let lexResponse;
        try {
            lexResponse = await lexClient.send(new client_lex_runtime_v2_1.RecognizeTextCommand(command));
        }
        catch (error) {
            console.error('[KisanMitra] Lex query failed:', error);
            // Handle specific Lex errors
            if (error.name === 'DependencyFailedException') {
                throw new Error('Kisan Mitra is temporarily unavailable. Please try again later.');
            }
            throw new Error('Failed to process query');
        }
        // Step 4: Extract intent and slots
        const intent = lexResponse.sessionState?.intent?.name || 'Unknown';
        const slots = lexResponse.sessionState?.intent?.slots || {};
        const intentState = lexResponse.sessionState?.intent?.state;
        // Calculate confidence based on intent state
        const confidence = intentState === 'Fulfilled' ? 0.95 :
            intentState === 'InProgress' ? 0.75 : 0.5;
        // Step 5: Get response text from Lex
        let responseText = lexResponse.messages?.[0]?.content ||
            'I did not understand that. Can you please rephrase?';
        // Step 6: Check if intent has a handler and call it
        const handler = this.handlerRegistry.get(intent);
        if (handler && intentState === 'Fulfilled') {
            try {
                console.log(`[KisanMitra] Calling handler for intent: ${intent}`);
                const handlerResponse = await this.callHandler(intent, handler, slots, sourceLanguage);
                if (handlerResponse) {
                    // Use handler response instead of Lex response
                    responseText = handlerResponse;
                    console.log('[KisanMitra] Handler response:', responseText);
                }
            }
            catch (error) {
                console.error(`[KisanMitra] Handler error for ${intent}:`, error);
                // Fall back to Lex response on handler error
                // Error handling will provide user-friendly message
                responseText = this.getHandlerErrorMessage(error, sourceLanguage);
            }
        }
        // Step 7: Translate response back to user's language (if not already translated by handler)
        if (needsTranslation && !handler) {
            try {
                console.log(`[KisanMitra] Translating response from English to ${sourceLanguage}:`, responseText);
                const translation = await translation_service_1.translationService.translateText({
                    text: responseText,
                    sourceLanguage: 'en',
                    targetLanguage: sourceLanguage,
                });
                responseText = translation.translatedText;
                console.log('[KisanMitra] Translated response:', responseText);
            }
            catch (error) {
                console.error('[KisanMitra] Translation to target language failed:', error);
                // Continue with English response
            }
        }
        // Step 7: Generate audio response asynchronously (don't block response)
        let audioUrl;
        // Start audio generation in background
        const audioPromise = voice_service_1.voiceService.synthesizeSpeech({
            text: responseText,
            language: sourceLanguage,
        }).then(synthesis => {
            if (synthesis.success) {
                console.log('[KisanMitra] Audio synthesis completed');
                return synthesis.audioUrl;
            }
            return undefined;
        }).catch(error => {
            console.error('[KisanMitra] Speech synthesis failed:', error);
            return undefined;
        });
        // Don't wait for audio - return response immediately
        // Audio will be available shortly after
        console.log('[KisanMitra] Returning response immediately, audio generating in background');
        // Step 8: Log conversation (also async, don't block)
        this.logConversation(request.userId, request.sessionId, queryText, responseText, intent, confidence, sourceLanguage).catch(error => {
            console.error('[KisanMitra] Failed to log conversation:', error);
        });
        // Return response immediately with pending audio
        const response = {
            text: responseText,
            audioUrl: undefined, // Will be generated shortly
            intent,
            confidence,
            slots: this.extractSlotValues(slots),
            sessionAttributes: lexResponse.sessionState?.sessionAttributes,
        };
        // Wait a bit for audio if it completes quickly (max 2 seconds)
        const audioWithTimeout = Promise.race([
            audioPromise,
            new Promise(resolve => setTimeout(() => resolve(undefined), 2000))
        ]);
        audioUrl = await audioWithTimeout;
        if (audioUrl) {
            response.audioUrl = audioUrl;
            console.log('[KisanMitra] Audio ready within timeout');
        }
        else {
            console.log('[KisanMitra] Audio still generating, will be cached for next time');
        }
        return response;
    }
    /**
     * Extract slot values from Lex response
     */
    extractSlotValues(slots) {
        const values = {};
        for (const [key, slot] of Object.entries(slots)) {
            if (slot && typeof slot === 'object' && 'value' in slot) {
                const slotValue = slot.value;
                if (slotValue && 'interpretedValue' in slotValue) {
                    values[key] = slotValue.interpretedValue;
                }
            }
        }
        return values;
    }
    /**
     * Log conversation to MongoDB for analytics and improvement
     */
    async logConversation(userId, sessionId, query, response, intent, confidence, language) {
        try {
            const db = await this.getDb();
            const collection = db.collection('voice_queries');
            await collection.insertOne({
                userId,
                sessionId,
                query,
                response,
                intent,
                confidence,
                language,
                timestamp: new Date(),
            });
        }
        catch (error) {
            console.error('[KisanMitra] Failed to log conversation:', error);
            throw error;
        }
    }
    /**
     * Get conversation history for a user
     */
    async getConversationHistory(userId, limit = 10) {
        try {
            const db = await this.getDb();
            const collection = db.collection('voice_queries');
            return await collection
                .find({ userId })
                .sort({ timestamp: -1 })
                .limit(limit)
                .toArray();
        }
        catch (error) {
            console.error('[KisanMitra] Failed to fetch history:', error);
            return [];
        }
    }
    /**
     * Clear conversation session
     * Note: AWS Lex sessions expire automatically after 5 minutes of inactivity
     */
    async clearSession(sessionId) {
        try {
            const db = await this.getDb();
            const collection = db.collection('voice_queries');
            // Mark session as cleared (for analytics)
            await collection.updateMany({ sessionId }, { $set: { sessionCleared: true, clearedAt: new Date() } });
        }
        catch (error) {
            console.error('[KisanMitra] Failed to clear session:', error);
        }
    }
    /**
     * Get conversation statistics
     */
    async getStats() {
        try {
            const db = await this.getDb();
            const collection = db.collection('voice_queries');
            const [totalQueries, uniqueUsers, topIntents, avgConfidence] = await Promise.all([
                collection.countDocuments(),
                collection.distinct('userId').then((users) => users.length),
                collection
                    .aggregate([
                    { $group: { _id: '$intent', count: { $sum: 1 } } },
                    { $sort: { count: -1 } },
                    { $limit: 5 },
                    { $project: { intent: '$_id', count: 1, _id: 0 } },
                ])
                    .toArray(),
                collection
                    .aggregate([{ $group: { _id: null, avg: { $avg: '$confidence' } } }])
                    .toArray()
                    .then((result) => result[0]?.avg || 0),
            ]);
            return {
                totalQueries,
                uniqueUsers,
                topIntents: topIntents,
                averageConfidence: avgConfidence,
            };
        }
        catch (error) {
            console.error('[KisanMitra] Failed to get stats:', error);
            return {
                totalQueries: 0,
                uniqueUsers: 0,
                topIntents: [],
                averageConfidence: 0,
            };
        }
    }
    /**
     * Call the appropriate handler based on intent and slots
     * @param intent - Intent name
     * @param handler - Handler instance
     * @param slots - Lex slots
     * @param language - User's language
     * @returns Formatted response text
     */
    async callHandler(intent, handler, slots, language) {
        const slotValues = this.extractSlotValues(slots);
        switch (intent) {
            case 'GetCropPrice': {
                const crop = slotValues.crop;
                const location = slotValues.location;
                if (!crop) {
                    throw new Error('Crop name is required for price query');
                }
                const priceData = await handler.handle(crop, location);
                const formatted = await handler.formatResponse(priceData, language);
                return formatted.text;
            }
            case 'GetWeather': {
                const location = slotValues.location;
                if (!location) {
                    throw new Error('Location is required for weather query');
                }
                const weatherData = await handler.handle(location);
                const formatted = await handler.formatResponse(weatherData, language);
                return formatted.text;
            }
            case 'GetFarmingAdvice': {
                const crop = slotValues.crop;
                const topic = slotValues.topic || 'general';
                if (!crop) {
                    throw new Error('Crop name is required for farming advice');
                }
                const adviceData = await handler.handle(crop, topic, language);
                const formatted = await handler.formatResponse(adviceData, language);
                return formatted.text;
            }
            default:
                console.warn(`[KisanMitra] No handler implementation for intent: ${intent}`);
                return null;
        }
    }
    /**
     * Get user-friendly error message for handler errors
     * @param error - Error object
     * @param language - User's language
     * @returns Error message in user's language
     */
    getHandlerErrorMessage(error, language) {
        const errorMessage = error instanceof Error ? error.message : 'An error occurred';
        console.error('[KisanMitra] Handler error details:', {
            message: errorMessage,
            stack: error instanceof Error ? error.stack : undefined,
            language,
        });
        // Check for specific error types and provide helpful messages
        if (errorMessage.includes('not found') || errorMessage.includes('No listings found')) {
            return errorMessage; // Already user-friendly
        }
        if (errorMessage.includes('API key not configured') || errorMessage.includes('unavailable')) {
            return 'Sorry, this service is temporarily unavailable. Please try again later.';
        }
        if (errorMessage.includes('Location not found')) {
            return errorMessage; // Already user-friendly
        }
        if (errorMessage.includes('required')) {
            return errorMessage; // Already user-friendly
        }
        // Generic error message for unexpected errors
        return 'I encountered an issue processing your request. Please try rephrasing your question.';
    }
    /**
     * Close MongoDB connection
     */
    async close() {
        await this.mongoClient.close();
        this.db = null;
    }
}
exports.KisanMitraService = KisanMitraService;
exports.kisanMitraService = new KisanMitraService();
//# sourceMappingURL=kisan-mitra.service.js.map