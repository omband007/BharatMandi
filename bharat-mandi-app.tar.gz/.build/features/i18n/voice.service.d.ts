/**
 * Voice Service
 *
 * Handles speech-to-text (AWS Transcribe) and text-to-speech (AWS Polly) operations
 * for multi-language voice interface support.
 *
 * Features:
 * - Audio transcription with language detection
 * - Speech synthesis with voice selection
 * - Audio caching for offline playback
 * - S3 integration for temporary audio storage
 *
 * Requirements: 6.1, 6.6, 6.13, 7.1, 7.4, 7.5, 7.12, 7.13
 */
/**
 * Supported language codes for voice operations
 */
export type VoiceLanguageCode = 'en' | 'hi' | 'pa' | 'mr' | 'ta' | 'te' | 'bn' | 'gu' | 'kn' | 'ml' | 'or';
/**
 * Voice transcription request
 */
export interface TranscriptionRequest {
    audioBuffer: Buffer;
    audioFormat: 'mp3' | 'wav' | 'flac' | 'ogg';
    language?: VoiceLanguageCode;
    sampleRate?: number;
}
/**
 * Voice transcription response
 */
export interface TranscriptionResponse {
    text: string;
    detectedLanguage?: VoiceLanguageCode;
    confidence?: number;
    success: boolean;
    error?: string;
}
/**
 * Text-to-speech request
 */
export interface SynthesisRequest {
    text: string;
    language: VoiceLanguageCode;
    speed?: number;
    ssml?: boolean;
}
/**
 * Text-to-speech response
 */
export interface SynthesisResponse {
    audioUrl: string;
    audioBuffer?: Buffer;
    duration?: number;
    success: boolean;
    error?: string;
}
/**
 * Voice Service
 *
 * Provides speech-to-text and text-to-speech capabilities using AWS services.
 */
export declare class VoiceService {
    private config;
    constructor();
    /**
     * Transcribe audio to text using AWS Transcribe
     *
     * Requirements: 6.1, 6.6, 6.13
     *
     * @param request - Transcription request with audio buffer and metadata
     * @returns Transcription response with text and detected language
     */
    transcribeAudio(request: TranscriptionRequest): Promise<TranscriptionResponse>;
    /**
     * Upload audio buffer to S3
     *
     * @param audioBuffer - Audio data
     * @param s3Key - S3 object key
     * @param format - Audio format
     */
    private uploadAudioToS3;
    /**
     * Delete audio file from S3
     *
     * Requirements: 19.3
     *
     * @param s3Key - S3 object key
     */
    private deleteAudioFromS3;
    /**
     * Poll transcription job until completion
     *
     * @param jobName - Transcription job name
     * @returns Transcription job result
     */
    private pollTranscriptionJob;
    /**
     * Fetch transcript text from S3 URL
     *
     * @param transcriptUri - S3 URI of transcript JSON
     * @returns Transcript text
     */
    private fetchTranscript;
    /**
     * Map AWS Transcribe language code to our language code
     *
     * @param transcribeCode - AWS Transcribe language code
     * @returns Our language code
     */
    private mapTranscribeLanguageCode;
    /**
     * Get content type for audio format
     *
     * @param format - Audio format
     * @returns MIME type
     */
    private getContentType;
    /**
     * Synthesize speech from text using AWS Polly
     *
     * Requirements: 7.1, 7.4, 7.5, 7.12, 7.13, 7.14
     *
     * @param request - Synthesis request with text and language
     * @returns Synthesis response with audio URL
     */
    synthesizeSpeech(request: SynthesisRequest): Promise<SynthesisResponse>;
    /**
     * Generate cache key for TTS
     *
     * Requirements: 7.12, 7.13
     *
     * @param text - Text to synthesize
     * @param language - Language code
     * @param speed - Speech speed
     * @returns Cache key
     */
    private generateTTSCacheKey;
    /**
     * Get Polly language code from our language code
     *
     * @param languageCode - Our language code
     * @returns Polly language code
     */
    private getPollyLanguageCode;
    /**
     * Convert readable stream to buffer
     *
     * @param stream - Readable stream
     * @returns Buffer
     */
    private streamToBuffer;
    /**
     * Clear TTS cache
     *
     * @param cacheKey - Optional specific cache key to clear
     */
    clearTTSCache(cacheKey?: string): void;
    /**
     * Get TTS cache statistics
     *
     * @returns Cache statistics
     */
    getTTSCacheStats(): {
        size: number;
        keys: string[];
    };
    /**
     * Get audio cache statistics (local SQLite cache)
     *
     * Requirements: 13.8
     *
     * @returns Audio cache statistics
     */
    getAudioCacheStats(): import("./audio-cache.service").AudioCacheStats;
    /**
     * Clear audio cache (local SQLite cache)
     *
     * @param cacheKey - Optional specific cache key to clear
     */
    clearAudioCache(cacheKey?: string): void;
    /**
     * Get cached audio by language
     *
     * @param language - Language code
     * @returns Array of cached audio entries
     */
    getCachedAudioByLanguage(language: string): import("./audio-cache.service").CachedAudio[];
    /**
     * Preload common phrases for offline playback
     *
     * Requirements: 12.6
     *
     * @param language - Language code
     * @param phrases - Array of common phrases to preload
     */
    preloadCommonPhrases(language: VoiceLanguageCode, phrases: string[]): Promise<void>;
    /**
     * Preload user's recent voice outputs
     *
     * Requirements: 12.6
     *
     * @param language - Language code
     * @param limit - Number of recent entries to preload (default 10)
     */
    preloadRecentVoiceOutputs(language: VoiceLanguageCode, limit?: number): Promise<void>;
    /**
     * Get common phrases for preloading
     *
     * @returns Array of common phrases
     */
    static getCommonPhrases(): string[];
}
export declare const voiceService: VoiceService;
//# sourceMappingURL=voice.service.d.ts.map