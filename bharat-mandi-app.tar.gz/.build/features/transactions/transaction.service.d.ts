import type { Transaction, EscrowAccount } from './transaction.types';
export declare class TransactionService {
    initiatePurchase(listingId: string, farmerId: string, buyerId: string, amount: number): Promise<Transaction>;
    acceptOrder(transactionId: string): Promise<Transaction | undefined>;
    rejectOrder(transactionId: string): Promise<Transaction | undefined>;
    createEscrow(transactionId: string, amount: number): Promise<EscrowAccount>;
    lockPayment(transactionId: string): Promise<{
        transaction?: Transaction;
        escrow?: EscrowAccount;
    }>;
    markDispatched(transactionId: string): Promise<Transaction | undefined>;
    markDelivered(transactionId: string): Promise<Transaction | undefined>;
    releaseFunds(transactionId: string): Promise<{
        transaction?: Transaction;
        escrow?: EscrowAccount;
    }>;
    completeDirectPayment(transactionId: string): Promise<Transaction>;
    getTransaction(id: string): Promise<Transaction | undefined>;
}
export declare const transactionService: TransactionService;
//# sourceMappingURL=transaction.service.d.ts.map