"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transactionService = exports.transactionController = void 0;
// Public API - only export what other features need
var transaction_controller_1 = require("./transaction.controller");
Object.defineProperty(exports, "transactionController", { enumerable: true, get: function () { return transaction_controller_1.transactionController; } });
var transaction_service_1 = require("./transaction.service");
Object.defineProperty(exports, "transactionService", { enumerable: true, get: function () { return transaction_service_1.transactionService; } });
//# sourceMappingURL=index.js.map