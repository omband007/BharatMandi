export declare const transactionController: import("express-serve-static-core").Router;
//# sourceMappingURL=transaction.controller.d.ts.map