"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transactionService = exports.TransactionService = void 0;
// Transaction and escrow service
const uuid_1 = require("uuid");
const common_types_1 = require("../../shared/types/common.types");
// Get the shared DatabaseManager instance from app.ts
function getDbManager() {
    const dbManager = global.sharedDbManager;
    if (!dbManager) {
        throw new Error('DatabaseManager not initialized. This should be set by app.ts');
    }
    return dbManager;
}
class TransactionService {
    // Initiate purchase request
    async initiatePurchase(listingId, farmerId, buyerId, amount) {
        const transaction = {
            id: (0, uuid_1.v4)(),
            listingId,
            farmerId,
            buyerId,
            amount,
            status: common_types_1.TransactionStatus.PENDING,
            createdAt: new Date(),
            updatedAt: new Date()
        };
        return await getDbManager().createTransaction(transaction);
    }
    // Farmer accepts order
    async acceptOrder(transactionId) {
        return await getDbManager().updateTransaction(transactionId, {
            status: common_types_1.TransactionStatus.ACCEPTED
        });
    }
    // Farmer rejects order
    async rejectOrder(transactionId) {
        return await getDbManager().updateTransaction(transactionId, {
            status: common_types_1.TransactionStatus.REJECTED
        });
    }
    // Create escrow account
    async createEscrow(transactionId, amount) {
        const escrow = {
            id: (0, uuid_1.v4)(),
            transactionId,
            amount,
            status: common_types_1.EscrowStatus.CREATED,
            isLocked: false,
            createdAt: new Date()
        };
        return await getDbManager().createEscrow(escrow);
    }
    // Lock payment in escrow
    async lockPayment(transactionId) {
        const escrow = await getDbManager().getEscrowByTransaction(transactionId);
        if (!escrow)
            return {};
        const updatedEscrow = await getDbManager().updateEscrow(escrow.id, { isLocked: true });
        const updatedTransaction = await getDbManager().updateTransaction(transactionId, {
            status: common_types_1.TransactionStatus.PAYMENT_LOCKED
        });
        return { transaction: updatedTransaction, escrow: updatedEscrow };
    }
    // Mark as dispatched
    async markDispatched(transactionId) {
        return await getDbManager().updateTransaction(transactionId, {
            status: common_types_1.TransactionStatus.IN_TRANSIT
        });
    }
    // Mark as delivered
    async markDelivered(transactionId) {
        return await getDbManager().updateTransaction(transactionId, {
            status: common_types_1.TransactionStatus.DELIVERED
        });
    }
    // Release funds (after validation)
    async releaseFunds(transactionId) {
        const escrow = await getDbManager().getEscrowByTransaction(transactionId);
        if (!escrow || !escrow.isLocked)
            return {};
        const updatedEscrow = await getDbManager().updateEscrow(escrow.id, { isLocked: false });
        const updatedTransaction = await getDbManager().updateTransaction(transactionId, {
            status: common_types_1.TransactionStatus.COMPLETED
        });
        return { transaction: updatedTransaction, escrow: updatedEscrow };
    }
    // Complete direct payment (skip escrow flow)
    // Requirements: 20.1, 20.2, 20.3, 20.6, 20.7
    async completeDirectPayment(transactionId) {
        const dbManager = getDbManager();
        // Get transaction
        const transaction = await this.getTransaction(transactionId);
        if (!transaction) {
            throw new Error(`Transaction with ID "${transactionId}" not found`);
        }
        // Validate transaction is in ACCEPTED state
        if (transaction.status !== common_types_1.TransactionStatus.ACCEPTED) {
            throw new Error(`Cannot complete direct payment. Transaction status is ${transaction.status}, must be ACCEPTED`);
        }
        // Get listing to validate payment_method_preference
        const listing = await dbManager.get('SELECT * FROM listings WHERE id = ?', [transaction.listingId]);
        if (!listing) {
            throw new Error(`Listing with ID "${transaction.listingId}" not found`);
        }
        // Validate listing payment_method_preference allows direct payment
        if (listing.payment_method_preference === 'PLATFORM_ONLY') {
            throw new Error('Cannot complete direct payment. Listing only accepts platform payments (escrow)');
        }
        // Transition transaction to COMPLETED_DIRECT
        const updatedTransaction = await dbManager.updateTransaction(transactionId, {
            status: common_types_1.TransactionStatus.COMPLETED_DIRECT,
            completedAt: new Date()
        });
        if (!updatedTransaction) {
            throw new Error('Failed to update transaction status');
        }
        console.log(`[TransactionService] Transaction ${transactionId} completed via direct payment`);
        return updatedTransaction;
    }
    async getTransaction(id) {
        return await getDbManager().getTransaction(id);
    }
}
exports.TransactionService = TransactionService;
exports.transactionService = new TransactionService();
//# sourceMappingURL=transaction.service.js.map