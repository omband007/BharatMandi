import type { Notification, NotificationTemplate, NotificationType, NotificationVariables } from './notification.types';
export declare class NotificationService {
    /**
     * Interpolate variables into a template string
     * Replaces {{variableName}} with actual values
     */
    private interpolateTemplate;
    /**
     * Get notification template for a specific type and language
     * Falls back to English if language not found
     */
    getTemplate(type: NotificationType, language: string): Promise<NotificationTemplate | undefined>;
    /**
     * Create a notification with translated content
     * Uses notification templates and variable interpolation
     */
    createNotification(userId: string, type: NotificationType, variables: NotificationVariables, targetLanguage?: string): Promise<Notification>;
    /**
     * Get notification title based on type and language
     * This could also use templates, but keeping it simple for now
     */
    private getNotificationTitle;
    /**
     * Get all notifications for a user
     */
    getUserNotifications(userId: string): Promise<Notification[]>;
    /**
     * Mark notification as read
     */
    markAsRead(notificationId: string): Promise<void>;
}
export declare const notificationService: NotificationService;
//# sourceMappingURL=notification.service.d.ts.map