export { devController } from './dev.controller';
//# sourceMappingURL=index.d.ts.map