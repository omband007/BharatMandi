/**
 * Development Controller
 *
 * Provides development-only endpoints for testing and data management
 * WARNING: These endpoints should NEVER be exposed in production!
 */
export declare const devController: import("express-serve-static-core").Router;
//# sourceMappingURL=dev.controller.d.ts.map