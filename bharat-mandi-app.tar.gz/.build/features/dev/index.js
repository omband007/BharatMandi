"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.devController = void 0;
var dev_controller_1 = require("./dev.controller");
Object.defineProperty(exports, "devController", { enumerable: true, get: function () { return dev_controller_1.devController; } });
//# sourceMappingURL=index.js.map