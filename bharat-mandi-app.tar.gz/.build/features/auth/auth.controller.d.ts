export declare const authController: import("express-serve-static-core").Router;
//# sourceMappingURL=auth.controller.d.ts.map