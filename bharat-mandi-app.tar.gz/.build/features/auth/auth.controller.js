"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authController = void 0;
const express_1 = __importDefault(require("express"));
const auth_service_1 = require("./auth.service");
const common_types_1 = require("../../shared/types/common.types");
const router = express_1.default.Router();
/**
 * POST /api/auth/request-otp
 * Request OTP for phone number
 */
router.post('/request-otp', async (req, res) => {
    try {
        const { phoneNumber } = req.body;
        if (!phoneNumber) {
            return res.status(400).json({ error: 'Phone number is required' });
        }
        const result = await (0, auth_service_1.requestOTP)(phoneNumber);
        if (!result.success) {
            return res.status(400).json({ error: result.message });
        }
        res.json({ message: result.message });
    }
    catch (error) {
        console.error('Error requesting OTP:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
/**
 * POST /api/auth/verify-otp
 * Verify OTP
 */
router.post('/verify-otp', async (req, res) => {
    try {
        const { phoneNumber, otp } = req.body;
        if (!phoneNumber || !otp) {
            return res.status(400).json({ error: 'Phone number and OTP are required' });
        }
        const result = await (0, auth_service_1.verifyOTP)(phoneNumber, otp);
        if (!result.success) {
            return res.status(400).json({ error: result.message });
        }
        // Check if user exists
        const existingUser = await (0, auth_service_1.getUserByPhone)(phoneNumber);
        res.json({
            message: result.message,
            userExists: !!existingUser,
            user: existingUser
        });
    }
    catch (error) {
        console.error('Error verifying OTP:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
/**
 * POST /api/auth/register
 * Register new user
 */
router.post('/register', async (req, res) => {
    try {
        const { phoneNumber, name, userType, location, bankAccount } = req.body;
        // Validate required fields
        if (!phoneNumber || !name || !userType || !location) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        // Validate user type
        if (!Object.values(common_types_1.UserType).includes(userType)) {
            return res.status(400).json({ error: 'Invalid user type' });
        }
        // Validate location
        if (!location.latitude || !location.longitude || !location.address) {
            return res.status(400).json({ error: 'Invalid location data' });
        }
        const result = await (0, auth_service_1.createUser)({
            phoneNumber,
            name,
            userType,
            location,
            bankAccount
        });
        if (!result.success) {
            return res.status(400).json({ error: result.message });
        }
        res.status(201).json({
            message: result.message,
            user: result.user
        });
    }
    catch (error) {
        console.error('Error registering user:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
/**
 * GET /api/auth/user/:phoneNumber
 * Get user by phone number
 */
router.get('/user/:phoneNumber', async (req, res) => {
    try {
        const { phoneNumber } = req.params;
        const user = await (0, auth_service_1.getUserByPhone)(phoneNumber);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json({ user });
    }
    catch (error) {
        console.error('Error getting user:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Export as authController for feature-based architecture
exports.authController = router;
/**
 * POST /api/auth/setup-pin
 * Set up PIN for a user
 */
router.post('/setup-pin', async (req, res) => {
    try {
        const { phoneNumber, pin } = req.body;
        if (!phoneNumber || !pin) {
            return res.status(400).json({ error: 'Phone number and PIN are required' });
        }
        const result = await (0, auth_service_1.setupPIN)(phoneNumber, pin);
        if (!result.success) {
            return res.status(400).json({ error: result.message });
        }
        res.json({ message: result.message });
    }
    catch (error) {
        console.error('Error setting up PIN:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
/**
 * POST /api/auth/login
 * Login with phone number and PIN
 */
router.post('/login', async (req, res) => {
    try {
        const { phoneNumber, pin } = req.body;
        if (!phoneNumber || !pin) {
            return res.status(400).json({ error: 'Phone number and PIN are required' });
        }
        const result = await (0, auth_service_1.loginWithPIN)(phoneNumber, pin);
        if (!result.success) {
            return res.status(400).json({ error: result.message });
        }
        res.json({
            message: result.message,
            token: result.token,
            user: result.user
        });
    }
    catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
/**
 * POST /api/auth/login/biometric
 * Login with biometric authentication
 * Note: The mobile app should verify biometric locally first,
 * then call this endpoint with the phone number
 */
router.post('/login/biometric', async (req, res) => {
    try {
        const { phoneNumber } = req.body;
        if (!phoneNumber) {
            return res.status(400).json({ error: 'Phone number is required' });
        }
        const result = await (0, auth_service_1.loginWithBiometric)(phoneNumber);
        if (!result.success) {
            return res.status(400).json({ error: result.message });
        }
        res.json({
            message: result.message,
            token: result.token,
            user: result.user
        });
    }
    catch (error) {
        console.error('Error during biometric login:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
/**
 * POST /api/auth/verify-token
 * Verify JWT token
 */
router.post('/verify-token', async (req, res) => {
    try {
        const { token } = req.body;
        if (!token) {
            return res.status(400).json({ error: 'Token is required' });
        }
        const result = (0, auth_service_1.verifyToken)(token);
        if (!result.valid) {
            return res.status(401).json({ error: 'Invalid or expired token' });
        }
        res.json({
            valid: true,
            userId: result.userId,
            phoneNumber: result.phoneNumber,
            userType: result.userType
        });
    }
    catch (error) {
        console.error('Error verifying token:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
/**
 * GET /api/auth/profile/:userId
 * Get user profile
 */
router.get('/profile/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }
        const result = await (0, auth_service_1.getUserProfile)(userId);
        if (!result.success) {
            return res.status(404).json({ error: result.message });
        }
        res.json({
            message: result.message,
            user: result.user
        });
    }
    catch (error) {
        console.error('Error getting profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
/**
 * PUT /api/auth/profile/:userId
 * Update user profile
 * Requires OTP verification for sensitive data changes (phone, bank account)
 */
router.put('/profile/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const { name, location, phoneNumber, bankAccount, isPhoneVerified } = req.body;
        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }
        const result = await (0, auth_service_1.updateUserProfile)(userId, {
            name,
            location,
            phoneNumber,
            bankAccount
        }, isPhoneVerified);
        if (!result.success) {
            if (result.requiresVerification) {
                return res.status(403).json({
                    error: result.message,
                    requiresVerification: true
                });
            }
            return res.status(400).json({ error: result.message });
        }
        res.json({
            message: result.message,
            user: result.user
        });
    }
    catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
//# sourceMappingURL=auth.controller.js.map