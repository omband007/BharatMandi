/**
 * Test Data Factories for Auth Controller Tests
 *
 * Provides factory functions to create test data objects with sensible defaults
 * and support for partial overrides.
 */
import { User, OTPSession } from '../../auth.types';
import { Location, BankAccount } from '../../../../shared/types/common.types';
/**
 * Create a test user with default values
 */
export declare function createTestUser(overrides?: Partial<User>): User;
/**
 * Create a test user with language preferences
 */
export declare function createTestUserWithLanguages(overrides?: Partial<User>): User;
/**
 * Create a test location with default values
 */
export declare function createTestLocation(overrides?: Partial<Location>): Location;
/**
 * Create a test bank account with default values
 */
export declare function createTestBankAccount(overrides?: Partial<BankAccount>): BankAccount;
/**
 * Create a test OTP session with default values
 */
export declare function createTestOTPSession(overrides?: Partial<OTPSession>): OTPSession;
/**
 * Create a test JWT token
 */
export declare function createTestToken(userId?: string): string;
//# sourceMappingURL=test-data-factories.d.ts.map