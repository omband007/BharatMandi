/**
 * Test Constants for Auth Controller Tests
 *
 * Provides shared constants for phone numbers, PINs, user types,
 * supported languages, and SQL injection payloads.
 */
import { UserType } from '../../../../shared/types/common.types';
export declare const TEST_PHONE_NUMBERS: {
    VALID: string;
    WITH_COUNTRY_CODE: string;
    WITH_91_PREFIX: string;
    INVALID_SHORT: string;
    INVALID_LONG: string;
    INVALID_CHARS: string;
};
export declare const TEST_PINS: {
    VALID_4_DIGIT: string;
    VALID_6_DIGIT: string;
    INVALID_SHORT: string;
    INVALID_LONG: string;
};
export declare const TEST_USER_TYPES: UserType[];
export declare const SUPPORTED_LANGUAGES: string[];
export declare const SQL_INJECTION_PAYLOADS: string[];
//# sourceMappingURL=test-constants.d.ts.map