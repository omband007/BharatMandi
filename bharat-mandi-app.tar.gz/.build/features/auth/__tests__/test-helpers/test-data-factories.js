"use strict";
/**
 * Test Data Factories for Auth Controller Tests
 *
 * Provides factory functions to create test data objects with sensible defaults
 * and support for partial overrides.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTestUser = createTestUser;
exports.createTestUserWithLanguages = createTestUserWithLanguages;
exports.createTestLocation = createTestLocation;
exports.createTestBankAccount = createTestBankAccount;
exports.createTestOTPSession = createTestOTPSession;
exports.createTestToken = createTestToken;
const common_types_1 = require("../../../../shared/types/common.types");
/**
 * Create a test user with default values
 */
function createTestUser(overrides) {
    return {
        id: 'test-user-id',
        phoneNumber: '9876543210',
        name: 'Test User',
        userType: common_types_1.UserType.FARMER,
        location: createTestLocation(),
        createdAt: new Date('2024-01-01T00:00:00.000Z'),
        ...overrides
    };
}
/**
 * Create a test user with language preferences
 */
function createTestUserWithLanguages(overrides) {
    return createTestUser({
        languagePreference: 'hi',
        voiceLanguagePreference: 'hi',
        recentLanguages: ['hi', 'en'],
        ...overrides
    });
}
/**
 * Create a test location with default values
 */
function createTestLocation(overrides) {
    return {
        latitude: 28.6139,
        longitude: 77.2090,
        address: 'Test Address, Delhi',
        ...overrides
    };
}
/**
 * Create a test bank account with default values
 */
function createTestBankAccount(overrides) {
    return {
        accountNumber: '1234567890',
        ifscCode: 'TEST0001234',
        bankName: 'Test Bank',
        accountHolderName: 'Test User',
        ...overrides
    };
}
/**
 * Create a test OTP session with default values
 */
function createTestOTPSession(overrides) {
    return {
        phoneNumber: '9876543210',
        otp: '123456',
        expiresAt: new Date(Date.now() + 5 * 60 * 1000), // 5 minutes from now
        attempts: 0,
        ...overrides
    };
}
/**
 * Create a test JWT token
 */
function createTestToken(userId = 'test-user-id') {
    return `test-jwt-token-${userId}`;
}
//# sourceMappingURL=test-data-factories.js.map