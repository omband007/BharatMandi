/**
 * Create mock sqliteHelpers for testing auth service
 *
 * This creates Jest mock functions for all sqliteHelpers functions used by the auth service.
 * Each function is a Jest mock that can be configured with mockResolvedValue/mockRejectedValue.
 */
export declare function createMockSqliteHelpers(): {
    createOTPSession: jest.Mock<any, any, any>;
    getOTPSession: jest.Mock<any, any, any>;
    deleteOTPSession: jest.Mock<any, any, any>;
    updateOTPAttempts: jest.Mock<any, any, any>;
    getUserPinHash: jest.Mock<any, any, any>;
    updateUserPin: jest.Mock<any, any, any>;
    getFailedAttempts: jest.Mock<any, any, any>;
    incrementFailedAttempts: jest.Mock<any, any, any>;
    resetFailedAttempts: jest.Mock<any, any, any>;
    lockAccount: jest.Mock<any, any, any>;
    createUser: jest.Mock<any, any, any>;
    getUserByPhone: jest.Mock<any, any, any>;
    getUserById: jest.Mock<any, any, any>;
    updateUser: jest.Mock<any, any, any>;
};
/**
 * Configure mock sqliteHelpers with default resolved values
 *
 * This sets up default behavior for all mock functions to return successful responses.
 * Individual tests can override these defaults using mockResolvedValue/mockRejectedValue.
 *
 * @param mockHelpers - The mock helpers object created by createMockSqliteHelpers()
 */
export declare function configureMockSqliteHelpers(mockHelpers: ReturnType<typeof createMockSqliteHelpers>): void;
//# sourceMappingURL=mock-sqlite-helpers.d.ts.map