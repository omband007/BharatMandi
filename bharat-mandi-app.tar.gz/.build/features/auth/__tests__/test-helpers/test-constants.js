"use strict";
/**
 * Test Constants for Auth Controller Tests
 *
 * Provides shared constants for phone numbers, PINs, user types,
 * supported languages, and SQL injection payloads.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SQL_INJECTION_PAYLOADS = exports.SUPPORTED_LANGUAGES = exports.TEST_USER_TYPES = exports.TEST_PINS = exports.TEST_PHONE_NUMBERS = void 0;
const common_types_1 = require("../../../../shared/types/common.types");
exports.TEST_PHONE_NUMBERS = {
    VALID: '9876543210',
    WITH_COUNTRY_CODE: '+919876543210',
    WITH_91_PREFIX: '919876543210',
    INVALID_SHORT: '987654',
    INVALID_LONG: '98765432109876',
    INVALID_CHARS: '98765abcde'
};
exports.TEST_PINS = {
    VALID_4_DIGIT: '1234',
    VALID_6_DIGIT: '123456',
    INVALID_SHORT: '12',
    INVALID_LONG: '1234567'
};
exports.TEST_USER_TYPES = [
    common_types_1.UserType.FARMER,
    common_types_1.UserType.BUYER,
    common_types_1.UserType.LOGISTICS_PROVIDER
];
exports.SUPPORTED_LANGUAGES = [
    'en', 'hi', 'bn', 'te', 'mr', 'ta', 'gu', 'kn', 'ml', 'or', 'pa'
];
exports.SQL_INJECTION_PAYLOADS = [
    "'; DROP TABLE users; --",
    "' OR '1'='1",
    "' UNION SELECT * FROM users --",
    "admin'--",
    "' OR 1=1--"
];
//# sourceMappingURL=test-constants.js.map