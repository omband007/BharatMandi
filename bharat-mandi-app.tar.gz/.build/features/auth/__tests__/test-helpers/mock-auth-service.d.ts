/**
 * Mock Auth Service Configuration
 *
 * Provides mock implementations for all auth service methods
 * to enable isolated controller testing.
 */
/**
 * Create mock auth service with all methods
 */
export declare function createMockAuthService(): {
    requestOTP: jest.Mock<any, any, any>;
    verifyOTP: jest.Mock<any, any, any>;
    createUser: jest.Mock<any, any, any>;
    getUserByPhone: jest.Mock<any, any, any>;
    setupPIN: jest.Mock<any, any, any>;
    loginWithPIN: jest.Mock<any, any, any>;
    loginWithBiometric: jest.Mock<any, any, any>;
    verifyToken: jest.Mock<any, any, any>;
    getUserProfile: jest.Mock<any, any, any>;
    updateUserProfile: jest.Mock<any, any, any>;
};
/**
 * Configure mock auth service with default success responses
 */
export declare function configureMockAuthService(mockService: ReturnType<typeof createMockAuthService>): void;
//# sourceMappingURL=mock-auth-service.d.ts.map