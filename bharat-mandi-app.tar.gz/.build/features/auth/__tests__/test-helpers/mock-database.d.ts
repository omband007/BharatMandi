/**
 * Mock Database Helper for Auth Service Tests
 *
 * Provides mock DatabaseManager configuration for testing auth service functions
 * without requiring actual database connections.
 */
/**
 * Create mock DatabaseManager for testing
 *
 * Returns a mock object that mimics the DatabaseManager interface with
 * Jest mock functions for all database operations.
 */
export declare function createMockDatabaseManager(): {
    db: {
        prepare: jest.Mock<any, any, any>;
    };
};
/**
 * Configure mock database with default behavior
 *
 * Sets up default successful responses for common database operations.
 * Individual tests can override these defaults as needed.
 *
 * @param mockDb - The mock database manager created by createMockDatabaseManager()
 */
export declare function configureMockDatabase(mockDb: ReturnType<typeof createMockDatabaseManager>): void;
//# sourceMappingURL=mock-database.d.ts.map