import { UserType } from '../../shared/types/common.types';
import type { User } from './auth.types';
interface LoginResponse {
    success: boolean;
    token?: string;
    user?: User;
    message: string;
}
/**
 * Request OTP for phone number
 */
export declare function requestOTP(phoneNumber: string): Promise<{
    success: boolean;
    message: string;
}>;
/**
 * Verify OTP
 */
export declare function verifyOTP(phoneNumber: string, otp: string): Promise<{
    success: boolean;
    message: string;
}>;
/**
 * Create new user account
 * Requires prior OTP verification (Property 13)
 */
export declare function createUser(userData: {
    phoneNumber: string;
    name: string;
    userType: UserType;
    location: {
        latitude: number;
        longitude: number;
        address: string;
    };
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        bankName: string;
        accountHolderName: string;
    };
}): Promise<{
    success: boolean;
    user?: User;
    message: string;
}>;
/**
 * Get user by phone number
 */
export declare function getUserByPhone(phoneNumber: string): Promise<User | null>;
/**
 * Get OTP for testing purposes only
 * WARNING: This should NEVER be exposed in production!
 */
export declare function getOTPForTesting(phoneNumber: string): Promise<string | null>;
/**
 * Clear verified phone numbers (for testing)
 */
export declare function clearVerifiedPhoneNumbers(): void;
/**
 * Set up PIN for a user
 * Should be called after registration
 */
export declare function setupPIN(phoneNumber: string, pin: string): Promise<{
    success: boolean;
    message: string;
}>;
/**
 * Login with phone number and PIN
 */
export declare function loginWithPIN(phoneNumber: string, pin: string): Promise<LoginResponse>;
/**
 * Verify JWT token
 */
export declare function verifyToken(token: string): {
    valid: boolean;
    userId?: string;
    phoneNumber?: string;
    userType?: UserType;
};
/**
 * Login with biometric authentication
 * This requires the mobile app to first verify biometric locally,
 * then call this endpoint with a valid session token or phone number
 */
export declare function loginWithBiometric(phoneNumber: string): Promise<LoginResponse>;
/**
 * Get user profile by ID
 */
export declare function getUserProfile(userId: string): Promise<{
    success: boolean;
    user?: User;
    message: string;
}>;
/**
 * Update user profile
 * Requires re-verification for sensitive data (phone number, bank account)
 */
export declare function updateUserProfile(userId: string, updates: {
    name?: string;
    location?: {
        latitude: number;
        longitude: number;
        address: string;
    };
    phoneNumber?: string;
    bankAccount?: {
        accountNumber: string;
        ifscCode: string;
        bankName: string;
        accountHolderName: string;
    };
}, isPhoneVerified?: boolean): Promise<{
    success: boolean;
    user?: User;
    requiresVerification?: boolean;
    message: string;
}>;
export {};
//# sourceMappingURL=auth.service.d.ts.map