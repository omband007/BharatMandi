"use strict";
// Core type definitions for Bharat Mandi Platform
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogisticsStatus = exports.AuctionStatus = exports.ActivityCategory = exports.DisputeStatus = exports.TransactionStatus = exports.ProduceGrade = exports.UserType = void 0;
// ============================================================================
// ENUMS
// ============================================================================
var UserType;
(function (UserType) {
    UserType["FARMER"] = "FARMER";
    UserType["BUYER"] = "BUYER";
    UserType["LOGISTICS_PROVIDER"] = "LOGISTICS_PROVIDER";
    UserType["COLD_STORAGE_PROVIDER"] = "COLD_STORAGE_PROVIDER";
    UserType["SUPPLIER"] = "SUPPLIER";
})(UserType || (exports.UserType = UserType = {}));
var ProduceGrade;
(function (ProduceGrade) {
    ProduceGrade["A"] = "A";
    ProduceGrade["B"] = "B";
    ProduceGrade["C"] = "C";
})(ProduceGrade || (exports.ProduceGrade = ProduceGrade = {}));
var TransactionStatus;
(function (TransactionStatus) {
    TransactionStatus["PENDING"] = "PENDING";
    TransactionStatus["ACCEPTED"] = "ACCEPTED";
    TransactionStatus["PAYMENT_LOCKED"] = "PAYMENT_LOCKED";
    TransactionStatus["IN_TRANSIT"] = "IN_TRANSIT";
    TransactionStatus["DELIVERED"] = "DELIVERED";
    TransactionStatus["COMPLETED"] = "COMPLETED";
    TransactionStatus["DISPUTED"] = "DISPUTED";
    TransactionStatus["REJECTED"] = "REJECTED";
})(TransactionStatus || (exports.TransactionStatus = TransactionStatus = {}));
var DisputeStatus;
(function (DisputeStatus) {
    DisputeStatus["INITIATED"] = "INITIATED";
    DisputeStatus["UNDER_REVIEW"] = "UNDER_REVIEW";
    DisputeStatus["RESOLVED"] = "RESOLVED";
    DisputeStatus["ESCALATED"] = "ESCALATED";
})(DisputeStatus || (exports.DisputeStatus = DisputeStatus = {}));
var ActivityCategory;
(function (ActivityCategory) {
    ActivityCategory["TILLING"] = "TILLING";
    ActivityCategory["SOWING"] = "SOWING";
    ActivityCategory["SPRAYING"] = "SPRAYING";
    ActivityCategory["FERTIGATION"] = "FERTIGATION";
    ActivityCategory["HARVEST"] = "HARVEST";
    ActivityCategory["OTHER"] = "OTHER";
})(ActivityCategory || (exports.ActivityCategory = ActivityCategory = {}));
var AuctionStatus;
(function (AuctionStatus) {
    AuctionStatus["OPEN"] = "OPEN";
    AuctionStatus["CLOSED"] = "CLOSED";
    AuctionStatus["CANCELLED"] = "CANCELLED";
})(AuctionStatus || (exports.AuctionStatus = AuctionStatus = {}));
var LogisticsStatus;
(function (LogisticsStatus) {
    LogisticsStatus["PENDING"] = "PENDING";
    LogisticsStatus["ASSIGNED"] = "ASSIGNED";
    LogisticsStatus["IN_TRANSIT"] = "IN_TRANSIT";
    LogisticsStatus["DELIVERED"] = "DELIVERED";
    LogisticsStatus["CANCELLED"] = "CANCELLED";
})(LogisticsStatus || (exports.LogisticsStatus = LogisticsStatus = {}));
//# sourceMappingURL=index.js.map