"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("./app"));
const PORT = parseInt(process.env.PORT || '3000');
// Start server
app_1.default.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Bharat Mandi POC server running on port ${PORT}`);
    console.log(`📍 Health check: http://localhost:${PORT}/api/health`);
    console.log(`🌐 Web UI: http://localhost:${PORT}`);
});
exports.default = app_1.default;
//# sourceMappingURL=index.js.map