/**
 * Environment Configuration
 *
 * Centralized configuration for different environments (development, testing, production)
 */
export interface EnvironmentConfig {
    nodeEnv: 'development' | 'testing' | 'production';
    server: {
        port: number;
    };
    database: {
        host: string;
        port: number;
        name: string;
        user: string;
        password: string;
        ssl: boolean;
    };
    aws: {
        region: string;
        accessKeyId: string;
        secretAccessKey: string;
        s3: {
            listingsBucket: string;
            audioBucket: string;
            useS3ForListings: boolean;
        };
        lex: {
            botId: string;
            botAliasId: string;
            region: string;
        };
    };
    redis: {
        host: string;
        port: number;
    };
    mongodb: {
        uri: string;
    };
}
export declare function getEnvironmentConfig(): EnvironmentConfig;
/**
 * Validate configuration on startup
 * Throws error if required configuration is missing
 */
export declare function validateConfig(config: EnvironmentConfig): void;
export declare const environmentConfig: EnvironmentConfig;
//# sourceMappingURL=environment.d.ts.map