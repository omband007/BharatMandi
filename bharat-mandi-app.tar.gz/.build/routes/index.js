"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const uuid_1 = require("uuid");
const memory_db_1 = require("../database/memory-db");
const grading_controller_1 = __importDefault(require("../features/grading/grading.controller"));
const auth_controller_1 = __importDefault(require("../features/auth/auth.controller"));
const marketplace_service_1 = require("../services/marketplace.service");
const transaction_service_1 = require("../services/transaction.service");
const router = (0, express_1.Router)();
// Health check
router.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date() });
});
// Use authentication routes
router.use('/auth', auth_controller_1.default);
// Use grading routes
router.use('/grading', grading_controller_1.default);
// Create user (farmer or buyer)
router.post('/users', (req, res) => {
    const { name, phone, type, location } = req.body;
    const user = memory_db_1.db.createUser({
        id: (0, uuid_1.v4)(),
        name,
        phone,
        type: type,
        location,
        createdAt: new Date()
    });
    res.status(201).json(user);
});
// Get all users
router.get('/users', (req, res) => {
    res.json(memory_db_1.db.getAllUsers());
});
// Create listing
router.post('/listings', (req, res) => {
    const { farmerId, produceType, quantity, pricePerKg, certificateId } = req.body;
    const listing = marketplace_service_1.marketplaceService.createListing(farmerId, produceType, quantity, pricePerKg, certificateId);
    res.status(201).json(listing);
});
// Get active listings
router.get('/listings', (req, res) => {
    res.json(marketplace_service_1.marketplaceService.getActiveListings());
});
// Get listing by ID
router.get('/listings/:id', (req, res) => {
    const listing = marketplace_service_1.marketplaceService.getListing(req.params.id);
    if (!listing) {
        return res.status(404).json({ error: 'Listing not found' });
    }
    res.json(listing);
});
// Initiate purchase
router.post('/transactions', (req, res) => {
    const { listingId, farmerId, buyerId, amount } = req.body;
    const transaction = transaction_service_1.transactionService.initiatePurchase(listingId, farmerId, buyerId, amount);
    res.status(201).json(transaction);
});
// Accept order
router.post('/transactions/:id/accept', (req, res) => {
    const transaction = transaction_service_1.transactionService.acceptOrder(req.params.id);
    if (!transaction) {
        return res.status(404).json({ error: 'Transaction not found' });
    }
    // Create escrow
    const escrow = transaction_service_1.transactionService.createEscrow(transaction.id, transaction.amount);
    res.json({ transaction, escrow });
});
// Lock payment
router.post('/transactions/:id/lock-payment', (req, res) => {
    const result = transaction_service_1.transactionService.lockPayment(req.params.id);
    if (!result.transaction) {
        return res.status(404).json({ error: 'Transaction or escrow not found' });
    }
    res.json(result);
});
// Mark dispatched
router.post('/transactions/:id/dispatch', (req, res) => {
    const transaction = transaction_service_1.transactionService.markDispatched(req.params.id);
    if (!transaction) {
        return res.status(404).json({ error: 'Transaction not found' });
    }
    res.json(transaction);
});
// Mark delivered
router.post('/transactions/:id/deliver', (req, res) => {
    const transaction = transaction_service_1.transactionService.markDelivered(req.params.id);
    if (!transaction) {
        return res.status(404).json({ error: 'Transaction not found' });
    }
    res.json(transaction);
});
// Release funds
router.post('/transactions/:id/release-funds', (req, res) => {
    const result = transaction_service_1.transactionService.releaseFunds(req.params.id);
    if (!result.transaction) {
        return res.status(404).json({ error: 'Transaction or escrow not found' });
    }
    res.json(result);
});
// Get transaction
router.get('/transactions/:id', (req, res) => {
    const transaction = transaction_service_1.transactionService.getTransaction(req.params.id);
    if (!transaction) {
        return res.status(404).json({ error: 'Transaction not found' });
    }
    res.json(transaction);
});
exports.default = router;
//# sourceMappingURL=index.js.map