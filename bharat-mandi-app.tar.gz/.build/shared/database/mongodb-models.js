"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mongoose = exports.FarmingTipModel = exports.AdListingModel = exports.TraceabilityRecordModel = exports.SmartAlertModel = exports.SoilTestReportModel = exports.DiseaseDiagnosisModel = exports.FeedbackCommentModel = exports.VoiceQueryModel = exports.PricePredictionModel = exports.QualityCertificateModel = exports.PhotoLogModel = void 0;
exports.createIndexes = createIndexes;
exports.dropAllCollections = dropAllCollections;
exports.getCollectionStats = getCollectionStats;
const mongoose_1 = require("mongoose");
const mongodb_schemas_1 = require("./mongodb-schemas");
// ============================================================================
// MODELS
// ============================================================================
exports.PhotoLogModel = (0, mongoose_1.model)('PhotoLog', mongodb_schemas_1.PhotoLogSchema);
exports.QualityCertificateModel = (0, mongoose_1.model)('QualityCertificate', mongodb_schemas_1.QualityCertificateSchema);
exports.PricePredictionModel = (0, mongoose_1.model)('PricePrediction', mongodb_schemas_1.PricePredictionSchema);
exports.VoiceQueryModel = (0, mongoose_1.model)('VoiceQuery', mongodb_schemas_1.VoiceQuerySchema);
exports.FeedbackCommentModel = (0, mongoose_1.model)('FeedbackComment', mongodb_schemas_1.FeedbackCommentSchema);
exports.DiseaseDiagnosisModel = (0, mongoose_1.model)('DiseaseDiagnosis', mongodb_schemas_1.DiseaseDiagnosisSchema);
exports.SoilTestReportModel = (0, mongoose_1.model)('SoilTestReport', mongodb_schemas_1.SoilTestReportSchema);
exports.SmartAlertModel = (0, mongoose_1.model)('SmartAlert', mongodb_schemas_1.SmartAlertSchema);
exports.TraceabilityRecordModel = (0, mongoose_1.model)('TraceabilityRecord', mongodb_schemas_1.TraceabilityRecordSchema);
exports.AdListingModel = (0, mongoose_1.model)('AdListing', mongodb_schemas_1.AdListingSchema);
exports.FarmingTipModel = (0, mongoose_1.model)('FarmingTip', mongodb_schemas_1.FarmingTipSchema);
// ============================================================================
// HELPER FUNCTIONS
// ============================================================================
// Create indexes for all collections
async function createIndexes() {
    console.log('Creating MongoDB indexes...');
    await exports.PhotoLogModel.createIndexes();
    await exports.QualityCertificateModel.createIndexes();
    await exports.PricePredictionModel.createIndexes();
    await exports.VoiceQueryModel.createIndexes();
    await exports.FeedbackCommentModel.createIndexes();
    await exports.DiseaseDiagnosisModel.createIndexes();
    await exports.SoilTestReportModel.createIndexes();
    await exports.SmartAlertModel.createIndexes();
    await exports.TraceabilityRecordModel.createIndexes();
    await exports.AdListingModel.createIndexes();
    await exports.FarmingTipModel.createIndexes();
    console.log('✓ All MongoDB indexes created successfully');
}
// Drop all collections (for development/testing)
async function dropAllCollections() {
    if (!mongoose_2.default.connection.db) {
        throw new Error('Database connection not established');
    }
    const collections = await mongoose_2.default.connection.db.collections();
    for (const collection of collections) {
        await collection.drop();
    }
    console.log('✓ All collections dropped');
}
// Get collection statistics
async function getCollectionStats() {
    const stats = {};
    stats.photoLogs = await exports.PhotoLogModel.countDocuments();
    stats.qualityCertificates = await exports.QualityCertificateModel.countDocuments();
    stats.pricePredictions = await exports.PricePredictionModel.countDocuments();
    stats.voiceQueries = await exports.VoiceQueryModel.countDocuments();
    stats.feedbackComments = await exports.FeedbackCommentModel.countDocuments();
    stats.diseaseDiagnoses = await exports.DiseaseDiagnosisModel.countDocuments();
    stats.soilTestReports = await exports.SoilTestReportModel.countDocuments();
    stats.smartAlerts = await exports.SmartAlertModel.countDocuments();
    stats.traceabilityRecords = await exports.TraceabilityRecordModel.countDocuments();
    stats.adListings = await exports.AdListingModel.countDocuments();
    stats.farmingTips = await exports.FarmingTipModel.countDocuments();
    return stats;
}
// Export mongoose for direct access if needed
const mongoose_2 = __importDefault(require("mongoose"));
exports.mongoose = mongoose_2.default;
//# sourceMappingURL=mongodb-models.js.map