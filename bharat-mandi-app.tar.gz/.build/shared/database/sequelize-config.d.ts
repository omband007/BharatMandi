import { Sequelize } from 'sequelize';
declare const sequelize: Sequelize;
export declare function testSequelizeConnection(): Promise<boolean>;
export declare function syncDatabase(force?: boolean): Promise<void>;
export declare function closeSequelizeConnection(): Promise<void>;
export { sequelize };
export default sequelize;
//# sourceMappingURL=sequelize-config.d.ts.map