import type { OTPSession } from '../../features/profile/types/profile.types';
export declare function createOTPSession(session: OTPSession): Promise<void>;
export declare function getOTPSession(phoneNumber: string): Promise<OTPSession | undefined>;
export declare function updateOTPAttempts(phoneNumber: string, attempts: number): Promise<void>;
export declare function deleteOTPSession(phoneNumber: string): Promise<void>;
export declare function cleanupExpiredOTPSessions(): Promise<void>;
export interface SyncQueueItem {
    id?: number;
    operation_type: 'CREATE' | 'UPDATE' | 'DELETE';
    entity_type: string;
    entity_id: string;
    data: string;
    created_at?: string;
    retry_count?: number;
    last_retry_at?: string;
    error_message?: string;
}
export declare function addToSyncQueue(item: Omit<SyncQueueItem, 'id' | 'created_at' | 'retry_count'>): Promise<number>;
export declare function getPendingSyncItems(limit?: number): Promise<SyncQueueItem[]>;
export declare function removeSyncQueueItem(id: number): Promise<void>;
export declare function updateSyncQueueRetry(id: number, errorMessage: string): Promise<void>;
export interface CachedListing {
    id: string;
    farmer_id: string;
    produce_type: string;
    quantity: number;
    price_per_kg: number;
    certificate_id?: string;
    expected_harvest_date?: string;
    is_active: number;
    created_at?: string;
    cached_at?: string;
}
export declare function cacheListing(listing: CachedListing): Promise<void>;
export declare function getCachedListings(filters?: {
    produce_type?: string;
    is_active?: number;
}): Promise<CachedListing[]>;
export interface LocalPhotoLog {
    id: string;
    farmer_id: string;
    image_path: string;
    category: string;
    location_lat: number;
    location_lng: number;
    timestamp: string;
    notes?: string;
    transaction_id?: string;
    synced: number;
    created_at?: string;
}
export declare function saveLocalPhotoLog(photoLog: LocalPhotoLog): Promise<void>;
export declare function getUnsyncedPhotoLogs(): Promise<LocalPhotoLog[]>;
export declare function markPhotoLogAsSynced(id: string): Promise<void>;
export interface UserProfile {
    id: string;
    name: string;
    phone: string;
    type: string;
    location: string;
    bank_account_number?: string;
    bank_ifsc_code?: string;
    bank_name?: string;
    bank_account_holder_name?: string;
    credibility_score: number;
    rating: number;
    last_synced_at?: string;
}
export declare function cacheUserProfile(profile: UserProfile): Promise<void>;
export declare function getCachedUserProfile(userId: string): Promise<UserProfile | undefined>;
export interface OfflineActivity {
    id?: number;
    activity_type: string;
    user_id: string;
    data: string;
    status: 'PENDING' | 'SYNCED' | 'FAILED';
    created_at?: string;
    synced_at?: string;
    error_message?: string;
}
export declare function logOfflineActivity(activity: Omit<OfflineActivity, 'id' | 'created_at'>): Promise<number>;
export declare function getPendingOfflineActivities(): Promise<OfflineActivity[]>;
export declare function updateOfflineActivityStatus(id: number, status: 'SYNCED' | 'FAILED', errorMessage?: string): Promise<void>;
export declare function getAppSetting(key: string): Promise<string | undefined>;
export declare function setAppSetting(key: string, value: string): Promise<void>;
export declare function isOfflineMode(): Promise<boolean>;
export declare function setOfflineMode(offline: boolean): Promise<void>;
export interface SyncStatus {
    id?: number;
    entity_type: string;
    last_sync_at?: string;
    last_sync_status: 'SUCCESS' | 'FAILED' | 'IN_PROGRESS';
    records_synced: number;
    records_failed: number;
    error_message?: string;
}
export declare function updateSyncStatus(status: SyncStatus): Promise<void>;
export declare function getSyncStatus(entityType: string): Promise<SyncStatus | undefined>;
export declare function getAllSyncStatuses(): Promise<SyncStatus[]>;
export declare function createListing(listing: any): Promise<any>;
export declare function getListing(id: string): Promise<any | undefined>;
export declare function getActiveListings(): Promise<any[]>;
export declare function updateListing(id: string, updates: any): Promise<any | undefined>;
export declare function createTransaction(transaction: any): Promise<any>;
export declare function getTransaction(id: string): Promise<any | undefined>;
export declare function updateTransaction(id: string, updates: any): Promise<any | undefined>;
export declare function createEscrow(escrow: any): Promise<any>;
export declare function getEscrow(id: string): Promise<any | undefined>;
export declare function getEscrowByTransaction(transactionId: string): Promise<any | undefined>;
export declare function updateEscrow(id: string, updates: any): Promise<any | undefined>;
//# sourceMappingURL=sqlite-helpers.d.ts.map