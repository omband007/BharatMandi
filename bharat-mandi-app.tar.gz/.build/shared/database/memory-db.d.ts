import { UserType } from '../types/common.types';
import type { DigitalQualityCertificate } from '../../features/grading/grading.types';
import type { Listing } from '../../features/marketplace/marketplace.types';
import type { Transaction, EscrowAccount } from '../../features/transactions/transaction.types';
export interface User {
    id: string;
    phoneNumber: string;
    name: string;
    userType: UserType;
    location: any;
    bankAccount?: any;
    languagePreference?: string;
    createdAt: Date;
    updatedAt?: Date;
}
declare class MemoryDatabase {
    private users;
    private certificates;
    private listings;
    private transactions;
    private escrowAccounts;
    createUser(user: User): User;
    getUser(id: string): User | undefined;
    getAllUsers(): User[];
    createCertificate(certificate: DigitalQualityCertificate): DigitalQualityCertificate;
    getCertificate(id: string): DigitalQualityCertificate | undefined;
    createListing(listing: Listing): Listing;
    getListing(id: string): Listing | undefined;
    getActiveListings(): Listing[];
    updateListing(id: string, updates: Partial<Listing>): Listing | undefined;
    createTransaction(transaction: Transaction): Transaction;
    getTransaction(id: string): Transaction | undefined;
    updateTransaction(id: string, updates: Partial<Transaction>): Transaction | undefined;
    createEscrow(escrow: EscrowAccount): EscrowAccount;
    getEscrow(id: string): EscrowAccount | undefined;
    getEscrowByTransaction(transactionId: string): EscrowAccount | undefined;
    updateEscrow(id: string, updates: Partial<EscrowAccount>): EscrowAccount | undefined;
    clear(): void;
}
export declare const db: MemoryDatabase;
export {};
//# sourceMappingURL=memory-db.d.ts.map