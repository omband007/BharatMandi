"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DB_PATH = void 0;
exports.openSQLiteDB = openSQLiteDB;
exports.closeSQLiteDB = closeSQLiteDB;
exports.getSQLiteDB = getSQLiteDB;
exports.initializeSQLiteSchema = initializeSQLiteSchema;
exports.testSQLiteConnection = testSQLiteConnection;
exports.getSQLiteStats = getSQLiteStats;
exports.clearAllCachedData = clearAllCachedData;
exports.vacuumDatabase = vacuumDatabase;
exports.getDatabaseSize = getDatabaseSize;
const sqlite3_1 = __importDefault(require("sqlite3"));
const sqlite_1 = require("sqlite");
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
const dotenv = __importStar(require("dotenv"));
// Load environment variables
dotenv.config();
// SQLite database path
const DB_DIR = process.env.SQLITE_DB_DIR || path.join(__dirname, '../../data');
const DB_PATH = path.join(DB_DIR, 'offline.db');
exports.DB_PATH = DB_PATH;
let db = null;
// Ensure data directory exists
function ensureDataDirectory() {
    if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
        console.log(`✓ Created data directory: ${DB_DIR}`);
    }
}
// Open SQLite database connection
async function openSQLiteDB() {
    if (db) {
        return db;
    }
    ensureDataDirectory();
    db = await (0, sqlite_1.open)({
        filename: DB_PATH,
        driver: sqlite3_1.default.Database
    });
    // Disable foreign keys temporarily for development (data may be incomplete in SQLite)
    // TODO: Re-enable when proper sync is implemented
    // await db.exec('PRAGMA foreign_keys = ON;');
    await db.exec('PRAGMA foreign_keys = OFF;');
    // Enable WAL mode for better concurrency
    await db.exec('PRAGMA journal_mode = WAL;');
    // Set busy timeout to 5 seconds (5000ms) to handle lock contention
    await db.exec('PRAGMA busy_timeout = 5000;');
    console.log(`✓ SQLite database opened: ${DB_PATH}`);
    return db;
}
// Close SQLite database connection
async function closeSQLiteDB() {
    if (db) {
        await db.close();
        db = null;
        console.log('✓ SQLite database closed');
    }
}
// Get current database instance
function getSQLiteDB() {
    if (!db) {
        throw new Error('SQLite database not initialized. Call openSQLiteDB() first.');
    }
    return db;
}
// Initialize database schema
async function initializeSQLiteSchema() {
    const database = await openSQLiteDB();
    const schemaPath = path.join(__dirname, 'sqlite-schema.sql');
    if (!fs.existsSync(schemaPath)) {
        throw new Error(`Schema file not found: ${schemaPath}`);
    }
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    await database.exec(schema);
    console.log('✓ SQLite schema initialized');
}
// Test SQLite connection
async function testSQLiteConnection() {
    try {
        const database = await openSQLiteDB();
        const result = await database.get('SELECT 1 as test');
        console.log('✓ SQLite connection test passed:', result);
        return true;
    }
    catch (error) {
        console.error('✗ SQLite connection test failed:', error);
        return false;
    }
}
// Get database statistics
async function getSQLiteStats() {
    const database = getSQLiteDB();
    const stats = {};
    const tables = [
        'cached_listings',
        'pending_sync_queue',
        'local_photo_logs',
        'user_profile',
        'ai_models_metadata',
        'cached_certificates',
        'offline_activities',
        'cached_transactions',
        'sync_status',
        'app_settings'
    ];
    for (const table of tables) {
        const result = await database.get(`SELECT COUNT(*) as count FROM ${table}`);
        stats[table] = result?.count || 0;
    }
    return stats;
}
// Clear all cached data (for development/testing)
async function clearAllCachedData() {
    const database = getSQLiteDB();
    await database.exec(`
    DELETE FROM cached_listings;
    DELETE FROM pending_sync_queue;
    DELETE FROM local_photo_logs;
    DELETE FROM cached_certificates;
    DELETE FROM offline_activities;
    DELETE FROM cached_transactions;
  `);
    console.log('✓ All cached data cleared');
}
// Vacuum database to reclaim space
async function vacuumDatabase() {
    const database = getSQLiteDB();
    await database.exec('VACUUM;');
    console.log('✓ Database vacuumed');
}
// Get database file size
function getDatabaseSize() {
    if (fs.existsSync(DB_PATH)) {
        const stats = fs.statSync(DB_PATH);
        return stats.size;
    }
    return 0;
}
//# sourceMappingURL=sqlite-config.js.map