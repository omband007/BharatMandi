"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FarmingTipSchema = exports.AdListingSchema = exports.TraceabilityRecordSchema = exports.SmartAlertSchema = exports.SoilTestReportSchema = exports.DiseaseDiagnosisSchema = exports.FeedbackCommentSchema = exports.VoiceQuerySchema = exports.PricePredictionSchema = exports.QualityCertificateSchema = exports.PhotoLogSchema = void 0;
const mongoose_1 = require("mongoose");
// ============================================================================
// PHOTO LOG SCHEMA
// ============================================================================
exports.PhotoLogSchema = new mongoose_1.Schema({
    farmerId: { type: String, required: true, index: true },
    imageUrl: { type: String, required: true },
    category: {
        type: String,
        required: true,
        enum: ['TILLING', 'SOWING', 'SPRAYING', 'FERTIGATION', 'HARVEST', 'OTHER'],
        index: true
    },
    location: {
        lat: { type: Number, required: true },
        lng: { type: Number, required: true }
    },
    timestamp: { type: Date, required: true, default: Date.now, index: true },
    notes: { type: String },
    transactionId: { type: String, index: true }
}, {
    timestamps: true,
    collection: 'photo_logs'
});
// Indexes
exports.PhotoLogSchema.index({ farmerId: 1, timestamp: -1 });
exports.PhotoLogSchema.index({ category: 1, timestamp: -1 });
// ============================================================================
// QUALITY CERTIFICATE SCHEMA
// ============================================================================
exports.QualityCertificateSchema = new mongoose_1.Schema({
    certificateId: { type: String, required: true, unique: true, index: true },
    farmerId: { type: String, required: true, index: true },
    produceType: { type: String, required: true, index: true },
    grade: {
        type: String,
        required: true,
        enum: ['A', 'B', 'C']
    },
    timestamp: { type: Date, required: true, default: Date.now },
    location: {
        lat: { type: Number, required: true },
        lng: { type: Number, required: true }
    },
    imageHash: { type: String, required: true },
    analysisDetails: {
        size: { type: Number },
        shape: { type: Number },
        color: { type: Number },
        defects: { type: Number },
        confidence: { type: Number, required: true }
    }
}, {
    timestamps: true,
    collection: 'quality_certificates'
});
// Indexes
exports.QualityCertificateSchema.index({ farmerId: 1, timestamp: -1 });
exports.QualityCertificateSchema.index({ produceType: 1, grade: 1 });
// ============================================================================
// PRICE PREDICTION SCHEMA
// ============================================================================
exports.PricePredictionSchema = new mongoose_1.Schema({
    produceType: { type: String, required: true, index: true },
    location: { type: String, required: true, index: true },
    predictions: [{
            date: { type: Date, required: true },
            predictedPrice: { type: Number, required: true },
            confidenceInterval: {
                lower: { type: Number, required: true },
                upper: { type: Number, required: true }
            }
        }],
    confidence: { type: Number, required: true },
    generatedAt: { type: Date, required: true, default: Date.now, index: true }
}, {
    timestamps: true,
    collection: 'price_predictions'
});
// Indexes
exports.PricePredictionSchema.index({ produceType: 1, location: 1, generatedAt: -1 });
// ============================================================================
// VOICE QUERY SCHEMA
// ============================================================================
exports.VoiceQuerySchema = new mongoose_1.Schema({
    userId: { type: String, required: true, index: true },
    query: { type: String, required: true },
    response: { type: String, required: true },
    confidence: { type: Number, required: true },
    timestamp: { type: Date, required: true, default: Date.now, index: true },
    language: { type: String, default: 'en' },
    queryType: {
        type: String,
        enum: ['PRICE', 'WEATHER', 'BEST_PRACTICE', 'PLATFORM_HELP', 'OTHER']
    }
}, {
    timestamps: true,
    collection: 'voice_queries'
});
// Indexes
exports.VoiceQuerySchema.index({ userId: 1, timestamp: -1 });
// ============================================================================
// FEEDBACK COMMENTS SCHEMA
// ============================================================================
exports.FeedbackCommentSchema = new mongoose_1.Schema({
    transactionId: { type: String, required: true, index: true },
    fromUserId: { type: String, required: true, index: true },
    toUserId: { type: String, required: true, index: true },
    rating: { type: Number, required: true, min: 0, max: 5 },
    comment: { type: String },
    response: { type: String },
    timestamp: { type: Date, required: true, default: Date.now, index: true }
}, {
    timestamps: true,
    collection: 'feedback_comments'
});
// Indexes
exports.FeedbackCommentSchema.index({ toUserId: 1, timestamp: -1 });
// ============================================================================
// DISEASE DIAGNOSIS SCHEMA
// ============================================================================
exports.DiseaseDiagnosisSchema = new mongoose_1.Schema({
    farmerId: { type: String, required: true, index: true },
    imageUrl: { type: String, required: true },
    diseaseName: { type: String, required: true },
    severity: {
        type: String,
        required: true,
        enum: ['LOW', 'MEDIUM', 'HIGH']
    },
    confidence: { type: Number, required: true },
    treatments: [{
            name: { type: String, required: true },
            type: { type: String, enum: ['CHEMICAL', 'ORGANIC'], required: true },
            dosage: { type: String, required: true },
            applicationMethod: { type: String, required: true }
        }],
    timestamp: { type: Date, required: true, default: Date.now, index: true },
    photoLogId: { type: String }
}, {
    timestamps: true,
    collection: 'disease_diagnoses'
});
// Indexes
exports.DiseaseDiagnosisSchema.index({ farmerId: 1, timestamp: -1 });
exports.DiseaseDiagnosisSchema.index({ diseaseName: 1 });
// ============================================================================
// SOIL TEST REPORT SCHEMA
// ============================================================================
exports.SoilTestReportSchema = new mongoose_1.Schema({
    farmerId: { type: String, required: true, index: true },
    testDate: { type: Date, required: true },
    labName: { type: String, required: true },
    parameters: {
        pH: { type: Number, required: true },
        nitrogen: { type: Number, required: true },
        phosphorus: { type: Number, required: true },
        potassium: { type: Number, required: true },
        organicCarbon: { type: Number, required: true },
        electricalConductivity: { type: Number, required: true },
        micronutrients: {
            zinc: { type: Number },
            iron: { type: Number },
            copper: { type: Number },
            manganese: { type: Number }
        }
    },
    recommendations: [{ type: String }],
    createdAt: { type: Date, default: Date.now, index: true }
}, {
    timestamps: true,
    collection: 'soil_test_reports'
});
// Indexes
exports.SoilTestReportSchema.index({ farmerId: 1, testDate: -1 });
// ============================================================================
// SMART ALERT SCHEMA
// ============================================================================
exports.SmartAlertSchema = new mongoose_1.Schema({
    userId: { type: String, required: true, index: true },
    type: {
        type: String,
        required: true,
        enum: ['WEATHER', 'PEST', 'PRICE', 'POWER_CUT', 'HARVEST', 'SCHEME'],
        index: true
    },
    title: { type: String, required: true },
    message: { type: String, required: true },
    actionable: { type: String, required: true },
    priority: {
        type: String,
        required: true,
        enum: ['LOW', 'MEDIUM', 'HIGH', 'URGENT'],
        index: true
    },
    channels: [{
            type: String,
            enum: ['PUSH', 'SMS', 'VOICE']
        }],
    sentAt: { type: Date, required: true, default: Date.now, index: true },
    readAt: { type: Date }
}, {
    timestamps: true,
    collection: 'smart_alerts'
});
// Indexes
exports.SmartAlertSchema.index({ userId: 1, sentAt: -1 });
exports.SmartAlertSchema.index({ type: 1, priority: 1 });
// ============================================================================
// TRACEABILITY RECORD SCHEMA
// ============================================================================
exports.TraceabilityRecordSchema = new mongoose_1.Schema({
    produceId: { type: String, required: true, unique: true, index: true },
    farmerId: { type: String, required: true, index: true },
    seedSource: { type: String, required: true },
    plantingDate: { type: Date, required: true },
    activities: [{
            type: {
                type: String,
                enum: ['PLANTING', 'FERTILIZER', 'PESTICIDE', 'IRRIGATION', 'HARVEST', 'TRANSPORT'],
                required: true
            },
            description: { type: String, required: true },
            timestamp: { type: Date, required: true },
            photoLogId: { type: String }
        }],
    certificateId: { type: String, required: true },
    transactionId: { type: String },
    qrCode: { type: String },
    createdAt: { type: Date, default: Date.now, index: true }
}, {
    timestamps: true,
    collection: 'traceability_records'
});
// Indexes
exports.TraceabilityRecordSchema.index({ farmerId: 1, createdAt: -1 });
exports.TraceabilityRecordSchema.index({ certificateId: 1 });
// ============================================================================
// AD LISTING SCHEMA
// ============================================================================
exports.AdListingSchema = new mongoose_1.Schema({
    userId: { type: String, required: true, index: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    category: { type: String, required: true, index: true },
    price: { type: Number, required: true },
    images: [{ type: String }],
    voiceTranscript: { type: String },
    isActive: { type: Boolean, default: true, index: true },
    createdAt: { type: Date, default: Date.now, index: true }
}, {
    timestamps: true,
    collection: 'ad_listings'
});
// Indexes
exports.AdListingSchema.index({ userId: 1, createdAt: -1 });
exports.AdListingSchema.index({ category: 1, isActive: 1 });
// ============================================================================
// FARMING TIPS SCHEMA
// ============================================================================
exports.FarmingTipSchema = new mongoose_1.Schema({
    crop: { type: String, required: true, index: true },
    topic: {
        type: String,
        required: true,
        enum: ['planting', 'irrigation', 'pest-control', 'harvesting'],
        index: true
    },
    advice: { type: String, required: true },
    tips: [{ type: String }],
    season: { type: String },
    region: { type: String },
    language: { type: String, required: true, default: 'en', index: true },
    references: [{ type: String }],
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
}, {
    timestamps: true,
    collection: 'farming_tips'
});
// Indexes
exports.FarmingTipSchema.index({ crop: 1, topic: 1, language: 1 });
//# sourceMappingURL=mongodb-schemas.js.map