/**
 * Database Migration Runner
 * Executes the schema consolidation migration
 */
export {};
//# sourceMappingURL=run-migration.d.ts.map