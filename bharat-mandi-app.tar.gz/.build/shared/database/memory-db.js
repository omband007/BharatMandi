"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.db = void 0;
class MemoryDatabase {
    constructor() {
        this.users = new Map();
        this.certificates = new Map();
        this.listings = new Map();
        this.transactions = new Map();
        this.escrowAccounts = new Map();
    }
    // User operations
    createUser(user) {
        this.users.set(user.id, user);
        return user;
    }
    getUser(id) {
        return this.users.get(id);
    }
    getAllUsers() {
        return Array.from(this.users.values());
    }
    // Certificate operations
    createCertificate(certificate) {
        this.certificates.set(certificate.id, certificate);
        return certificate;
    }
    getCertificate(id) {
        return this.certificates.get(id);
    }
    // Listing operations
    createListing(listing) {
        this.listings.set(listing.id, listing);
        return listing;
    }
    getListing(id) {
        return this.listings.get(id);
    }
    getActiveListings() {
        return Array.from(this.listings.values()).filter(l => l.status === 'ACTIVE');
    }
    updateListing(id, updates) {
        const listing = this.listings.get(id);
        if (!listing)
            return undefined;
        const updated = { ...listing, ...updates };
        this.listings.set(id, updated);
        return updated;
    }
    // Transaction operations
    createTransaction(transaction) {
        this.transactions.set(transaction.id, transaction);
        return transaction;
    }
    getTransaction(id) {
        return this.transactions.get(id);
    }
    updateTransaction(id, updates) {
        const transaction = this.transactions.get(id);
        if (!transaction)
            return undefined;
        const updated = { ...transaction, ...updates, updatedAt: new Date() };
        this.transactions.set(id, updated);
        return updated;
    }
    // Escrow operations
    createEscrow(escrow) {
        this.escrowAccounts.set(escrow.id, escrow);
        return escrow;
    }
    getEscrow(id) {
        return this.escrowAccounts.get(id);
    }
    getEscrowByTransaction(transactionId) {
        return Array.from(this.escrowAccounts.values())
            .find(e => e.transactionId === transactionId);
    }
    updateEscrow(id, updates) {
        const escrow = this.escrowAccounts.get(id);
        if (!escrow)
            return undefined;
        const updated = { ...escrow, ...updates };
        this.escrowAccounts.set(id, updated);
        return updated;
    }
    // Utility
    clear() {
        this.users.clear();
        this.certificates.clear();
        this.listings.clear();
        this.transactions.clear();
        this.escrowAccounts.clear();
    }
}
exports.db = new MemoryDatabase();
//# sourceMappingURL=memory-db.js.map