/**
 * Clean Database and Run Migration
 * Clears test data and executes schema consolidation
 */
export {};
//# sourceMappingURL=clean-and-migrate.d.ts.map