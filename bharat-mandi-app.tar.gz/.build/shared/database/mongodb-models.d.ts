import { Model, Document } from 'mongoose';
import { PhotoLogEntry, DigitalQualityCertificate, PricePrediction, VoiceQuery, DiseaseDiagnosis, SoilTestReport, SmartAlert, TraceabilityRecord, AdListing } from '../../types';
export interface PhotoLogDocument extends Omit<PhotoLogEntry, 'id'>, Document {
}
export interface QualityCertificateDocument extends Omit<DigitalQualityCertificate, 'id'>, Document {
}
export interface PricePredictionDocument extends Omit<PricePrediction, 'id'>, Document {
}
export interface VoiceQueryDocument extends Omit<VoiceQuery, 'id'>, Document {
}
export interface DiseaseDiagnosisDocument extends Omit<DiseaseDiagnosis, 'id'>, Document {
}
export interface SoilTestReportDocument extends Omit<SoilTestReport, 'id'>, Document {
}
export interface SmartAlertDocument extends Omit<SmartAlert, 'id'>, Document {
}
export interface TraceabilityRecordDocument extends Omit<TraceabilityRecord, 'id'>, Document {
}
export interface AdListingDocument extends Omit<AdListing, 'id'>, Document {
}
export interface FeedbackComment {
    transactionId: string;
    fromUserId: string;
    toUserId: string;
    rating: number;
    comment?: string;
    response?: string;
    timestamp: Date;
}
export interface FeedbackCommentDocument extends FeedbackComment, Document {
}
export interface FarmingTip {
    crop: string;
    topic: 'planting' | 'irrigation' | 'pest-control' | 'harvesting';
    advice: string;
    tips: string[];
    season?: string;
    region?: string;
    language: string;
    references: string[];
    createdAt: Date;
    updatedAt: Date;
}
export interface FarmingTipDocument extends FarmingTip, Document {
}
export declare const PhotoLogModel: Model<PhotoLogDocument>;
export declare const QualityCertificateModel: Model<QualityCertificateDocument>;
export declare const PricePredictionModel: Model<PricePredictionDocument>;
export declare const VoiceQueryModel: Model<VoiceQueryDocument>;
export declare const FeedbackCommentModel: Model<FeedbackCommentDocument>;
export declare const DiseaseDiagnosisModel: Model<DiseaseDiagnosisDocument>;
export declare const SoilTestReportModel: Model<SoilTestReportDocument>;
export declare const SmartAlertModel: Model<SmartAlertDocument>;
export declare const TraceabilityRecordModel: Model<TraceabilityRecordDocument>;
export declare const AdListingModel: Model<AdListingDocument>;
export declare const FarmingTipModel: Model<FarmingTipDocument>;
export declare function createIndexes(): Promise<void>;
export declare function dropAllCollections(): Promise<void>;
export declare function getCollectionStats(): Promise<any>;
import mongoose from 'mongoose';
export { mongoose };
//# sourceMappingURL=mongodb-models.d.ts.map