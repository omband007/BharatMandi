export declare function setupSQLite(): Promise<void>;
//# sourceMappingURL=sqlite-setup.d.ts.map