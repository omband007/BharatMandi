import type { OTPSession } from '../../features/profile/types/profile.types';
import type { User } from './db-abstraction';
import type { Listing } from '../../features/marketplace/marketplace.types';
import type { ListingMedia } from '../../features/marketplace/media.types';
import type { Transaction, EscrowAccount } from '../../features/transactions/transaction.types';
import type { Notification, NotificationTemplate, NotificationType, TranslationFeedback, TranslationFeedbackStats } from '../../features/notifications/notification.types';
import type { DatabaseAdapter } from './db-abstraction';
/**
 * PostgreSQL Adapter for Bharat Mandi Application
 * Implements database operations for PostgreSQL as the primary database
 */
export declare class PostgreSQLAdapter implements DatabaseAdapter {
    /**
     * Create a new user in PostgreSQL
     * @param user - User object to create
     * @param pinHash - Optional hashed PIN for the user
     * @returns Created user object
     */
    createUser(user: User, pinHash?: string): Promise<User>;
    /**
     * Get user by ID
     * @param id - User ID
     * @returns User object or undefined if not found
     */
    getUserById(id: string): Promise<User | undefined>;
    /**
     * Get user by phone number
     * @param phoneNumber - User's phone number
     * @returns User object or undefined if not found
     */
    getUserByPhone(phoneNumber: string): Promise<User | undefined>;
    /**
     * Update user information
     * @param userId - User ID to update
     * @param updates - Partial user object with fields to update
     * @returns Updated user object or undefined if not found
     */
    updateUser(userId: string, updates: Partial<User>): Promise<User | undefined>;
    /**
     * Get all users
     * @returns Array of all users
     */
    getAllUsers(): Promise<User[]>;
    /**
     * Get user's PIN hash
     * @param phoneNumber - User's phone number
     * @returns PIN hash or undefined if not found
     */
    getUserPinHash(phoneNumber: string): Promise<string | undefined>;
    /**
     * Update user's PIN
     * @param phoneNumber - User's phone number
     * @param pinHash - New hashed PIN
     */
    updateUserPin(phoneNumber: string, pinHash: string): Promise<void>;
    /**
     * Get failed login attempts for a user
     * @param phoneNumber - User's phone number
     * @returns Object with failed_attempts and locked_until or undefined
     */
    getFailedAttempts(phoneNumber: string): Promise<{
        failed_attempts: number;
        locked_until?: string;
    } | undefined>;
    /**
     * Increment failed login attempts
     * @param phoneNumber - User's phone number
     */
    incrementFailedAttempts(phoneNumber: string): Promise<void>;
    /**
     * Reset failed login attempts
     * @param phoneNumber - User's phone number
     */
    resetFailedAttempts(phoneNumber: string): Promise<void>;
    /**
     * Lock user account until specified time
     * @param phoneNumber - User's phone number
     * @param lockUntil - Date until which account should be locked
     */
    lockAccount(phoneNumber: string, lockUntil: Date): Promise<void>;
    /**
     * Create OTP session
     * @param session - OTP session object
     */
    createOTPSession(session: OTPSession): Promise<void>;
    /**
     * Get OTP session for a phone number
     * @param phoneNumber - User's phone number
     * @returns OTP session or undefined if not found
     */
    getOTPSession(phoneNumber: string): Promise<OTPSession | undefined>;
    /**
     * Update OTP attempts
     * @param phoneNumber - User's phone number
     * @param attempts - New attempts count
     */
    updateOTPAttempts(phoneNumber: string, attempts: number): Promise<void>;
    /**
     * Delete OTP session
     * @param phoneNumber - User's phone number
     */
    deleteOTPSession(phoneNumber: string): Promise<void>;
    /**
     * Check PostgreSQL connection health
     * @returns true if connection is healthy, false otherwise
     */
    checkConnection(): Promise<boolean>;
    /**
     * Helper method to map PostgreSQL row to User object
     * @param row - Database row
     * @returns User object
     */
    private mapRowToUser;
    createListing(listing: Listing): Promise<Listing>;
    getListing(id: string): Promise<Listing | undefined>;
    getActiveListings(): Promise<Listing[]>;
    updateListing(id: string, updates: Partial<Listing>): Promise<Listing | undefined>;
    private mapRowToListing;
    createTransaction(transaction: Transaction): Promise<Transaction>;
    getTransaction(id: string): Promise<Transaction | undefined>;
    updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction | undefined>;
    private mapRowToTransaction;
    createEscrow(escrow: EscrowAccount): Promise<EscrowAccount>;
    getEscrow(id: string): Promise<EscrowAccount | undefined>;
    getEscrowByTransaction(transactionId: string): Promise<EscrowAccount | undefined>;
    updateEscrow(id: string, updates: Partial<EscrowAccount>): Promise<EscrowAccount | undefined>;
    private mapRowToEscrow;
    createListingMedia(media: Omit<ListingMedia, 'id' | 'createdAt' | 'updatedAt'>): Promise<ListingMedia>;
    getListingMedia(listingId: string): Promise<ListingMedia[]>;
    getMediaById(mediaId: string): Promise<ListingMedia | null>;
    deleteListingMedia(mediaId: string): Promise<boolean>;
    updateMediaOrder(listingId: string, mediaOrder: {
        mediaId: string;
        displayOrder: number;
    }[]): Promise<boolean>;
    setPrimaryMedia(listingId: string, mediaId: string): Promise<boolean>;
    getMediaCount(listingId: string): Promise<number>;
    createNotification(notification: Notification): Promise<Notification>;
    getNotification(id: string): Promise<Notification | undefined>;
    getUserNotifications(userId: string): Promise<Notification[]>;
    updateNotification(id: string, updates: Partial<Notification>): Promise<Notification | undefined>;
    getNotificationTemplate(type: NotificationType, language: string): Promise<NotificationTemplate | undefined>;
    private mapRowToNotification;
    private mapRowToNotificationTemplate;
    /**
     * Execute raw SQL query (for development/admin operations)
     * @param sql - SQL query string
     * @param params - Query parameters
     * @returns Query result
     */
    query(sql: string, params?: any[]): Promise<any>;
    private mapRowToListingMedia;
    /**
     * Create translation feedback
     * @param feedback - Translation feedback object to create
     * @returns Created translation feedback object
     */
    createTranslationFeedback(feedback: Omit<TranslationFeedback, 'id' | 'createdAt' | 'updatedAt'>): Promise<TranslationFeedback>;
    /**
     * Get translation feedback by ID
     * @param id - Feedback ID
     * @returns Translation feedback object or undefined if not found
     */
    getTranslationFeedback(id: string): Promise<TranslationFeedback | undefined>;
    /**
     * Get translation feedback statistics
     * @param targetLanguage - Optional language filter
     * @returns Translation feedback statistics
     */
    getTranslationFeedbackStats(targetLanguage?: string): Promise<TranslationFeedbackStats>;
    /**
     * Update translation feedback
     * @param id - Feedback ID to update
     * @param updates - Partial feedback object with fields to update
     * @returns Updated feedback object or undefined if not found
     */
    updateTranslationFeedback(id: string, updates: Partial<TranslationFeedback>): Promise<TranslationFeedback | undefined>;
    private mapRowToTranslationFeedback;
    /**
     * Execute a SQL query and return the first row
     * Converts SQLite-style ? placeholders to PostgreSQL-style $1, $2, etc.
     * @param sql - SQL query to execute
     * @param params - Parameters for the SQL query
     * @returns First row or undefined
     */
    get(sql: string, params?: any[]): Promise<any>;
    /**
     * Execute a SQL query and return all rows
     * Converts SQLite-style ? placeholders to PostgreSQL-style $1, $2, etc.
     * @param sql - SQL query to execute
     * @param params - Parameters for the SQL query
     * @returns Array of rows
     */
    all(sql: string, params?: any[]): Promise<any[]>;
    /**
     * Execute a SQL statement (INSERT, UPDATE, DELETE)
     * Converts SQLite-style ? placeholders to PostgreSQL-style $1, $2, etc.
     * @param sql - SQL statement to execute
     * @param params - Parameters for the SQL statement
     */
    run(sql: string, params?: any[]): Promise<void>;
}
//# sourceMappingURL=pg-adapter.d.ts.map