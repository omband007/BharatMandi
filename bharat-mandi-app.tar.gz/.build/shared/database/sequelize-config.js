"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.sequelize = void 0;
exports.testSequelizeConnection = testSequelizeConnection;
exports.syncDatabase = syncDatabase;
exports.closeSequelizeConnection = closeSequelizeConnection;
const sequelize_1 = require("sequelize");
const dotenv = __importStar(require("dotenv"));
// Load environment variables
dotenv.config();
// PostgreSQL connection configuration
const sequelize = new sequelize_1.Sequelize({
    dialect: 'postgres',
    host: process.env.POSTGRES_HOST || 'localhost',
    port: parseInt(process.env.POSTGRES_PORT || '5432'),
    database: process.env.POSTGRES_DB || 'bharat_mandi',
    username: process.env.POSTGRES_USER || 'postgres',
    password: process.env.POSTGRES_PASSWORD || '',
    logging: false, // Disable SQL query logging
    dialectOptions: {
        ssl: process.env.DB_SSL === 'true' ? {
            require: true,
            rejectUnauthorized: false // For AWS RDS
        } : false
    },
    pool: {
        max: 10,
        min: 2,
        acquire: 30000,
        idle: 10000
    },
    define: {
        timestamps: true,
        underscored: true,
        createdAt: 'created_at',
        updatedAt: 'updated_at'
    }
});
exports.sequelize = sequelize;
// Test connection
async function testSequelizeConnection() {
    try {
        await sequelize.authenticate();
        console.log('✓ Sequelize PostgreSQL connection established');
        return true;
    }
    catch (error) {
        console.error('✗ Sequelize PostgreSQL connection failed:', error);
        return false;
    }
}
// Sync database (create tables if they don't exist)
async function syncDatabase(force = false) {
    try {
        await sequelize.sync({ force, alter: !force });
        console.log(`✓ Database synced ${force ? '(force)' : '(alter)'}`);
    }
    catch (error) {
        console.error('✗ Database sync failed:', error);
        throw error;
    }
}
// Close connection
async function closeSequelizeConnection() {
    try {
        await sequelize.close();
        console.log('✓ Sequelize connection closed');
    }
    catch (error) {
        console.error('✗ Error closing Sequelize connection:', error);
    }
}
exports.default = sequelize;
//# sourceMappingURL=sequelize-config.js.map