import { Database } from 'sqlite';
declare const DB_PATH: string;
export declare function openSQLiteDB(): Promise<Database>;
export declare function closeSQLiteDB(): Promise<void>;
export declare function getSQLiteDB(): Database;
export declare function initializeSQLiteSchema(): Promise<void>;
export declare function testSQLiteConnection(): Promise<boolean>;
export declare function getSQLiteStats(): Promise<any>;
export declare function clearAllCachedData(): Promise<void>;
export declare function vacuumDatabase(): Promise<void>;
export declare function getDatabaseSize(): number;
export { DB_PATH };
//# sourceMappingURL=sqlite-config.d.ts.map