"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mongoose = void 0;
exports.connectMongoDB = connectMongoDB;
exports.disconnectMongoDB = disconnectMongoDB;
exports.testMongoConnection = testMongoConnection;
exports.getConnectionStatus = getConnectionStatus;
const mongoose_1 = __importDefault(require("mongoose"));
exports.mongoose = mongoose_1.default;
const dotenv = __importStar(require("dotenv"));
// Load environment variables
dotenv.config();
// MongoDB connection URI
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/bharat_mandi';
// Connection options
const options = {
    maxPoolSize: 10,
    minPoolSize: 5,
    socketTimeoutMS: 45000,
    serverSelectionTimeoutMS: 5000,
};
// Connect to MongoDB
async function connectMongoDB() {
    try {
        await mongoose_1.default.connect(MONGODB_URI, options);
        console.log('✓ MongoDB connected successfully');
        // Handle connection events
        mongoose_1.default.connection.on('error', (error) => {
            console.error('MongoDB connection error:', error);
        });
        mongoose_1.default.connection.on('disconnected', () => {
            console.log('MongoDB disconnected');
        });
        mongoose_1.default.connection.on('reconnected', () => {
            console.log('MongoDB reconnected');
        });
    }
    catch (error) {
        console.error('✗ MongoDB connection failed:', error);
        throw error;
    }
}
// Disconnect from MongoDB
async function disconnectMongoDB() {
    try {
        await mongoose_1.default.disconnect();
        console.log('MongoDB disconnected successfully');
    }
    catch (error) {
        console.error('MongoDB disconnect error:', error);
        throw error;
    }
}
// Test MongoDB connection
async function testMongoConnection() {
    try {
        await connectMongoDB();
        if (!mongoose_1.default.connection.db) {
            throw new Error('Database connection not established');
        }
        const adminDb = mongoose_1.default.connection.db.admin();
        const result = await adminDb.ping();
        console.log('✓ MongoDB ping successful:', result);
        return true;
    }
    catch (error) {
        console.error('✗ MongoDB connection test failed:', error);
        return false;
    }
}
// Get MongoDB connection status
function getConnectionStatus() {
    const states = ['disconnected', 'connected', 'connecting', 'disconnecting'];
    return states[mongoose_1.default.connection.readyState] || 'unknown';
}
//# sourceMappingURL=mongodb-config.js.map