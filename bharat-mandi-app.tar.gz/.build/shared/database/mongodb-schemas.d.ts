import { Schema } from 'mongoose';
export declare const PhotoLogSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    farmerId: string;
    imageUrl: string;
    category: "TILLING" | "SOWING" | "SPRAYING" | "FERTIGATION" | "HARVEST" | "OTHER";
    timestamp: NativeDate;
    location?: {
        lng: number;
        lat: number;
    } | null | undefined;
    transactionId?: string | null | undefined;
    notes?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    farmerId: string;
    imageUrl: string;
    category: "TILLING" | "SOWING" | "SPRAYING" | "FERTIGATION" | "HARVEST" | "OTHER";
    timestamp: NativeDate;
    location?: {
        lng: number;
        lat: number;
    } | null | undefined;
    transactionId?: string | null | undefined;
    notes?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    farmerId: string;
    imageUrl: string;
    category: "TILLING" | "SOWING" | "SPRAYING" | "FERTIGATION" | "HARVEST" | "OTHER";
    timestamp: NativeDate;
    location?: {
        lng: number;
        lat: number;
    } | null | undefined;
    transactionId?: string | null | undefined;
    notes?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const QualityCertificateSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    farmerId: string;
    produceType: string;
    certificateId: string;
    grade: "A" | "B" | "C";
    timestamp: NativeDate;
    imageHash: string;
    location?: {
        lng: number;
        lat: number;
    } | null | undefined;
    analysisDetails?: {
        confidence: number;
        size?: number | null | undefined;
        color?: number | null | undefined;
        defects?: number | null | undefined;
        shape?: number | null | undefined;
    } | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    farmerId: string;
    produceType: string;
    certificateId: string;
    grade: "A" | "B" | "C";
    timestamp: NativeDate;
    imageHash: string;
    location?: {
        lng: number;
        lat: number;
    } | null | undefined;
    analysisDetails?: {
        confidence: number;
        size?: number | null | undefined;
        color?: number | null | undefined;
        defects?: number | null | undefined;
        shape?: number | null | undefined;
    } | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    farmerId: string;
    produceType: string;
    certificateId: string;
    grade: "A" | "B" | "C";
    timestamp: NativeDate;
    imageHash: string;
    location?: {
        lng: number;
        lat: number;
    } | null | undefined;
    analysisDetails?: {
        confidence: number;
        size?: number | null | undefined;
        color?: number | null | undefined;
        defects?: number | null | undefined;
        shape?: number | null | undefined;
    } | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const PricePredictionSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    location: string;
    produceType: string;
    confidence: number;
    predictions: import("mongoose").Types.DocumentArray<{
        date: NativeDate;
        predictedPrice: number;
        confidenceInterval?: {
            lower: number;
            upper: number;
        } | null | undefined;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        date: NativeDate;
        predictedPrice: number;
        confidenceInterval?: {
            lower: number;
            upper: number;
        } | null | undefined;
    }> & {
        date: NativeDate;
        predictedPrice: number;
        confidenceInterval?: {
            lower: number;
            upper: number;
        } | null | undefined;
    }>;
    generatedAt: NativeDate;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    location: string;
    produceType: string;
    confidence: number;
    predictions: import("mongoose").Types.DocumentArray<{
        date: NativeDate;
        predictedPrice: number;
        confidenceInterval?: {
            lower: number;
            upper: number;
        } | null | undefined;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        date: NativeDate;
        predictedPrice: number;
        confidenceInterval?: {
            lower: number;
            upper: number;
        } | null | undefined;
    }> & {
        date: NativeDate;
        predictedPrice: number;
        confidenceInterval?: {
            lower: number;
            upper: number;
        } | null | undefined;
    }>;
    generatedAt: NativeDate;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    location: string;
    produceType: string;
    confidence: number;
    predictions: import("mongoose").Types.DocumentArray<{
        date: NativeDate;
        predictedPrice: number;
        confidenceInterval?: {
            lower: number;
            upper: number;
        } | null | undefined;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        date: NativeDate;
        predictedPrice: number;
        confidenceInterval?: {
            lower: number;
            upper: number;
        } | null | undefined;
    }> & {
        date: NativeDate;
        predictedPrice: number;
        confidenceInterval?: {
            lower: number;
            upper: number;
        } | null | undefined;
    }>;
    generatedAt: NativeDate;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const VoiceQuerySchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    userId: string;
    confidence: number;
    query: string;
    language: string;
    timestamp: NativeDate;
    response: string;
    queryType?: "OTHER" | "PRICE" | "WEATHER" | "BEST_PRACTICE" | "PLATFORM_HELP" | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    userId: string;
    confidence: number;
    query: string;
    language: string;
    timestamp: NativeDate;
    response: string;
    queryType?: "OTHER" | "PRICE" | "WEATHER" | "BEST_PRACTICE" | "PLATFORM_HELP" | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    userId: string;
    confidence: number;
    query: string;
    language: string;
    timestamp: NativeDate;
    response: string;
    queryType?: "OTHER" | "PRICE" | "WEATHER" | "BEST_PRACTICE" | "PLATFORM_HELP" | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const FeedbackCommentSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    transactionId: string;
    timestamp: NativeDate;
    fromUserId: string;
    toUserId: string;
    rating: number;
    comment?: string | null | undefined;
    response?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    transactionId: string;
    timestamp: NativeDate;
    fromUserId: string;
    toUserId: string;
    rating: number;
    comment?: string | null | undefined;
    response?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    transactionId: string;
    timestamp: NativeDate;
    fromUserId: string;
    toUserId: string;
    rating: number;
    comment?: string | null | undefined;
    response?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const DiseaseDiagnosisSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    farmerId: string;
    confidence: number;
    imageUrl: string;
    timestamp: NativeDate;
    diseaseName: string;
    severity: "LOW" | "MEDIUM" | "HIGH";
    treatments: import("mongoose").Types.DocumentArray<{
        name: string;
        type: "CHEMICAL" | "ORGANIC";
        dosage: string;
        applicationMethod: string;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        name: string;
        type: "CHEMICAL" | "ORGANIC";
        dosage: string;
        applicationMethod: string;
    }> & {
        name: string;
        type: "CHEMICAL" | "ORGANIC";
        dosage: string;
        applicationMethod: string;
    }>;
    photoLogId?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    farmerId: string;
    confidence: number;
    imageUrl: string;
    timestamp: NativeDate;
    diseaseName: string;
    severity: "LOW" | "MEDIUM" | "HIGH";
    treatments: import("mongoose").Types.DocumentArray<{
        name: string;
        type: "CHEMICAL" | "ORGANIC";
        dosage: string;
        applicationMethod: string;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        name: string;
        type: "CHEMICAL" | "ORGANIC";
        dosage: string;
        applicationMethod: string;
    }> & {
        name: string;
        type: "CHEMICAL" | "ORGANIC";
        dosage: string;
        applicationMethod: string;
    }>;
    photoLogId?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    farmerId: string;
    confidence: number;
    imageUrl: string;
    timestamp: NativeDate;
    diseaseName: string;
    severity: "LOW" | "MEDIUM" | "HIGH";
    treatments: import("mongoose").Types.DocumentArray<{
        name: string;
        type: "CHEMICAL" | "ORGANIC";
        dosage: string;
        applicationMethod: string;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        name: string;
        type: "CHEMICAL" | "ORGANIC";
        dosage: string;
        applicationMethod: string;
    }> & {
        name: string;
        type: "CHEMICAL" | "ORGANIC";
        dosage: string;
        applicationMethod: string;
    }>;
    photoLogId?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const SoilTestReportSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    createdAt: NativeDate;
    farmerId: string;
    testDate: NativeDate;
    labName: string;
    recommendations: string[];
    parameters?: {
        pH: number;
        nitrogen: number;
        phosphorus: number;
        potassium: number;
        organicCarbon: number;
        electricalConductivity: number;
        micronutrients?: {
            zinc?: number | null | undefined;
            iron?: number | null | undefined;
            copper?: number | null | undefined;
            manganese?: number | null | undefined;
        } | null | undefined;
    } | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    farmerId: string;
    testDate: NativeDate;
    labName: string;
    recommendations: string[];
    parameters?: {
        pH: number;
        nitrogen: number;
        phosphorus: number;
        potassium: number;
        organicCarbon: number;
        electricalConductivity: number;
        micronutrients?: {
            zinc?: number | null | undefined;
            iron?: number | null | undefined;
            copper?: number | null | undefined;
            manganese?: number | null | undefined;
        } | null | undefined;
    } | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    farmerId: string;
    testDate: NativeDate;
    labName: string;
    recommendations: string[];
    parameters?: {
        pH: number;
        nitrogen: number;
        phosphorus: number;
        potassium: number;
        organicCarbon: number;
        electricalConductivity: number;
        micronutrients?: {
            zinc?: number | null | undefined;
            iron?: number | null | undefined;
            copper?: number | null | undefined;
            manganese?: number | null | undefined;
        } | null | undefined;
    } | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const SmartAlertSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    userId: string;
    type: "HARVEST" | "PRICE" | "WEATHER" | "PEST" | "POWER_CUT" | "SCHEME";
    title: string;
    message: string;
    channels: ("PUSH" | "SMS" | "VOICE")[];
    actionable: string;
    priority: "LOW" | "MEDIUM" | "HIGH" | "URGENT";
    sentAt: NativeDate;
    readAt?: NativeDate | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    userId: string;
    type: "HARVEST" | "PRICE" | "WEATHER" | "PEST" | "POWER_CUT" | "SCHEME";
    title: string;
    message: string;
    channels: ("PUSH" | "SMS" | "VOICE")[];
    actionable: string;
    priority: "LOW" | "MEDIUM" | "HIGH" | "URGENT";
    sentAt: NativeDate;
    readAt?: NativeDate | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    userId: string;
    type: "HARVEST" | "PRICE" | "WEATHER" | "PEST" | "POWER_CUT" | "SCHEME";
    title: string;
    message: string;
    channels: ("PUSH" | "SMS" | "VOICE")[];
    actionable: string;
    priority: "LOW" | "MEDIUM" | "HIGH" | "URGENT";
    sentAt: NativeDate;
    readAt?: NativeDate | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const TraceabilityRecordSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    createdAt: NativeDate;
    farmerId: string;
    certificateId: string;
    produceId: string;
    seedSource: string;
    plantingDate: NativeDate;
    activities: import("mongoose").Types.DocumentArray<{
        type: "HARVEST" | "PLANTING" | "FERTILIZER" | "PESTICIDE" | "IRRIGATION" | "TRANSPORT";
        description: string;
        timestamp: NativeDate;
        photoLogId?: string | null | undefined;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        type: "HARVEST" | "PLANTING" | "FERTILIZER" | "PESTICIDE" | "IRRIGATION" | "TRANSPORT";
        description: string;
        timestamp: NativeDate;
        photoLogId?: string | null | undefined;
    }> & {
        type: "HARVEST" | "PLANTING" | "FERTILIZER" | "PESTICIDE" | "IRRIGATION" | "TRANSPORT";
        description: string;
        timestamp: NativeDate;
        photoLogId?: string | null | undefined;
    }>;
    transactionId?: string | null | undefined;
    qrCode?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    farmerId: string;
    certificateId: string;
    produceId: string;
    seedSource: string;
    plantingDate: NativeDate;
    activities: import("mongoose").Types.DocumentArray<{
        type: "HARVEST" | "PLANTING" | "FERTILIZER" | "PESTICIDE" | "IRRIGATION" | "TRANSPORT";
        description: string;
        timestamp: NativeDate;
        photoLogId?: string | null | undefined;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        type: "HARVEST" | "PLANTING" | "FERTILIZER" | "PESTICIDE" | "IRRIGATION" | "TRANSPORT";
        description: string;
        timestamp: NativeDate;
        photoLogId?: string | null | undefined;
    }> & {
        type: "HARVEST" | "PLANTING" | "FERTILIZER" | "PESTICIDE" | "IRRIGATION" | "TRANSPORT";
        description: string;
        timestamp: NativeDate;
        photoLogId?: string | null | undefined;
    }>;
    transactionId?: string | null | undefined;
    qrCode?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    farmerId: string;
    certificateId: string;
    produceId: string;
    seedSource: string;
    plantingDate: NativeDate;
    activities: import("mongoose").Types.DocumentArray<{
        type: "HARVEST" | "PLANTING" | "FERTILIZER" | "PESTICIDE" | "IRRIGATION" | "TRANSPORT";
        description: string;
        timestamp: NativeDate;
        photoLogId?: string | null | undefined;
    }, import("mongoose").Types.Subdocument<import("bson").ObjectId, any, {
        type: "HARVEST" | "PLANTING" | "FERTILIZER" | "PESTICIDE" | "IRRIGATION" | "TRANSPORT";
        description: string;
        timestamp: NativeDate;
        photoLogId?: string | null | undefined;
    }> & {
        type: "HARVEST" | "PLANTING" | "FERTILIZER" | "PESTICIDE" | "IRRIGATION" | "TRANSPORT";
        description: string;
        timestamp: NativeDate;
        photoLogId?: string | null | undefined;
    }>;
    transactionId?: string | null | undefined;
    qrCode?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const AdListingSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    createdAt: NativeDate;
    userId: string;
    title: string;
    description: string;
    price: number;
    category: string;
    images: string[];
    isActive: boolean;
    voiceTranscript?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    userId: string;
    title: string;
    description: string;
    price: number;
    category: string;
    images: string[];
    isActive: boolean;
    voiceTranscript?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    userId: string;
    title: string;
    description: string;
    price: number;
    category: string;
    images: string[];
    isActive: boolean;
    voiceTranscript?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const FarmingTipSchema: Schema<any, import("mongoose").Model<any, any, any, any, any, any>, {}, {}, {}, {}, {
    timestamps: true;
    collection: string;
}, {
    createdAt: NativeDate;
    updatedAt: NativeDate;
    crop: string;
    language: string;
    topic: "planting" | "irrigation" | "pest-control" | "harvesting";
    advice: string;
    tips: string[];
    references: string[];
    region?: string | null | undefined;
    season?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    updatedAt: NativeDate;
    crop: string;
    language: string;
    topic: "planting" | "irrigation" | "pest-control" | "harvesting";
    advice: string;
    tips: string[];
    references: string[];
    region?: string | null | undefined;
    season?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps>, {}, import("mongoose").MergeType<import("mongoose").DefaultSchemaOptions, {
    timestamps: true;
    collection: string;
}>> & import("mongoose").FlatRecord<{
    createdAt: NativeDate;
    updatedAt: NativeDate;
    crop: string;
    language: string;
    topic: "planting" | "irrigation" | "pest-control" | "harvesting";
    advice: string;
    tips: string[];
    references: string[];
    region?: string | null | undefined;
    season?: string | null | undefined;
} & import("mongoose").DefaultTimestampProps> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
//# sourceMappingURL=mongodb-schemas.d.ts.map