"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOTPSession = createOTPSession;
exports.getOTPSession = getOTPSession;
exports.updateOTPAttempts = updateOTPAttempts;
exports.deleteOTPSession = deleteOTPSession;
exports.cleanupExpiredOTPSessions = cleanupExpiredOTPSessions;
exports.addToSyncQueue = addToSyncQueue;
exports.getPendingSyncItems = getPendingSyncItems;
exports.removeSyncQueueItem = removeSyncQueueItem;
exports.updateSyncQueueRetry = updateSyncQueueRetry;
exports.cacheListing = cacheListing;
exports.getCachedListings = getCachedListings;
exports.saveLocalPhotoLog = saveLocalPhotoLog;
exports.getUnsyncedPhotoLogs = getUnsyncedPhotoLogs;
exports.markPhotoLogAsSynced = markPhotoLogAsSynced;
exports.cacheUserProfile = cacheUserProfile;
exports.getCachedUserProfile = getCachedUserProfile;
exports.logOfflineActivity = logOfflineActivity;
exports.getPendingOfflineActivities = getPendingOfflineActivities;
exports.updateOfflineActivityStatus = updateOfflineActivityStatus;
exports.getAppSetting = getAppSetting;
exports.setAppSetting = setAppSetting;
exports.isOfflineMode = isOfflineMode;
exports.setOfflineMode = setOfflineMode;
exports.updateSyncStatus = updateSyncStatus;
exports.getSyncStatus = getSyncStatus;
exports.getAllSyncStatuses = getAllSyncStatuses;
exports.createListing = createListing;
exports.getListing = getListing;
exports.getActiveListings = getActiveListings;
exports.updateListing = updateListing;
exports.createTransaction = createTransaction;
exports.getTransaction = getTransaction;
exports.updateTransaction = updateTransaction;
exports.createEscrow = createEscrow;
exports.getEscrow = getEscrow;
exports.getEscrowByTransaction = getEscrowByTransaction;
exports.updateEscrow = updateEscrow;
const sqlite_config_1 = require("./sqlite-config");
// ============================================================================
// OTP SESSION OPERATIONS
// ============================================================================
async function createOTPSession(session) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    // Delete any existing OTP sessions for this phone number
    await db.run('DELETE FROM otp_sessions WHERE phone_number = ?', [session.phoneNumber]);
    // Create new session
    await db.run(`INSERT INTO otp_sessions (phone_number, otp, expires_at, attempts)
     VALUES (?, ?, ?, ?)`, [session.phoneNumber, session.otp, session.expiresAt.toISOString(), session.attempts]);
}
async function getOTPSession(phoneNumber) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const row = await db.get('SELECT * FROM otp_sessions WHERE phone_number = ? ORDER BY created_at DESC LIMIT 1', [phoneNumber]);
    if (!row)
        return undefined;
    return {
        phoneNumber: row.phone_number,
        otp: row.otp,
        expiresAt: new Date(row.expires_at),
        attempts: row.attempts
    };
}
async function updateOTPAttempts(phoneNumber, attempts) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run('UPDATE otp_sessions SET attempts = ? WHERE phone_number = ?', [attempts, phoneNumber]);
}
async function deleteOTPSession(phoneNumber) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run('DELETE FROM otp_sessions WHERE phone_number = ?', [phoneNumber]);
}
async function cleanupExpiredOTPSessions() {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run('DELETE FROM otp_sessions WHERE expires_at < ?', [new Date().toISOString()]);
}
async function addToSyncQueue(item) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const result = await db.run(`INSERT INTO pending_sync_queue (operation_type, entity_type, entity_id, data)
     VALUES (?, ?, ?, ?)`, [item.operation_type, item.entity_type, item.entity_id, item.data]);
    return result.lastID;
}
async function getPendingSyncItems(limit = 50) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    return await db.all(`SELECT * FROM pending_sync_queue 
     ORDER BY created_at ASC 
     LIMIT ?`, [limit]);
}
async function removeSyncQueueItem(id) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run('DELETE FROM pending_sync_queue WHERE id = ?', [id]);
}
async function updateSyncQueueRetry(id, errorMessage) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`UPDATE pending_sync_queue 
     SET retry_count = retry_count + 1, 
         last_retry_at = CURRENT_TIMESTAMP,
         error_message = ?
     WHERE id = ?`, [errorMessage, id]);
}
async function cacheListing(listing) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`INSERT OR REPLACE INTO cached_listings 
     (id, farmer_id, produce_type, quantity, price_per_kg, certificate_id, expected_harvest_date, is_active)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, [
        listing.id,
        listing.farmer_id,
        listing.produce_type,
        listing.quantity,
        listing.price_per_kg,
        listing.certificate_id,
        listing.expected_harvest_date,
        listing.is_active
    ]);
}
async function getCachedListings(filters) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    let query = 'SELECT * FROM cached_listings WHERE 1=1';
    const params = [];
    if (filters?.produce_type) {
        query += ' AND produce_type = ?';
        params.push(filters.produce_type);
    }
    if (filters?.is_active !== undefined) {
        query += ' AND is_active = ?';
        params.push(filters.is_active);
    }
    query += ' ORDER BY created_at DESC';
    return await db.all(query, params);
}
async function saveLocalPhotoLog(photoLog) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`INSERT INTO local_photo_logs 
     (id, farmer_id, image_path, category, location_lat, location_lng, timestamp, notes, transaction_id, synced)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
        photoLog.id,
        photoLog.farmer_id,
        photoLog.image_path,
        photoLog.category,
        photoLog.location_lat,
        photoLog.location_lng,
        photoLog.timestamp,
        photoLog.notes,
        photoLog.transaction_id,
        photoLog.synced
    ]);
}
async function getUnsyncedPhotoLogs() {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    return await db.all('SELECT * FROM local_photo_logs WHERE synced = 0 ORDER BY timestamp ASC');
}
async function markPhotoLogAsSynced(id) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run('UPDATE local_photo_logs SET synced = 1 WHERE id = ?', [id]);
}
async function cacheUserProfile(profile) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`INSERT OR REPLACE INTO user_profile 
     (id, name, phone, type, location, bank_account_number, bank_ifsc_code, bank_name, bank_account_holder_name, credibility_score, rating)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
        profile.id,
        profile.name,
        profile.phone,
        profile.type,
        profile.location,
        profile.bank_account_number,
        profile.bank_ifsc_code,
        profile.bank_name,
        profile.bank_account_holder_name,
        profile.credibility_score,
        profile.rating
    ]);
}
async function getCachedUserProfile(userId) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    return await db.get('SELECT * FROM user_profile WHERE id = ?', [userId]);
}
async function logOfflineActivity(activity) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const result = await db.run(`INSERT INTO offline_activities (activity_type, user_id, data, status)
     VALUES (?, ?, ?, ?)`, [activity.activity_type, activity.user_id, activity.data, activity.status]);
    return result.lastID;
}
async function getPendingOfflineActivities() {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    return await db.all(`SELECT * FROM offline_activities 
     WHERE status = 'PENDING' 
     ORDER BY created_at ASC`);
}
async function updateOfflineActivityStatus(id, status, errorMessage) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`UPDATE offline_activities 
     SET status = ?, synced_at = CURRENT_TIMESTAMP, error_message = ?
     WHERE id = ?`, [status, errorMessage, id]);
}
// ============================================================================
// APP SETTINGS OPERATIONS
// ============================================================================
async function getAppSetting(key) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const result = await db.get('SELECT value FROM app_settings WHERE key = ?', [key]);
    return result?.value;
}
async function setAppSetting(key, value) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`INSERT OR REPLACE INTO app_settings (key, value, updated_at)
     VALUES (?, ?, CURRENT_TIMESTAMP)`, [key, value]);
}
async function isOfflineMode() {
    const offlineMode = await getAppSetting('offline_mode');
    return offlineMode === 'true';
}
async function setOfflineMode(offline) {
    await setAppSetting('offline_mode', offline ? 'true' : 'false');
    if (!offline) {
        await setAppSetting('last_online_at', new Date().toISOString());
    }
}
async function updateSyncStatus(status) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`UPDATE sync_status 
     SET last_sync_at = CURRENT_TIMESTAMP,
         last_sync_status = ?,
         records_synced = ?,
         records_failed = ?,
         error_message = ?
     WHERE entity_type = ?`, [
        status.last_sync_status,
        status.records_synced,
        status.records_failed,
        status.error_message,
        status.entity_type
    ]);
}
async function getSyncStatus(entityType) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    return await db.get('SELECT * FROM sync_status WHERE entity_type = ?', [entityType]);
}
async function getAllSyncStatuses() {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    return await db.all('SELECT * FROM sync_status ORDER BY last_sync_at DESC');
}
// ============================================================================
// Marketplace Operations - Listings
// ============================================================================
async function createListing(listing) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`INSERT INTO listings (
      id, farmer_id, produce_type, quantity, price_per_kg, 
      certificate_id, expected_harvest_date, created_at, updated_at,
      status, listing_type, produce_category_id, expiry_date, payment_method_preference
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
        listing.id,
        listing.farmerId,
        listing.produceType,
        listing.quantity,
        listing.pricePerKg,
        listing.certificateId,
        listing.expectedHarvestDate?.toISOString() || null,
        listing.createdAt.toISOString(),
        listing.updatedAt.toISOString(),
        listing.status || 'ACTIVE',
        listing.listingType || 'POST_HARVEST',
        listing.produceCategoryId,
        listing.expiryDate.toISOString(),
        listing.paymentMethodPreference || 'BOTH'
    ]);
    return listing;
}
async function getListing(id) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const row = await db.get('SELECT * FROM listings WHERE id = ?', [id]);
    return row ? mapRowToListing(row) : undefined;
}
async function getActiveListings() {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const rows = await db.all("SELECT * FROM listings WHERE status = 'ACTIVE' ORDER BY created_at DESC");
    return rows.map(mapRowToListing);
}
async function updateListing(id, updates) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const fields = [];
    const values = [];
    if (updates.quantity !== undefined) {
        fields.push('quantity = ?');
        values.push(updates.quantity);
    }
    if (updates.pricePerKg !== undefined) {
        fields.push('price_per_kg = ?');
        values.push(updates.pricePerKg);
    }
    if (updates.status !== undefined) {
        fields.push('status = ?');
        values.push(updates.status);
    }
    if (updates.expectedHarvestDate !== undefined) {
        fields.push('expected_harvest_date = ?');
        values.push(updates.expectedHarvestDate?.toISOString() || null);
    }
    if (fields.length === 0)
        return getListing(id);
    values.push(id);
    await db.run(`UPDATE listings SET ${fields.join(', ')} WHERE id = ?`, values);
    return getListing(id);
}
function mapRowToListing(row) {
    return {
        id: row.id,
        farmerId: row.farmer_id,
        produceType: row.produce_type,
        quantity: row.quantity,
        pricePerKg: row.price_per_kg,
        certificateId: row.certificate_id,
        expectedHarvestDate: row.expected_harvest_date ? new Date(row.expected_harvest_date) : undefined,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
        status: row.status,
        soldAt: row.sold_at ? new Date(row.sold_at) : undefined,
        transactionId: row.transaction_id,
        expiredAt: row.expired_at ? new Date(row.expired_at) : undefined,
        cancelledAt: row.cancelled_at ? new Date(row.cancelled_at) : undefined,
        cancelledBy: row.cancelled_by,
        listingType: row.listing_type,
        produceCategoryId: row.produce_category_id,
        expiryDate: new Date(row.expiry_date),
        paymentMethodPreference: row.payment_method_preference,
        saleChannel: row.sale_channel,
        salePrice: row.sale_price,
        saleNotes: row.sale_notes
    };
}
// ============================================================================
// Marketplace Operations - Transactions
// ============================================================================
async function createTransaction(transaction) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`INSERT INTO transactions (
      id, listing_id, farmer_id, buyer_id, amount, status, 
      created_at, updated_at, dispatched_at, delivered_at, completed_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
        transaction.id,
        transaction.listingId,
        transaction.farmerId,
        transaction.buyerId,
        transaction.amount,
        transaction.status,
        transaction.createdAt.toISOString(),
        transaction.updatedAt.toISOString(),
        transaction.dispatchedAt?.toISOString() || null,
        transaction.deliveredAt?.toISOString() || null,
        transaction.completedAt?.toISOString() || null
    ]);
    return transaction;
}
async function getTransaction(id) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const row = await db.get('SELECT * FROM transactions WHERE id = ?', [id]);
    return row ? mapRowToTransaction(row) : undefined;
}
async function updateTransaction(id, updates) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const fields = ['updated_at = ?'];
    const values = [new Date().toISOString()];
    if (updates.status !== undefined) {
        fields.push('status = ?');
        values.push(updates.status);
    }
    if (updates.dispatchedAt !== undefined) {
        fields.push('dispatched_at = ?');
        values.push(updates.dispatchedAt.toISOString());
    }
    if (updates.deliveredAt !== undefined) {
        fields.push('delivered_at = ?');
        values.push(updates.deliveredAt.toISOString());
    }
    if (updates.completedAt !== undefined) {
        fields.push('completed_at = ?');
        values.push(updates.completedAt.toISOString());
    }
    values.push(id);
    await db.run(`UPDATE transactions SET ${fields.join(', ')} WHERE id = ?`, values);
    return getTransaction(id);
}
function mapRowToTransaction(row) {
    return {
        id: row.id,
        listingId: row.listing_id,
        farmerId: row.farmer_id,
        buyerId: row.buyer_id,
        amount: row.amount,
        status: row.status,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
        dispatchedAt: row.dispatched_at ? new Date(row.dispatched_at) : undefined,
        deliveredAt: row.delivered_at ? new Date(row.delivered_at) : undefined,
        completedAt: row.completed_at ? new Date(row.completed_at) : undefined
    };
}
// ============================================================================
// Marketplace Operations - Escrow Accounts
// ============================================================================
async function createEscrow(escrow) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    await db.run(`INSERT INTO escrow_accounts (
      id, transaction_id, amount, status, is_locked, created_at, released_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?)`, [
        escrow.id,
        escrow.transactionId,
        escrow.amount,
        escrow.status,
        escrow.isLocked ? 1 : 0,
        escrow.createdAt.toISOString(),
        escrow.releasedAt?.toISOString() || null
    ]);
    return escrow;
}
async function getEscrow(id) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const row = await db.get('SELECT * FROM escrow_accounts WHERE id = ?', [id]);
    return row ? mapRowToEscrow(row) : undefined;
}
async function getEscrowByTransaction(transactionId) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const row = await db.get('SELECT * FROM escrow_accounts WHERE transaction_id = ?', [transactionId]);
    return row ? mapRowToEscrow(row) : undefined;
}
async function updateEscrow(id, updates) {
    const db = (0, sqlite_config_1.getSQLiteDB)();
    const fields = [];
    const values = [];
    if (updates.status !== undefined) {
        fields.push('status = ?');
        values.push(updates.status);
    }
    if (updates.isLocked !== undefined) {
        fields.push('is_locked = ?');
        values.push(updates.isLocked ? 1 : 0);
    }
    if (updates.releasedAt !== undefined) {
        fields.push('released_at = ?');
        values.push(updates.releasedAt.toISOString());
    }
    if (fields.length === 0)
        return getEscrow(id);
    values.push(id);
    await db.run(`UPDATE escrow_accounts SET ${fields.join(', ')} WHERE id = ?`, values);
    return getEscrow(id);
}
function mapRowToEscrow(row) {
    return {
        id: row.id,
        transactionId: row.transaction_id,
        amount: row.amount,
        status: row.status,
        isLocked: row.is_locked === 1,
        createdAt: new Date(row.created_at),
        releasedAt: row.released_at ? new Date(row.released_at) : undefined
    };
}
//# sourceMappingURL=sqlite-helpers.js.map