"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupSQLite = setupSQLite;
const sqlite_config_1 = require("./sqlite-config");
// Setup SQLite database
async function setupSQLite() {
    console.log('\n=== SQLite Setup ===\n');
    try {
        // Test connection
        console.log('Testing SQLite connection...');
        const connected = await (0, sqlite_config_1.testSQLiteConnection)();
        if (!connected) {
            throw new Error('Cannot connect to SQLite database');
        }
        // Initialize schema
        console.log('\nInitializing schema...');
        await (0, sqlite_config_1.initializeSQLiteSchema)();
        // Get statistics
        console.log('\nDatabase Statistics:');
        const stats = await (0, sqlite_config_1.getSQLiteStats)();
        console.log(JSON.stringify(stats, null, 2));
        // Get database size
        const size = (0, sqlite_config_1.getDatabaseSize)();
        console.log(`\nDatabase Size: ${(size / 1024).toFixed(2)} KB`);
        console.log(`Database Path: ${sqlite_config_1.DB_PATH}`);
        console.log('\n=== SQLite Setup Complete ===\n');
    }
    catch (error) {
        console.error('SQLite setup failed:', error);
        throw error;
    }
}
// CLI execution
if (require.main === module) {
    const command = process.argv[2];
    if (command === 'setup') {
        setupSQLite()
            .then(() => {
            console.log('SQLite setup completed successfully');
            process.exit(0);
        })
            .catch((error) => {
            console.error('SQLite setup failed:', error);
            process.exit(1);
        })
            .finally(() => {
            (0, sqlite_config_1.closeSQLiteDB)();
        });
    }
    else if (command === 'test') {
        (0, sqlite_config_1.testSQLiteConnection)()
            .then((success) => {
            if (success) {
                console.log('SQLite connection test passed');
                process.exit(0);
            }
            else {
                console.log('SQLite connection test failed');
                process.exit(1);
            }
        })
            .catch((error) => {
            console.error('SQLite connection test error:', error);
            process.exit(1);
        })
            .finally(() => {
            (0, sqlite_config_1.closeSQLiteDB)();
        });
    }
    else if (command === 'stats') {
        (0, sqlite_config_1.openSQLiteDB)()
            .then(() => (0, sqlite_config_1.getSQLiteStats)())
            .then((stats) => {
            console.log('\nSQLite Database Statistics:');
            console.log(JSON.stringify(stats, null, 2));
            const size = (0, sqlite_config_1.getDatabaseSize)();
            console.log(`\nDatabase Size: ${(size / 1024).toFixed(2)} KB`);
            console.log(`Database Path: ${sqlite_config_1.DB_PATH}`);
            process.exit(0);
        })
            .catch((error) => {
            console.error('Error getting stats:', error);
            process.exit(1);
        })
            .finally(() => {
            (0, sqlite_config_1.closeSQLiteDB)();
        });
    }
    else {
        console.log('Usage:');
        console.log('  npm run sqlite:setup  - Setup SQLite database and schema');
        console.log('  npm run sqlite:test   - Test SQLite connection');
        console.log('  npm run sqlite:stats  - Get database statistics');
        process.exit(1);
    }
}
//# sourceMappingURL=sqlite-setup.js.map