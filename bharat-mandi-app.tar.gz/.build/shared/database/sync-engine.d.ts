import type { PostgreSQLAdapter } from './pg-adapter';
import type { SQLiteAdapter } from './sqlite-adapter';
import type { ConnectionMonitor } from './connection-monitor';
/**
 * Sync Queue Item interface
 * Represents an operation queued for synchronization
 */
export interface SyncQueueItem {
    id?: number;
    operation_type: 'CREATE' | 'UPDATE' | 'DELETE';
    entity_type: string;
    entity_id: string;
    data: any;
    created_at?: Date;
    retry_count?: number;
    last_retry_at?: Date;
    error_message?: string;
}
/**
 * Sync Engine for Database Synchronization
 * Manages the sync queue for offline operations and synchronizes data between PostgreSQL and SQLite
 * Validates: Requirements 3.1, 3.2, 3.4, 6.1, 6.2, 6.3, 6.4, 6.5
 */
export declare class SyncEngine {
    private pgAdapter;
    private sqliteAdapter;
    private connectionMonitor;
    private syncInterval;
    private isSyncing;
    constructor(pgAdapter: PostgreSQLAdapter, sqliteAdapter: SQLiteAdapter, connectionMonitor: ConnectionMonitor);
    /**
     * Add operation to sync queue
     * Called when a write operation fails due to PostgreSQL unavailability
     * Validates: Requirement 6.1
     *
     * @param operationType - Type of operation (CREATE, UPDATE, DELETE)
     * @param entityType - Type of entity (e.g., 'user', 'listing')
     * @param entityId - ID of the entity
     * @param data - Entity data to sync
     */
    addToQueue(operationType: 'CREATE' | 'UPDATE' | 'DELETE', entityType: string, entityId: string, data: any): Promise<void>;
    /**
     * Get pending sync items from the queue
     * Validates: Requirement 6.2
     *
     * @param limit - Maximum number of items to retrieve (default: 50)
     * @returns Array of pending sync queue items
     */
    getPendingSyncItems(limit?: number): Promise<SyncQueueItem[]>;
    /**
     * Remove sync queue item after successful synchronization
     * Validates: Requirement 6.4
     *
     * @param id - ID of the sync queue item to remove
     */
    removeSyncQueueItem(id: number): Promise<void>;
    /**
     * Process sync queue
     * Processes pending sync items in chronological order with retry logic
     * Validates: Requirements 3.2, 3.4, 6.3, 6.5
     */
    processSyncQueue(): Promise<void>;
    /**
     * Propagate PostgreSQL changes to SQLite asynchronously
     * Ensures changes propagate within 5 seconds without blocking the caller
     * Validates: Requirements 3.1, 4.4
     *
     * @param operationType - Type of operation (CREATE, UPDATE, DELETE)
     * @param entityType - Type of entity (e.g., 'user')
     * @param entityId - ID of the entity
     * @param data - Entity data to propagate
     */
    propagateToSQLite(operationType: 'CREATE' | 'UPDATE' | 'DELETE', entityType: string, entityId: string, data: any): Promise<void>;
    /**
     * Process individual sync item
     * Routes the operation to the appropriate PostgreSQL adapter method
     *
     * @param item - Sync queue item to process
     */
    private processSyncItem;
    /**
     * Handle connectivity restored event
     * Triggers sync queue processing when PostgreSQL connection is restored
     */
    private onConnected;
    /**
     * Handle connectivity lost event
     */
    private onDisconnected;
    /**
     * Start the sync engine
     * Begins periodic processing of the sync queue
     */
    start(): void;
    /**
     * Stop the sync engine
     * Stops periodic processing of the sync queue
     */
    stop(): void;
}
//# sourceMappingURL=sync-engine.d.ts.map