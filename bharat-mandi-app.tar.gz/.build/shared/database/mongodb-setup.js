"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupMongoDB = setupMongoDB;
const mongodb_config_1 = require("./mongodb-config");
const mongodb_models_1 = require("./mongodb-models");
// Setup MongoDB collections and indexes
async function setupMongoDB() {
    console.log('\n=== MongoDB Setup ===\n');
    try {
        // Test connection
        console.log('Testing MongoDB connection...');
        const connected = await (0, mongodb_config_1.testMongoConnection)();
        if (!connected) {
            throw new Error('Cannot connect to MongoDB');
        }
        // Create indexes
        console.log('\nCreating indexes...');
        await (0, mongodb_models_1.createIndexes)();
        // Get collection stats
        console.log('\nCollection Statistics:');
        const stats = await (0, mongodb_models_1.getCollectionStats)();
        console.log(JSON.stringify(stats, null, 2));
        console.log('\n=== MongoDB Setup Complete ===\n');
    }
    catch (error) {
        console.error('MongoDB setup failed:', error);
        throw error;
    }
}
// CLI execution
if (require.main === module) {
    const command = process.argv[2];
    if (command === 'setup') {
        setupMongoDB()
            .then(() => {
            console.log('MongoDB setup completed successfully');
            process.exit(0);
        })
            .catch((error) => {
            console.error('MongoDB setup failed:', error);
            process.exit(1);
        })
            .finally(() => {
            (0, mongodb_config_1.disconnectMongoDB)();
        });
    }
    else if (command === 'test') {
        (0, mongodb_config_1.testMongoConnection)()
            .then((success) => {
            if (success) {
                console.log('MongoDB connection test passed');
                process.exit(0);
            }
            else {
                console.log('MongoDB connection test failed');
                process.exit(1);
            }
        })
            .catch((error) => {
            console.error('MongoDB connection test error:', error);
            process.exit(1);
        })
            .finally(() => {
            (0, mongodb_config_1.disconnectMongoDB)();
        });
    }
    else if (command === 'stats') {
        (0, mongodb_config_1.connectMongoDB)()
            .then(() => (0, mongodb_models_1.getCollectionStats)())
            .then((stats) => {
            console.log('\nMongoDB Collection Statistics:');
            console.log(JSON.stringify(stats, null, 2));
            process.exit(0);
        })
            .catch((error) => {
            console.error('Error getting stats:', error);
            process.exit(1);
        })
            .finally(() => {
            (0, mongodb_config_1.disconnectMongoDB)();
        });
    }
    else {
        console.log('Usage:');
        console.log('  npm run mongodb:setup  - Setup MongoDB collections and indexes');
        console.log('  npm run mongodb:test   - Test MongoDB connection');
        console.log('  npm run mongodb:stats  - Get collection statistics');
        process.exit(1);
    }
}
//# sourceMappingURL=mongodb-setup.js.map