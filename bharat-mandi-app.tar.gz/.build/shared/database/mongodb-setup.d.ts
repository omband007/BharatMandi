export declare function setupMongoDB(): Promise<void>;
//# sourceMappingURL=mongodb-setup.d.ts.map