"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseManager = void 0;
// Logging control - set to false to reduce console output
const VERBOSE_LOGGING = process.env.DB_VERBOSE_LOGGING === 'true';
/**
 * DatabaseManager Class
 *
 * Main database manager that provides PostgreSQL database operations.
 *
 * Requirements: 1.2, 1.4, 5.1, 5.2
 */
class DatabaseManager {
    constructor() {
        this.instanceId = Math.random().toString(36).substring(7);
        if (VERBOSE_LOGGING) {
            console.log(`[DatabaseManager] New instance created: ${this.instanceId}`);
        }
        // Import adapters dynamically to avoid circular dependencies
        const { PostgreSQLAdapter } = require('./pg-adapter');
        const { ConnectionMonitor } = require('./connection-monitor');
        // Initialize PostgreSQL adapter
        this.pgAdapter = new PostgreSQLAdapter();
        // Initialize connection monitor with PostgreSQL adapter
        this.connectionMonitor = new ConnectionMonitor(this.pgAdapter);
    }
    /**
     * Start the database manager
     * Begins connection monitoring
     */
    async start() {
        if (VERBOSE_LOGGING) {
            console.log(`[DatabaseManager:${this.instanceId}] Starting connection monitor`);
        }
        await this.connectionMonitor.start();
    }
    /**
     * Stop the database manager
     * Stops connection monitoring
     */
    stop() {
        if (VERBOSE_LOGGING) {
            console.log('[DatabaseManager] Stopping connection monitor');
        }
        this.connectionMonitor.stop();
    }
    /**
     * Get the PostgreSQL adapter instance
     * @returns PostgreSQL adapter
     */
    getPostgreSQLAdapter() {
        return this.pgAdapter;
    }
    /**
     * Get the connection monitor instance
     * @returns Connection monitor
     */
    getConnectionMonitor() {
        return this.connectionMonitor;
    }
    /**
     * Check if PostgreSQL is currently connected
     * @returns true if connected, false otherwise
     */
    isPostgreSQLConnected() {
        return this.connectionMonitor.isConnected();
    }
    /**
     * Get health status for monitoring
     * @returns Health status object with connectivity information
     */
    getHealthStatus() {
        return {
            postgresql: this.connectionMonitor.getHealthStatus()
        };
    }
    // ============================================================================
    // User Operations
    // ============================================================================
    async createUser(user, pinHash) {
        return await this.pgAdapter.createUser(user, pinHash);
    }
    async updateUser(userId, updates) {
        return await this.pgAdapter.updateUser(userId, updates);
    }
    async updateUserPin(phoneNumber, pinHash) {
        await this.pgAdapter.updateUserPin(phoneNumber, pinHash);
    }
    async getUserByPhone(phoneNumber) {
        return await this.pgAdapter.getUserByPhone(phoneNumber);
    }
    async getUserById(id) {
        return await this.pgAdapter.getUserById(id);
    }
    // ============================================================================
    // Listing Operations
    // ============================================================================
    async createListing(listing) {
        return await this.pgAdapter.createListing(listing);
    }
    async getListing(id) {
        return await this.pgAdapter.getListing(id);
    }
    async getActiveListings() {
        return await this.pgAdapter.getActiveListings();
    }
    async updateListing(id, updates) {
        return await this.pgAdapter.updateListing(id, updates);
    }
    // ============================================================================
    // Transaction Operations
    // ============================================================================
    async createTransaction(transaction) {
        return await this.pgAdapter.createTransaction(transaction);
    }
    async getTransaction(id) {
        return await this.pgAdapter.getTransaction(id);
    }
    async updateTransaction(id, updates) {
        return await this.pgAdapter.updateTransaction(id, updates);
    }
    // ============================================================================
    // Escrow Operations
    // ============================================================================
    async createEscrow(escrow) {
        return await this.pgAdapter.createEscrow(escrow);
    }
    async getEscrow(id) {
        return await this.pgAdapter.getEscrow(id);
    }
    async getEscrowByTransaction(transactionId) {
        return await this.pgAdapter.getEscrowByTransaction(transactionId);
    }
    async updateEscrow(id, updates) {
        return await this.pgAdapter.updateEscrow(id, updates);
    }
    // ============================================================================
    // Notification Operations
    // ============================================================================
    async createNotification(notification) {
        return await this.pgAdapter.createNotification(notification);
    }
    async getNotification(id) {
        return await this.pgAdapter.getNotification(id);
    }
    async getUserNotifications(userId) {
        return await this.pgAdapter.getUserNotifications(userId);
    }
    async updateNotification(id, updates) {
        return await this.pgAdapter.updateNotification(id, updates);
    }
    async getNotificationTemplate(type, language) {
        return await this.pgAdapter.getNotificationTemplate(type, language);
    }
    // ============================================================================
    // Translation Feedback Operations
    // ============================================================================
    async createTranslationFeedback(feedback) {
        return await this.pgAdapter.createTranslationFeedback(feedback);
    }
    async getTranslationFeedback(id) {
        return await this.pgAdapter.getTranslationFeedback(id);
    }
    async getTranslationFeedbackStats(targetLanguage) {
        return await this.pgAdapter.getTranslationFeedbackStats(targetLanguage);
    }
    async updateTranslationFeedback(id, updates) {
        return await this.pgAdapter.updateTranslationFeedback(id, updates);
    }
    // ============================================================================
    // Low-Level SQL Operations
    // ============================================================================
    async run(sql, params) {
        const pgAdapter = this.pgAdapter;
        if (pgAdapter.run) {
            await pgAdapter.run(sql, params);
        }
        else {
            await pgAdapter.pool.query(sql, params);
        }
    }
    async get(sql, params) {
        const pgAdapter = this.pgAdapter;
        if (pgAdapter.get) {
            return await pgAdapter.get(sql, params);
        }
        else {
            const result = await pgAdapter.pool.query(sql, params);
            return result.rows[0];
        }
    }
    async all(sql, params) {
        const pgAdapter = this.pgAdapter;
        if (pgAdapter.all) {
            return await pgAdapter.all(sql, params);
        }
        else {
            const result = await pgAdapter.pool.query(sql, params);
            return result.rows;
        }
    }
}
exports.DatabaseManager = DatabaseManager;
//# sourceMappingURL=db-abstraction.js.map