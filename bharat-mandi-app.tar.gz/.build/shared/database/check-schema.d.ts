/**
 * Check Database Schema
 */
export {};
//# sourceMappingURL=check-schema.d.ts.map