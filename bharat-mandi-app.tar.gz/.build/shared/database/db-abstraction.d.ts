import type { OTPSession } from '../../features/profile/types/profile.types';
import type { Listing } from '../../features/marketplace/marketplace.types';
import type { Transaction, EscrowAccount } from '../../features/transactions/transaction.types';
import type { Notification, NotificationTemplate, NotificationType, TranslationFeedback, TranslationFeedbackStats } from '../../features/notifications/notification.types';
import type { PostgreSQLAdapter } from './pg-adapter';
import type { ConnectionMonitor } from './connection-monitor';
export interface User {
    id: string;
    phoneNumber: string;
    name: string;
    userType: 'farmer' | 'buyer' | 'both';
    location: any;
    bankAccount?: any;
    languagePreference?: string;
    createdAt: Date;
    updatedAt?: Date;
}
/**
 * DatabaseAdapter Interface
 *
 * Defines the contract that database adapters must implement.
 *
 * Requirements: 1.2, 1.4
 */
export interface DatabaseAdapter {
    createUser(user: User, pinHash?: string): Promise<User>;
    getUserById(id: string): Promise<User | undefined>;
    getUserByPhone(phoneNumber: string): Promise<User | undefined>;
    updateUser(userId: string, updates: Partial<User>): Promise<User | undefined>;
    getAllUsers(): Promise<User[]>;
    getUserPinHash(phoneNumber: string): Promise<string | undefined>;
    updateUserPin(phoneNumber: string, pinHash: string): Promise<void>;
    getFailedAttempts(phoneNumber: string): Promise<{
        failed_attempts: number;
        locked_until?: string;
    } | undefined>;
    incrementFailedAttempts(phoneNumber: string): Promise<void>;
    resetFailedAttempts(phoneNumber: string): Promise<void>;
    lockAccount(phoneNumber: string, lockUntil: Date): Promise<void>;
    createOTPSession(session: OTPSession): Promise<void>;
    getOTPSession(phoneNumber: string): Promise<OTPSession | undefined>;
    updateOTPAttempts(phoneNumber: string, attempts: number): Promise<void>;
    deleteOTPSession(phoneNumber: string): Promise<void>;
    createListing(listing: Listing): Promise<Listing>;
    getListing(id: string): Promise<Listing | undefined>;
    getActiveListings(): Promise<Listing[]>;
    updateListing(id: string, updates: Partial<Listing>): Promise<Listing | undefined>;
    createTransaction(transaction: Transaction): Promise<Transaction>;
    getTransaction(id: string): Promise<Transaction | undefined>;
    updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction | undefined>;
    createEscrow(escrow: EscrowAccount): Promise<EscrowAccount>;
    getEscrow(id: string): Promise<EscrowAccount | undefined>;
    getEscrowByTransaction(transactionId: string): Promise<EscrowAccount | undefined>;
    updateEscrow(id: string, updates: Partial<EscrowAccount>): Promise<EscrowAccount | undefined>;
    createNotification(notification: Notification): Promise<Notification>;
    getNotification(id: string): Promise<Notification | undefined>;
    getUserNotifications(userId: string): Promise<Notification[]>;
    updateNotification(id: string, updates: Partial<Notification>): Promise<Notification | undefined>;
    getNotificationTemplate(type: NotificationType, language: string): Promise<NotificationTemplate | undefined>;
    createTranslationFeedback(feedback: Omit<TranslationFeedback, 'id' | 'createdAt' | 'updatedAt'>): Promise<TranslationFeedback>;
    getTranslationFeedback(id: string): Promise<TranslationFeedback | undefined>;
    getTranslationFeedbackStats(targetLanguage?: string): Promise<TranslationFeedbackStats>;
    updateTranslationFeedback(id: string, updates: Partial<TranslationFeedback>): Promise<TranslationFeedback | undefined>;
}
/**
 * DatabaseManager Class
 *
 * Main database manager that provides PostgreSQL database operations.
 *
 * Requirements: 1.2, 1.4, 5.1, 5.2
 */
export declare class DatabaseManager {
    private pgAdapter;
    private connectionMonitor;
    private instanceId;
    constructor();
    /**
     * Start the database manager
     * Begins connection monitoring
     */
    start(): Promise<void>;
    /**
     * Stop the database manager
     * Stops connection monitoring
     */
    stop(): void;
    /**
     * Get the PostgreSQL adapter instance
     * @returns PostgreSQL adapter
     */
    getPostgreSQLAdapter(): PostgreSQLAdapter;
    /**
     * Get the connection monitor instance
     * @returns Connection monitor
     */
    getConnectionMonitor(): ConnectionMonitor;
    /**
     * Check if PostgreSQL is currently connected
     * @returns true if connected, false otherwise
     */
    isPostgreSQLConnected(): boolean;
    /**
     * Get health status for monitoring
     * @returns Health status object with connectivity information
     */
    getHealthStatus(): {
        postgresql: {
            connected: boolean;
            lastCheck: Date | null;
        };
    };
    createUser(user: User, pinHash?: string): Promise<User>;
    updateUser(userId: string, updates: Partial<User>): Promise<User | undefined>;
    updateUserPin(phoneNumber: string, pinHash: string): Promise<void>;
    getUserByPhone(phoneNumber: string): Promise<User | undefined>;
    getUserById(id: string): Promise<User | undefined>;
    createListing(listing: Listing): Promise<Listing>;
    getListing(id: string): Promise<Listing | undefined>;
    getActiveListings(): Promise<Listing[]>;
    updateListing(id: string, updates: Partial<Listing>): Promise<Listing | undefined>;
    createTransaction(transaction: Transaction): Promise<Transaction>;
    getTransaction(id: string): Promise<Transaction | undefined>;
    updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction | undefined>;
    createEscrow(escrow: EscrowAccount): Promise<EscrowAccount>;
    getEscrow(id: string): Promise<EscrowAccount | undefined>;
    getEscrowByTransaction(transactionId: string): Promise<EscrowAccount | undefined>;
    updateEscrow(id: string, updates: Partial<EscrowAccount>): Promise<EscrowAccount | undefined>;
    createNotification(notification: Notification): Promise<Notification>;
    getNotification(id: string): Promise<Notification | undefined>;
    getUserNotifications(userId: string): Promise<Notification[]>;
    updateNotification(id: string, updates: Partial<Notification>): Promise<Notification | undefined>;
    getNotificationTemplate(type: NotificationType, language: string): Promise<NotificationTemplate | undefined>;
    createTranslationFeedback(feedback: Omit<TranslationFeedback, 'id' | 'createdAt' | 'updatedAt'>): Promise<TranslationFeedback>;
    getTranslationFeedback(id: string): Promise<TranslationFeedback | undefined>;
    getTranslationFeedbackStats(targetLanguage?: string): Promise<TranslationFeedbackStats>;
    updateTranslationFeedback(id: string, updates: Partial<TranslationFeedback>): Promise<TranslationFeedback | undefined>;
    run(sql: string, params?: any[]): Promise<void>;
    get(sql: string, params?: any[]): Promise<any>;
    all(sql: string, params?: any[]): Promise<any[]>;
}
//# sourceMappingURL=db-abstraction.d.ts.map