import { EventEmitter } from 'events';
import type { PostgreSQLAdapter } from './pg-adapter';
/**
 * Connection Monitor for PostgreSQL Database
 * Monitors PostgreSQL connectivity and emits events on state changes
 * Validates: Requirements 9.1, 9.2, 9.3, 9.4
 */
export declare class ConnectionMonitor extends EventEmitter {
    private pgAdapter;
    private connected;
    private checkInterval;
    private lastCheckTime;
    private instanceId;
    constructor(pgAdapter: PostgreSQLAdapter);
    /**
     * Start monitoring PostgreSQL connectivity
     * Checks connectivity every 30 seconds (Requirement 9.1)
     */
    start(): Promise<void>;
    /**
     * Stop monitoring
     */
    stop(): void;
    /**
     * Check PostgreSQL connectivity and emit events on state changes
     * Validates: Requirements 9.2, 9.3
     */
    private checkConnectivity;
    /**
     * Get current connectivity status
     * @returns true if connected, false otherwise
     */
    isConnected(): boolean;
    /**
     * Get last check time
     * @returns Date of last connectivity check or null if not checked yet
     */
    getLastCheckTime(): Date | null;
    /**
     * Get health status data for health check endpoint
     * Validates: Requirement 9.4
     * @returns Object with connectivity status and last check time
     */
    getHealthStatus(): {
        connected: boolean;
        lastCheck: Date | null;
    };
}
//# sourceMappingURL=connection-monitor.d.ts.map