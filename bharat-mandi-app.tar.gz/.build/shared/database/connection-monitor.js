"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConnectionMonitor = void 0;
const events_1 = require("events");
// Logging control
const VERBOSE_LOGGING = process.env.DB_VERBOSE_LOGGING === 'true';
/**
 * Connection Monitor for PostgreSQL Database
 * Monitors PostgreSQL connectivity and emits events on state changes
 * Validates: Requirements 9.1, 9.2, 9.3, 9.4
 */
class ConnectionMonitor extends events_1.EventEmitter {
    constructor(pgAdapter) {
        super();
        this.connected = false;
        this.checkInterval = null;
        this.lastCheckTime = null;
        this.pgAdapter = pgAdapter;
        this.instanceId = Math.random().toString(36).substring(7);
        if (VERBOSE_LOGGING) {
            console.log(`[ConnectionMonitor] New instance created: ${this.instanceId}`);
        }
    }
    /**
     * Start monitoring PostgreSQL connectivity
     * Checks connectivity every 30 seconds (Requirement 9.1)
     */
    async start() {
        if (VERBOSE_LOGGING) {
            console.log(`[ConnectionMonitor:${this.instanceId}] Starting - performing initial connectivity check...`);
        }
        // Initial check (wait for it to complete)
        await this.checkConnectivity();
        if (VERBOSE_LOGGING) {
            console.log(`[ConnectionMonitor:${this.instanceId}] Initial check complete - connected: ${this.connected}`);
        }
        // Check connectivity every 30 seconds
        this.checkInterval = setInterval(() => {
            this.checkConnectivity();
        }, 30000);
    }
    /**
     * Stop monitoring
     */
    stop() {
        if (this.checkInterval) {
            clearInterval(this.checkInterval);
            this.checkInterval = null;
        }
    }
    /**
     * Check PostgreSQL connectivity and emit events on state changes
     * Validates: Requirements 9.2, 9.3
     */
    async checkConnectivity() {
        const wasConnected = this.connected;
        try {
            this.connected = await this.pgAdapter.checkConnection();
        }
        catch (error) {
            console.error(`[ConnectionMonitor:${this.instanceId}] Error checking connectivity:`, error);
            this.connected = false;
        }
        this.lastCheckTime = new Date();
        // Only log on state change, not every check
        // Emit events on state change
        if (this.connected && !wasConnected) {
            if (VERBOSE_LOGGING) {
                console.log(`[ConnectionMonitor:${this.instanceId}] PostgreSQL connected`);
            }
            this.emit('connected');
        }
        else if (!this.connected && wasConnected) {
            console.log(`[ConnectionMonitor:${this.instanceId}] PostgreSQL disconnected`);
            this.emit('disconnected');
        }
    }
    /**
     * Get current connectivity status
     * @returns true if connected, false otherwise
     */
    isConnected() {
        // Don't log every call - too noisy
        return this.connected;
    }
    /**
     * Get last check time
     * @returns Date of last connectivity check or null if not checked yet
     */
    getLastCheckTime() {
        return this.lastCheckTime;
    }
    /**
     * Get health status data for health check endpoint
     * Validates: Requirement 9.4
     * @returns Object with connectivity status and last check time
     */
    getHealthStatus() {
        return {
            connected: this.connected,
            lastCheck: this.lastCheckTime
        };
    }
}
exports.ConnectionMonitor = ConnectionMonitor;
//# sourceMappingURL=connection-monitor.js.map