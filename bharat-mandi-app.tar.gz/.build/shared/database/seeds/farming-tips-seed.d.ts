import type { FarmingTip } from '../mongodb-models';
/**
 * Seed data for farming tips knowledge base
 * Covers top 20 crops with advice on planting, irrigation, pest control, and harvesting
 */
export declare const farmingTipsSeedData: Omit<FarmingTip, 'createdAt' | 'updatedAt'>[];
/**
 * Get total count of seed data entries
 */
export declare function getFarmingTipsSeedCount(): number;
/**
 * Get seed data by crop
 */
export declare function getFarmingTipsByCrop(crop: string): Omit<FarmingTip, 'createdAt' | 'updatedAt'>[];
/**
 * Get all unique crops in seed data
 */
export declare function getUniqueCrops(): string[];
//# sourceMappingURL=farming-tips-seed.d.ts.map