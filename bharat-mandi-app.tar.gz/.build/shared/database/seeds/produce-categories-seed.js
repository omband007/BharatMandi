"use strict";
/**
 * Seed data for produce categories
 * Defines default categories with expiry periods for perishability-based listing expiration
 * Requirements: 6.5
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.produceCategoriesSeedData = void 0;
exports.getProduceCategoriesSeedCount = getProduceCategoriesSeedCount;
exports.getCategoryByName = getCategoryByName;
exports.getAllCategoryNames = getAllCategoryNames;
const uuid_1 = require("uuid");
/**
 * Default produce categories with expiry periods
 * Expiry period is in hours after harvest date
 */
exports.produceCategoriesSeedData = [
    {
        id: (0, uuid_1.v4)(),
        name: 'Leafy Greens',
        expiry_period_hours: 24,
        description: 'Palak, methi, dhania, lettuce - highly perishable greens'
    },
    {
        id: (0, uuid_1.v4)(),
        name: 'Fruits',
        expiry_period_hours: 48,
        description: 'Tomato, apple, mango, banana - moderately perishable fruits'
    },
    {
        id: (0, uuid_1.v4)(),
        name: 'Root Vegetables',
        expiry_period_hours: 168, // 7 days
        description: 'Potato, onion, garlic, carrot - long-lasting root vegetables'
    },
    {
        id: (0, uuid_1.v4)(),
        name: 'Grains',
        expiry_period_hours: 672, // 28 days
        description: 'Wheat, rice, corn, millet - dry grains with extended shelf life'
    }
];
/**
 * Get total count of seed data entries
 */
function getProduceCategoriesSeedCount() {
    return exports.produceCategoriesSeedData.length;
}
/**
 * Get category by name
 */
function getCategoryByName(name) {
    return exports.produceCategoriesSeedData.find(cat => cat.name === name);
}
/**
 * Get all category names
 */
function getAllCategoryNames() {
    return exports.produceCategoriesSeedData.map(cat => cat.name);
}
//# sourceMappingURL=produce-categories-seed.js.map