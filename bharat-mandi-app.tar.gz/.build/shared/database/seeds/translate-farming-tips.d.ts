import type { FarmingTip } from '../mongodb-models';
/**
 * Translate all farming tips to all target languages
 */
export declare function translateAllFarmingTips(): Promise<Omit<FarmingTip, 'createdAt' | 'updatedAt'>[]>;
/**
 * Get translated farming tips (returns cached if available, otherwise translates)
 */
export declare function getTranslatedFarmingTips(): Promise<Omit<FarmingTip, 'createdAt' | 'updatedAt'>[]>;
//# sourceMappingURL=translate-farming-tips.d.ts.map