/**
 * Seeding script for produce categories
 * Inserts default produce categories into both PostgreSQL and SQLite databases
 * Requirements: 6.5
 */
import { DatabaseManager } from '../db-abstraction';
/**
 * Seed produce categories into the database
 * @param db - Database manager instance
 */
export declare function seedProduceCategories(db: DatabaseManager): Promise<void>;
/**
 * Main function to run seeding
 */
export declare function runProduceCategoriesSeeding(): Promise<void>;
//# sourceMappingURL=seed-produce-categories.d.ts.map