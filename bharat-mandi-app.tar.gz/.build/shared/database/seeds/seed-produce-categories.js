"use strict";
/**
 * Seeding script for produce categories
 * Inserts default produce categories into both PostgreSQL and SQLite databases
 * Requirements: 6.5
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.seedProduceCategories = seedProduceCategories;
exports.runProduceCategoriesSeeding = runProduceCategoriesSeeding;
const db_abstraction_1 = require("../db-abstraction");
const produce_categories_seed_1 = require("./produce-categories-seed");
/**
 * Seed produce categories into the database
 * @param db - Database manager instance
 */
async function seedProduceCategories(db) {
    console.log('Seeding produce categories...');
    try {
        for (const category of produce_categories_seed_1.produceCategoriesSeedData) {
            // Check if category already exists
            const existing = await db.get('SELECT id FROM produce_categories WHERE name = ?', [category.name]);
            if (existing) {
                console.log(`Category "${category.name}" already exists, skipping...`);
                continue;
            }
            // Insert category
            await db.run(`INSERT INTO produce_categories (id, name, expiry_period_hours, description, created_at, updated_at)
         VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`, [category.id, category.name, category.expiry_period_hours, category.description]);
            console.log(`✓ Inserted category: ${category.name} (${category.expiry_period_hours}h expiry)`);
        }
        console.log(`✓ Successfully seeded ${produce_categories_seed_1.produceCategoriesSeedData.length} produce categories`);
    }
    catch (error) {
        console.error('Error seeding produce categories:', error);
        throw error;
    }
}
/**
 * Main function to run seeding
 */
async function runProduceCategoriesSeeding() {
    const db = new db_abstraction_1.DatabaseManager();
    try {
        await db.start();
        await seedProduceCategories(db);
        console.log('Produce categories seeding completed successfully');
    }
    catch (error) {
        console.error('Failed to seed produce categories:', error);
        process.exit(1);
    }
    finally {
        db.stop();
    }
}
// Run seeding if this file is executed directly
if (require.main === module) {
    runProduceCategoriesSeeding();
}
//# sourceMappingURL=seed-produce-categories.js.map