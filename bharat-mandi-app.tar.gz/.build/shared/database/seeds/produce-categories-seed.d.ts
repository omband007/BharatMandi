/**
 * Seed data for produce categories
 * Defines default categories with expiry periods for perishability-based listing expiration
 * Requirements: 6.5
 */
export interface ProduceCategorySeed {
    id: string;
    name: string;
    expiry_period_hours: number;
    description: string;
}
/**
 * Default produce categories with expiry periods
 * Expiry period is in hours after harvest date
 */
export declare const produceCategoriesSeedData: ProduceCategorySeed[];
/**
 * Get total count of seed data entries
 */
export declare function getProduceCategoriesSeedCount(): number;
/**
 * Get category by name
 */
export declare function getCategoryByName(name: string): ProduceCategorySeed | undefined;
/**
 * Get all category names
 */
export declare function getAllCategoryNames(): string[];
//# sourceMappingURL=produce-categories-seed.d.ts.map