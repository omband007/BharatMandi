export declare function runMigrations(): Promise<void>;
export declare function rollbackLastMigration(): Promise<void>;
//# sourceMappingURL=migrate.d.ts.map