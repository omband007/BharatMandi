/**
 * OTP Session Helpers for PostgreSQL
 * Replaces SQLite-based OTP session management
 */
export interface OTPSession {
    phoneNumber: string;
    otp: string;
    expiresAt: Date;
    attempts: number;
}
/**
 * Create or update an OTP session
 */
export declare function createOTPSession(session: OTPSession): Promise<boolean>;
/**
 * Get an OTP session by phone number
 */
export declare function getOTPSession(phoneNumber: string): Promise<OTPSession | null>;
/**
 * Update OTP attempts
 */
export declare function updateOTPAttempts(phoneNumber: string, attempts: number): Promise<boolean>;
/**
 * Delete an OTP session
 */
export declare function deleteOTPSession(phoneNumber: string): Promise<boolean>;
/**
 * Clean up expired OTP sessions
 */
export declare function cleanupExpiredOTPSessions(): Promise<number>;
//# sourceMappingURL=otp-helpers.d.ts.map