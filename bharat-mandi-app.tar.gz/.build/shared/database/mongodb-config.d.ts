import mongoose from 'mongoose';
export declare function connectMongoDB(): Promise<void>;
export declare function disconnectMongoDB(): Promise<void>;
export declare function testMongoConnection(): Promise<boolean>;
export declare function getConnectionStatus(): string;
export { mongoose };
//# sourceMappingURL=mongodb-config.d.ts.map