import { RedisClientType } from 'redis';
export interface RedisConfig {
    host: string;
    port: number;
    password?: string;
    db?: number;
}
export declare function getRedisConfig(): RedisConfig;
export declare function initializeRedisClient(): Promise<RedisClientType>;
export declare function getRedisClient(): RedisClientType;
export declare function closeRedisClient(): Promise<void>;
export declare function isRedisAvailable(): Promise<boolean>;
//# sourceMappingURL=redis-client.d.ts.map