"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRedisConfig = getRedisConfig;
exports.initializeRedisClient = initializeRedisClient;
exports.getRedisClient = getRedisClient;
exports.closeRedisClient = closeRedisClient;
exports.isRedisAvailable = isRedisAvailable;
const redis_1 = require("redis");
let redisClient = null;
let isConnecting = false;
function getRedisConfig() {
    return {
        host: process.env.REDIS_HOST || 'localhost',
        port: parseInt(process.env.REDIS_PORT || '6379', 10),
        password: process.env.REDIS_PASSWORD || undefined,
        db: parseInt(process.env.REDIS_DB || '0', 10),
    };
}
async function initializeRedisClient() {
    if (redisClient && redisClient.isOpen) {
        return redisClient;
    }
    if (isConnecting) {
        // Wait for existing connection attempt
        await new Promise(resolve => setTimeout(resolve, 100));
        if (redisClient && redisClient.isOpen) {
            return redisClient;
        }
        throw new Error('Redis connection in progress');
    }
    isConnecting = true;
    try {
        const config = getRedisConfig();
        redisClient = (0, redis_1.createClient)({
            socket: {
                host: config.host,
                port: config.port,
                connectTimeout: 2000, // 2 second timeout
                reconnectStrategy: false, // Don't auto-reconnect in tests
            },
            password: config.password,
            database: config.db,
        });
        redisClient.on('error', (err) => {
            console.error('[Redis] Connection error:', err.message);
        });
        redisClient.on('connect', () => {
            console.log('[Redis] Connected successfully');
        });
        redisClient.on('ready', () => {
            console.log('[Redis] Client ready');
        });
        redisClient.on('end', () => {
            console.log('[Redis] Connection closed');
        });
        await redisClient.connect();
        isConnecting = false;
        return redisClient;
    }
    catch (error) {
        isConnecting = false;
        redisClient = null;
        console.error('[Redis] Failed to initialize:', error instanceof Error ? error.message : error);
        throw error;
    }
}
function getRedisClient() {
    if (!redisClient || !redisClient.isOpen) {
        throw new Error('Redis client not initialized. Call initializeRedisClient() first.');
    }
    return redisClient;
}
async function closeRedisClient() {
    if (redisClient && redisClient.isOpen) {
        await redisClient.quit();
        redisClient = null;
    }
}
async function isRedisAvailable() {
    try {
        if (!redisClient || !redisClient.isOpen) {
            await initializeRedisClient();
        }
        await redisClient.ping();
        return true;
    }
    catch (error) {
        console.error('[Redis] Availability check failed:', error);
        return false;
    }
}
//# sourceMappingURL=redis-client.js.map